﻿// WinDirStat - Windows Directory Statistics
// Copyright © WinDirStat Team
//
// SPDX-License-Identifier: GPL-3.0-or-later
// Distributed WITHOUT ANY WARRANTY; see LICENSE.md for details.

#include "pch.h"
#include "FileTreeView.h"
#include "TreeMapView.h"
#include "FileTopControl.h"
#include "FileSearchControl.h"
#include "FileWatcherControl.h"
#include "FilePermsControl.h"
#include "FinderBasic.h"
#include "FinderMtp.h"
#include "ProgressDlg.h"

CWinDirStatModel::CWinDirStatModel()
{
    assert(nullptr == s_singleton);
    s_singleton = this;

    VTRACE(L"sizeof(CItem) = {}", sizeof(CItem));
    VTRACE(L"sizeof(CTreeListItem) = {}", sizeof(CTreeListItem));
    VTRACE(L"sizeof(CWdsListItem) = {}", sizeof(CWdsListItem));
}

CWinDirStatModel::~CWinDirStatModel()
{
    delete m_rootItem;
    s_singleton = nullptr;
}

CWinDirStatModel* CWinDirStatModel::s_singleton = nullptr;

void CWinDirStatModel::ClearScanState()
{
    CWaitCursor wc;

    // Wait for system to fully shut down
    StopScanningEngine(Abort);

    // Stop watchers
    if (CFileWatcherControl::Get() != nullptr) CFileWatcherControl::Get()->StopMonitoring();

    // Discard pending top-list entries that still point into the old tree.
    if (CFileTopControl::Get() != nullptr) CFileTopControl::Get()->ClearPendingItems();

    // Clean out icon queue
    GetIconHandler()->ClearAsyncShellInfoQueue();

    // Reset extension data
    GetExtensionData()->clear();
    m_registeredExtensions.clear();

    // Clean up visual artifacts - controllers manage their own root items
    if (CFileTopControl::Get() != nullptr) CFileTopControl::Get()->DeleteAllItems();
    if (CFileTreeControl::Get() != nullptr) CFileTreeControl::Get()->DeleteAllItems();
    if (CFileDupeControl::Get() != nullptr) CFileDupeControl::Get()->DeleteAllItems();
    if (CFileSearchControl::Get() != nullptr) CFileSearchControl::Get()->DeleteAllItems();
    if (CFileWatcherControl::Get() != nullptr) CFileWatcherControl::Get()->ClearResults();
    if (CFilePermsControl::Get() != nullptr) CFilePermsControl::Get()->DeleteAllItems();

    // Clean up structures
    delete m_rootItem;
    m_rootItem = nullptr;
    m_zoomItem = nullptr;
}

bool CWinDirStatModel::ResetScan()
{
    ClearScanState();
    SetScanPathSpec(wds::strEmpty);
    NotifyPanes(MODEL_CHANGE_NEW_ROOT);
    return true;
}

bool CWinDirStatModel::StartScan(const std::wstring& pathSpec)
{
    // Expand All Files view to full window during scan
    CMainFrame::Get()->ExpandFileTabbedView();

    // Decode list of folders to scan, discarding blanks and selections already covered by another root
    const std::vector<std::wstring> selections = NormalizeScanPaths(pathSpec);
    if (selections.empty()) return false;

    // Prepare for new root and delete any existing data
    ClearScanState();

    // Persist the full scan spec, which may contain pipe-separated roots.
    Get()->SetScanPathSpec(JoinString(selections));

    const auto isDrivePath = [](const std::wstring& path)
    {
        return path.size() == 3 && path[1] == L':' && path[2] == L'\\' &&
            (path[0] >= L'A' && path[0] <= L'Z' || path[0] >= L'a' && path[0] <= L'z');
    };

    // Build and register an MTP root with its display name and shell path
    const auto createMtpItem = [](const std::wstring& path, const ITEMTYPE flags)
    {
        std::wstring name = FinderMtp::GetDisplayName(path);
        if (name.empty()) name = path;
        const auto item = CItem::Create(IT_DIRECTORY | ITF_MTP | flags, name);
        item->SetIndex(FinderMtp::RegisterPath(path, path));
        return item;
    };

    // Determine if we should add multiple roots under a single node
    if (selections.size() >= 2)
    {
        // Fetch the localized string for the root computer object
        CComHeapPtr<wchar_t> ppszName;
        CComPtr<IShellItem> psi;
        if (FAILED(SHGetKnownFolderItem(FOLDERID_ComputerFolder, KF_FLAG_DEFAULT, nullptr,
            IID_PPV_ARGS(&psi))) ||
            FAILED(psi->GetDisplayName(SIGDN_NORMALDISPLAY, &ppszName)))
        {
            assert(false);
        }

        const std::wstring name = ppszName != nullptr ?
            static_cast<wchar_t*>(ppszName) : Localization::Lookup(IDS_THISPC);
        m_rootItem = CItem::Create(IT_MYCOMPUTER | ITF_ROOTITEM, name);
        // Add filesystem drives, arbitrary folders and registered MTP roots under This PC
        for (const auto& rootFolder : selections)
        {
            if (FinderMtp::IsPath(rootFolder))
            {
                m_rootItem->AddChild(createMtpItem(rootFolder, ITF_NONE));
                continue;
            }

            const bool isDrive = isDrivePath(rootFolder);
            const auto child = CItem::Create(isDrive ? IT_DRIVE : IT_DIRECTORY, rootFolder);
            m_rootItem->AddChild(child);

            // Folder roots are never visited by the drive metadata pass, so read their stats here
            if (!isDrive) child->UpdateStatsFromDisk();
        }
    }
    else
    {
        // Create a storage-specific root for a single selection
        const ITEMTYPE type = isDrivePath(selections.front()) ? IT_DRIVE : IT_DIRECTORY;
        m_rootItem = FinderMtp::IsPath(selections.front()) ? createMtpItem(selections.front(), ITF_ROOTITEM) :
            CItem::Create(type | ITF_ROOTITEM, selections.front());
        m_rootItem->UpdateStatsFromDisk();
    }

    // Restore zoom scope to be the root
    m_zoomItem = m_rootItem;

    // Update new root for display
    NotifyPanes(MODEL_CHANGE_NEW_ROOT);
    StartScanningEngine(std::vector({ Get()->GetRootItem() }));
    return true;
}

bool CWinDirStatModel::OpenLoadedScan(CItem* loadedRoot)
{
    CMainFrame::Get()->ExpandFileTabbedView();

    ClearScanState();

    // Determine root spec string using GetNameView to avoid temporary allocations
    std::wstring spec(loadedRoot->GetNameView());
    // Preserve registered MTP paths when rebuilding single- or multi-root scan specs
    if (loadedRoot->IsTypeOrFlag(IT_MYCOMPUTER))
    {
        std::vector<std::wstring> folders;
        std::ranges::transform(loadedRoot->GetChildren(), std::back_inserter(folders),
            [](const CItem* obj) -> std::wstring
            {
                // GetPath() already yields the registered MTP path or the stored folder path
                return obj->IsTypeOrFlag(IT_DRIVE) ? GetDrive(obj->GetNameView()) : obj->GetPath();
            });
        spec = JoinString(folders);
    }
    else if (loadedRoot->IsTypeOrFlag(ITF_MTP))
    {
        spec = loadedRoot->GetPath();
    }
    else if (loadedRoot->IsTypeOrFlag(IT_DRIVE))
    {
        spec = GetDrive(loadedRoot->GetNameView());
    }

    Get()->SetScanPathSpec(spec);

    m_rootItem = loadedRoot;
    m_zoomItem = m_rootItem;

    // Populate the Largest Files list from the pre-built tree
    for (CItem* item : CItem::GetItemsRecursive({ m_rootItem }))
    {
        CFileTopControl::Get()->ProcessTop(item);
    }

    NotifyPanes(MODEL_CHANGE_NEW_ROOT);
    StartScanningEngine({});
    return true;
}

// The scan spec can be a pipe-separated list of folders, not a filesystem path.
//
void CWinDirStatModel::SetScanPathSpec(const std::wstring& pathSpec)
{
    // MRU would be fine but is not implemented yet.
    m_scanPathSpec = pathSpec;
    SetScanTitle(m_scanPathSpec);
}

// Prefix the window title (with percentage or "Scanning")
//
void CWinDirStatModel::SetScanTitlePrefix(const std::wstring& prefix) const
{
    std::wstring scanName = std::format(L"{} {}", prefix, GetScanTitle());
    scanName = TrimString(scanName);
    CMainFrame::Get()->UpdateFrameTitleForScan(scanName);
}

COLORREF CWinDirStatModel::GetCushionColor(const std::wstring & ext)
{
    const auto& record = GetExtensionData()->find(ext);
    assert(record != GetExtensionData()->end());
    return record->second.color;
}

SExtensionRecord* CWinDirStatModel::GetExtensionDataRecord(const std::wstring& ext)
{
    std::scoped_lock guard(m_extensionMutex);
    return &m_extensionData[ext];
}

// Snapshots every ".ext" key directly under HKEY_CLASSES_ROOT. Rebuilt with the extension
// data so registration tests are lock-free set lookups
void CWinDirStatModel::RebuildRegisteredExtensions()
{
    if (!m_registeredExtensions.empty()) return;

    CRegKey classes;
    if (classes.Open(HKEY_CLASSES_ROOT, nullptr, KEY_READ) != ERROR_SUCCESS) return;

    wchar_t name[UCHAR_MAX + 1];
    for (DWORD i = 0, length = std::size(name); classes.EnumKey(i, name, &length) == ERROR_SUCCESS; ++i, length = std::size(name))
    {
        if (name[0] != L'.') continue;
        _wcslwr_s(name, std::size(name));
        m_registeredExtensions.emplace(name);
    }
}

// True if the extension was present in the HKEY_CLASSES_ROOT snapshot (registered on this PC)
ULONGLONG CWinDirStatModel::GetRootSize() const
{
    assert(m_rootItem != nullptr);
    assert(IsRootDone());
    return m_rootItem->GetSizePhysical();
}

// Starts a refresh of all mount points in our tree.
// Called when the user changes the follow mount points option.
//
void CWinDirStatModel::RefreshReparsePointItems() const
{
    CWaitCursor wc;

    if (CItem* root = GetRootItem(); nullptr != root)
    {
        RecurseRefreshReparsePoints(root);
    }
}

bool CWinDirStatModel::IsRootDone() const
{
    return HasRootItem() && m_rootItem->IsDone();
}

bool CWinDirStatModel::IsScanRunning() const
{
    if (!m_thread.joinable()) return false;

    DWORD exitCode = 0;
    return GetExitCodeThread(const_cast<std::jthread&>(m_thread).native_handle(), &exitCode) &&
        exitCode == STILL_ACTIVE;
}

bool CWinDirStatModel::IsScanSettled() const
{
    return IsRootDone() && !IsScanRunning();
}

void CWinDirStatModel::RunPendingHeapCleanup()
{
    if (!m_heapMinPending.load(std::memory_order_relaxed) || IsScanRunning()) return;

    if (m_heapMinTask.valid() &&
        m_heapMinTask.wait_for(std::chrono::seconds::zero()) != std::future_status::ready) return;

    m_heapMinTask = std::async(std::launch::async, []
    {
        (void) _heapmin();
        ::SetProcessWorkingSetSize(::GetCurrentProcess(), static_cast<SIZE_T>(-1), static_cast<SIZE_T>(-1));
    });
    m_heapMinPending.store(false, std::memory_order_relaxed);
}

void CWinDirStatModel::SetHighlightExtension(const std::wstring & ext, const bool unregistered)
{
    m_highlightExtension = ext;
    m_highlightUnregistered = unregistered;

    // Precompute the unregistered extensions once so the treemap highlight can test each
    // leaf with a single lock-free lookup instead of a per-leaf registry query
    m_highlightExtensions.clear();
    if (unregistered)
    {
        for (const auto& key : m_extensionData | std::views::keys)
        {
            if (!key.empty() && !IsExtensionRegistered(key)) m_highlightExtensions.insert(key);
        }
    }

    CMainFrame::Get()->UpdatePaneText();
}

// The root item has been deleted.
//
void CWinDirStatModel::UnlinkRoot()
{
    CMainFrame::Get()->InvokeInMessageThread([this]
    {
        CMainFrame::Get()->ExpandFileTabbedView();
        ClearScanState();
        NotifyPanes(MODEL_CHANGE_NEW_ROOT);
        CMainFrame::Get()->SetProgressComplete();
    });
}

// Determines whether a UDC works for a given item.
//
bool CWinDirStatModel::UserDefinedCleanupWorksForItem(USERDEFINEDCLEANUP* udc, const CItem* item) const
{
    // Restrict command-based cleanups to items addressable by filesystem APIs
    return item != nullptr && item->SupportsFilesystemApis() && (
        (item->IsTypeOrFlag(IT_DRIVE) && udc->WorksForDrives) ||
        (item->IsTypeOrFlag(IT_DIRECTORY) && udc->WorksForDirectories) ||
        (item->IsTypeOrFlag(IT_FILE) && udc->WorksForFiles) ||
        (item->HasUncPath() && udc->WorksForUncPaths));
}

void CWinDirStatModel::OpenItem(const CItem* item, const std::wstring & verb)
{
    assert(item != nullptr);

    // Ignore if special reserved item
    if (item->IsTypeOrFlag(ITF_RESERVED)) return;

    // Resolve filesystem paths and registered MTP PIDLs to shell identities
    CComHeapPtr<ITEMIDLIST_ABSOLUTE __unaligned> pidl;
    if (item->IsTypeOrFlag(IT_MYCOMPUTER))
    {
        SHGetKnownFolderIDList(FOLDERID_ComputerFolder, 0, nullptr, &pidl);
    }
    else
    {
        pidl.Attach(CreateShellPidl(item));
    }

    // Ignore unresolvable (e.g., deleted) files
    if (pidl == nullptr)
    {
        assert(false);
        return;
    }

    // Launch properties dialog
    SHELLEXECUTEINFO sei{};
    sei.cbSize = sizeof(sei);
    sei.hwnd = GetMainWindowHandle();
    sei.lpVerb = verb.empty() ? nullptr : verb.c_str();
    sei.fMask = SEE_MASK_INVOKEIDLIST | SEE_MASK_IDLIST | SEE_MASK_NOZONECHECKS;
    sei.lpIDList = pidl;
    sei.nShow = SW_SHOWNORMAL;
    ShellExecuteEx(&sei);
}

void CWinDirStatModel::RecurseRefreshReparsePoints(CItem* items) const
{
    std::vector<CItem*> toRefresh;

    if (items == nullptr) return;
    std::vector reparseStack({items});
    while (!reparseStack.empty())
    {
        const auto qitem = reparseStack.back();
        reparseStack.pop_back();

        if (!qitem->IsTypeOrFlag(IT_DIRECTORY, IT_DRIVE)) continue;
        for (const auto& child : qitem->GetChildren())
        {
            if (!(child->IsTypeOrFlag(IT_DIRECTORY, IT_DRIVE) || child->IsTypeOrFlag(ITF_ROOTITEM)))
            {
                continue;
            }

            if (CDirStatApp::Get()->IsFollowingAllowed(child->GetReparseTag()))
            {
                toRefresh.push_back(child);
            }
            else
            {
                reparseStack.push_back(child);
            }
        }
    }

    if (!toRefresh.empty())
    {
        RefreshItem(toRefresh);
    }
}

void CWinDirStatModel::RebuildExtensionData()
{
    // Snapshot the registered extensions up front so all registration tests below (and on
    // the UI thread afterwards) are lock-free lookups against an immutable set
    RebuildRegisteredExtensions();

    // Do initial extension information population if necessary
    if (m_extensionData.empty())
    {
        GetRootItem()->ExtensionDataProcessChildren();
    }

    // Each registered extension is colored on its own; when grouping is enabled the
    // unregistered extensions are gathered so the whole group can share one color
    const bool group = COptions::GroupUnregisteredTypes;
    std::vector<CExtensionData::iterator> individual;
    std::vector<CExtensionData::iterator> unregistered;
    individual.reserve(m_extensionData.size());
    for (auto it = m_extensionData.begin(); it != m_extensionData.end(); ++it)
    {
        const bool grouped = group && !it->first.empty() && !IsExtensionRegistered(it->first);
        (grouped ? unregistered : individual).emplace_back(it);
    }

    // Rank color units by descending bytes; the unregistered group is a single unit
    // (marked with index 'groupUnit') sized by the sum of its members
    constexpr size_t groupUnit = SIZE_MAX;
    const ULONGLONG unregisteredBytes = std::ranges::fold_left(unregistered, ULONGLONG{ 0 },
        [](const ULONGLONG total, const auto& it) { return total + it->second.GetBytes(); });

    std::vector<std::pair<ULONGLONG, size_t>> units;
    units.reserve(individual.size() + 1);
    for (const auto [i, it] : std::views::enumerate(individual))
    {
        units.emplace_back(it->second.GetBytes(), static_cast<size_t>(i));
    }
    if (!unregistered.empty()) units.emplace_back(unregisteredBytes, groupUnit);

    // Sort the color units based on total bytes in descending order
    std::ranges::sort(units, [](const auto& a, const auto& b) { return a.first > b.first; });

    // Initialize colors if not already done
    static std::vector<COLORREF> colors;
    if (colors.empty())
    {
        CTreeMap::GetDefaultPalette(colors);
    }

    // Assign palette colors by rank: distinct primary colors first, then the shared fallback
    for (const auto [rank, unit] : std::views::enumerate(units))
    {
        const COLORREF color = colors[std::min(static_cast<size_t>(rank), colors.size() - 1)];
        if (unit.second == groupUnit)
        {
            for (const auto& it : unregistered) it->second.color = color;
        }
        else
        {
            individual[unit.second]->second.color = color;
        }
    }
}

void CWinDirStatModel::DeletePhysicalItems(const std::vector<CItem*>& items, const bool toTrashBin, const bool emptyOnly) const
{
    auto& showDeleteWarning = toTrashBin ?
        COptions::ShowDeleteToRecycleBinWarning : COptions::ShowDeletePermanentlyWarning;
    if (showDeleteWarning)
    {
        // Build list of file paths for the message box
        std::vector<std::wstring> filePaths;
        filePaths.reserve(items.size());
        for (const auto& item : items) filePaths.emplace_back(item->GetPath());

        // Display the file deletion warning dialog with custom width and height
        if (![&]() -> bool {
            const auto result = CMessageBoxDlg::Show(Localization::Lookup(emptyOnly ? IDS_EMPTY_FOLDER_WARNING : IDS_DELETE_WARNING), filePaths,
                Localization::Lookup(IDS_DONT_SHOW_AGAIN), false, MB_YESNO | MB_ICONWARNING, GetMainWindow(), { 600, 400 }, Localization::Lookup(IDS_DELETE_TITLE));

            if (result.nID != IDYES) return false;

            // Save off the deletion warning preference
            showDeleteWarning = !result.isChecked;
            return true;
        }()) return;
    }

    // Clear active selections
    if (!emptyOnly)
    {
        GetFocusControl()->DeselectAll();
        Get()->InvalidateSelectionCache();
    }

    // Build list of items to delete
    std::vector itemsToDelete{ items };
    if (emptyOnly)
    {
        auto childrenView = items | std::views::transform(&CItem::GetChildren) | std::views::join;
        itemsToDelete.assign(childrenView.begin(), childrenView.end());
    }
    // MTP items require shell deletion instead of direct filesystem calls
    const bool hasMtpItems = std::ranges::any_of(itemsToDelete,
        [](const CItem* item) { return item->IsTypeOrFlag(ITF_MTP); });

    // Calculate total item count for progress tracking
    const size_t totalItems = std::ranges::fold_left(itemsToDelete, size_t{ 0 },
        [](const size_t total, const CItem* item) { return total + static_cast<size_t>(1 + item->GetItemsCount()); });

    // Use direct parallel deletion only for filesystem items without shell progress UI
    std::atomic<bool> cancelled = false;
    if (!hasMtpItems && !toTrashBin && !COptions::ShowMicrosoftProgress) CProgressDlg(
        totalItems, CProgressDlg::Flags::None, GetMainWindow(), [&](CProgressDlg* pdlg)
        {
            // Collect items depth-first and separate into files and directories
            std::vector<const CItem*> files;
            std::vector<const CItem*> directories;
            for (std::vector<CItem*> stack = itemsToDelete; !stack.empty();)
            {
                const CItem* item = stack.back(); stack.pop_back();

                // Sort into files or directories
                (item->IsTypeOrFlag(IT_DIRECTORY) ? directories : files).push_back(item);

                // Add children to stack
                if (item->HasChildren() && !item->IsTypeOrFlag(ITRP_MASK))
                {
                    const auto& children = item->GetChildren();
                    stack.append_range(children);
                }
            }

            // Delete files in parallel
            std::for_each(std::execution::par, files.begin(), files.end(), [&](const CItem* item)
                {
                    if (pdlg->IsCancelled() || cancelled)
                    {
                        cancelled = true;
                        return;
                    }

                    DeleteFileForce(item->GetPathLong(), item->GetAttributes());
                    pdlg->Increment();
                });

            // Check if cancelled during parallel deletion
            if (cancelled) return;

            // Delete directories in reverse order (children before parents)
            for (const auto& item : directories | std::views::reverse)
            {
                if (pdlg->IsCancelled())
                {
                    cancelled = true;
                    return;
                }

                RemoveDirectory(item->GetPathLong().c_str());
                pdlg->Increment();
            }

            // Check if top-level items still exist
            std::vector<CItem*> remainingItems;
            for (const auto& item : itemsToDelete)
            {
                if (GetFileAttributes(item->GetPathLong().c_str()) != INVALID_FILE_ATTRIBUTES)
                {
                    remainingItems.push_back(item);
                }
            }
            itemsToDelete = std::move(remainingItems);
        }).ShowModal();

    if (!cancelled && !itemsToDelete.empty())
    {
        DWORD flags = FOFX_SHOWELEVATIONPROMPT | FOF_NOCONFIRMATION;
        if (toTrashBin) flags |= FOFX_ADDUNDORECORD | FOFX_RECYCLEONDELETE;

        const auto doDelete = [&](const HWND hwnd, const DWORD opFlags)
        {
            // Initialize COM on whichever thread executes the shell operation
            const ComApartmentScope com;
            if (!com) return;

            // Configure one shell operation for filesystem and MTP items
            CComPtr<IFileOperation> fileOperation;
            if (FAILED(::CoCreateInstance(CLSID_FileOperation, nullptr, CLSCTX_ALL, IID_PPV_ARGS(&fileOperation))) ||
                FAILED(fileOperation->SetOwnerWindow(hwnd)) ||
                FAILED(fileOperation->SetOperationFlags(opFlags)))
                return;
            // Queue the complete shell selection and execute it as one deletion
            const CComPtr<IShellItemArray> psia = CreateShellItemArray(itemsToDelete, true);
            if (psia == nullptr || FAILED(fileOperation->DeleteItems(psia))) return;
            const HRESULT res = fileOperation->PerformOperations();
            if (res != S_OK) VTRACE(L"File Operation Failed: {}", TranslateError(res));
        };

        if (COptions::ShowMicrosoftProgress)
            doDelete(GetMainWindowHandle(), flags);
        else
            CProgressDlg(0, CProgressDlg::Flags::None, GetMainWindow(), [&](const CProgressDlg* pdlg)
                { doDelete(*pdlg, flags | FOF_NO_UI); }).ShowModal();
    }

    // Create a set of recycler directories to refresh
    std::unordered_set<CItem*> recyclers;
    if (toTrashBin) for (const auto& item : items)
    {
        const auto& recycler = item->FindRecyclerItem();
        if (recycler != nullptr) recyclers.insert(recycler);
    }

    // Refresh the items and recycler directories
    std::vector<CItem*> itemsToRefresh;
    // Refresh an MTP file's parent after its shell identity is deleted
    for (auto* item : items)
    {
        CItem* refresh = item->IsTypeOrFlag(ITF_MTP) && item->IsTypeOrFlag(IT_FILE) ? item->GetParent() : item;
        if (refresh != nullptr && !std::ranges::contains(itemsToRefresh, refresh))
            itemsToRefresh.push_back(refresh);
    }
    itemsToRefresh.append_range(recyclers);
    RefreshItem(itemsToRefresh);
}

void CWinDirStatModel::SetZoomItem(CItem* item)
{
    if (item == nullptr) return;

    m_zoomItem = item;
    CTreeListControl* pControl = GetFocusControl();
    pControl->Invalidate();
    pControl->UpdateWindow();
    NotifyPanes(MODEL_CHANGE_ZOOM);
}

// Starts a refresh of an item.
// If the physical item has been deleted,
// updates selection, zoom and working item accordingly.
//
void CWinDirStatModel::RefreshItem(const std::vector<CItem*>& item) const
{
    Get()->StartScanningEngine(item);
}

bool CWinDirStatModel::ConfirmOperation(const std::wstring_view operationId, Setting<bool>& prompt,
    const std::wstring_view detail)
{
    return ConfirmOperation(operationId, prompt, std::span<CItem* const>{}, detail);
}

bool CWinDirStatModel::ConfirmOperation(const std::wstring_view operationId, Setting<bool>& prompt,
    const std::span<CItem* const> affectedItems, const std::wstring_view detail)
{
    if (!prompt) return true;

    const std::wstring operation = GetLocalizedMenuText(operationId, detail);
    assert(!operation.empty());
    if (operation.empty()) return false;

    std::vector<std::wstring> affectedPaths;
    affectedPaths.reserve(affectedItems.size());
    for (const CItem* item : affectedItems) affectedPaths.emplace_back(item->GetPath());

    const auto [nID, isChecked] = CMessageBoxDlg::Show(
        Localization::Format(IDS_OPERATION_CONFIRMATIONs, operation), affectedPaths,
        Localization::Lookup(IDS_DONT_SHOW_AGAIN), false, MB_YESNO | MB_ICONWARNING, GetMainWindow(),
        affectedPaths.empty() ? CSize{} : CSize{ 600, 400 }, Localization::Lookup(IDS_DELETE_TITLE));
    if (nID != IDYES) return false;

    prompt = !isChecked;
    return true;
}

void CWinDirStatModel::PerformUserDefinedCleanup(USERDEFINEDCLEANUP* udc, const CItem* item)
{
    CWaitCursor wc;

    const std::wstring path = item->GetPath();

    // Verify that path still exists
    if (item->IsTypeOrFlag(IT_DIRECTORY, IT_DRIVE))
    {
        if (!FolderExists(path) && !DriveExists(path))
        {
            DisplayError(Localization::Format(IDS_PATHs_NOT_EXIST, path));
            throw std::exception{};
        }
    }
    else
    {
        assert(item->IsTypeOrFlag(IT_FILE));

        if (!::PathFileExists(path.c_str()))
        {
            DisplayError(Localization::Format(IDS_PATHs_NOT_EXIST, path));
            throw std::exception{};
        }
    }

    if (udc->RecurseIntoSubdirectories)
    {
        assert(item->IsTypeOrFlag(IT_DRIVE, IT_DIRECTORY));

        RecursiveUserDefinedCleanup(udc, path, path);
    }
    else
    {
        CallUserDefinedCleanup(item->IsTypeOrFlag(IT_DIRECTORY, IT_DRIVE), udc->CommandLine.Obj(), path, path, udc->ShowConsoleWindow, udc->WaitForCompletion);
    }
}

void CWinDirStatModel::RefreshAfterUserDefinedCleanup(const USERDEFINEDCLEANUP* udc, CItem* item, std::vector<CItem*> & refreshQueue) const
{
    // Do not refresh if we are not set to wait
    if (!udc->WaitForCompletion.Obj())
    {
        return;
    }

    switch (static_cast<REFRESHPOLICY>(udc->RefreshPolicy.Obj()))
    {
    case RP_NO_REFRESH:
        break;

    case RP_REFRESH_THIS_ENTRY:
        {
            refreshQueue.push_back(item);
        }
        break;

    case RP_REFRESH_THIS_ENTRYS_PARENT:
        {
            refreshQueue.push_back(nullptr == item->GetParent() ? item : item->GetParent());
        }
        break;
    }
}

void CWinDirStatModel::RecursiveUserDefinedCleanup(USERDEFINEDCLEANUP* udc, const std::wstring& rootPath, const std::wstring& currentPath)
{
    // (Depth first.)

    std::vector<std::wstring> directories;
    FinderBasic finder;
    for (bool b = finder.FindFile(currentPath); b; b = finder.FindNext())
    {
        if (finder.IsDirectory() && CDirStatApp::Get()->IsFollowingAllowed(finder.GetReparseTag()))
            directories.push_back(finder.GetFilePath());
    }
    for (const auto& directory : directories) RecursiveUserDefinedCleanup(udc, rootPath, directory);

    CallUserDefinedCleanup(true, udc->CommandLine.Obj(), rootPath, currentPath, udc->ShowConsoleWindow, true);
}

void CWinDirStatModel::CallUserDefinedCleanup(const bool isDirectory, const std::wstring& format, const std::wstring& rootPath, const std::wstring& currentPath, const bool showConsoleWindow, const bool wait)
{
    const std::wstring userCommandLine = BuildUserDefinedCleanupCommandLine(format, rootPath, currentPath);

    const std::wstring app = GetCOMSPEC();
    std::wstring cmdline = GetBaseNameFromPath(app) + L" /C " + userCommandLine;
    const std::wstring directory = isDirectory ? currentPath : GetFolderNameFromPath(currentPath);

    STARTUPINFO si { sizeof(si) };
    si.dwFlags     = STARTF_USESHOWWINDOW;
    si.wShowWindow = showConsoleWindow ? SW_SHOWNORMAL : SW_HIDE;

    PROCESS_INFORMATION pi{};
    if (CreateProcess(app.c_str(), cmdline.data(), nullptr, nullptr, false,
        0, nullptr, directory.c_str(), &si, &pi) == 0)
    {
        DisplayError(Localization::Format(IDS_PROCESS_FAILEDss, app, TranslateError()));
        throw std::exception{};
    }

    CloseHandle(pi.hThread);

    if (wait)
    {
        CWinApp::WaitForHandleWithUiUpdates(pi.hProcess);
    }

    CloseHandle(pi.hProcess);
}

std::wstring CWinDirStatModel::BuildUserDefinedCleanupCommandLine(const std::wstring & format, const std::wstring & rootPath, const std::wstring & currentPath)
{
    const std::wstring rootName    = GetBaseNameFromPath(rootPath);
    const std::wstring currentName = GetBaseNameFromPath(currentPath);

    std::wstring s = format;

    // Because file names can contain "%", we first replace our placeholders with
    // strings which contain a forbidden character.
    ReplaceString(s, L"%p", L">p");
    ReplaceString(s, L"%n", L">n");
    ReplaceString(s, L"%sp", L">sp");
    ReplaceString(s, L"%sn", L">sn");

    // Now substitute
    ReplaceString(s, L">p", rootPath);
    ReplaceString(s, L">n", rootName);
    ReplaceString(s, L">sp", currentPath);
    ReplaceString(s,L">sn", currentName);

    return s;
}

void CWinDirStatModel::PushReselectChild(CItem* item)
{
    if (item != nullptr) m_reselectChildStack.push_back(item);
}

CItem* CWinDirStatModel::PopReselectChild()
{
    if (m_reselectChildStack.empty()) return nullptr;
    CItem* item = m_reselectChildStack.back();
    m_reselectChildStack.pop_back();
    return item;
}

bool CWinDirStatModel::FileTreeHasFocus()
{
    return LF_FILETREE == CMainFrame::Get()->GetLogicalFocus();
}

bool CWinDirStatModel::DupeListHasFocus()
{
    return LF_DUPELIST == CMainFrame::Get()->GetLogicalFocus();
}

bool CWinDirStatModel::TopListHasFocus()
{
    return LF_TOPLIST == CMainFrame::Get()->GetLogicalFocus();
}

bool CWinDirStatModel::SearchListHasFocus()
{
    return LF_SEARCHLIST == CMainFrame::Get()->GetLogicalFocus();
}

bool CWinDirStatModel::WatcherListHasFocus()
{
    return LF_WATCHERLIST == CMainFrame::Get()->GetLogicalFocus();
}

bool CWinDirStatModel::PermsListHasFocus()
{
    return LF_PERMSLIST == CMainFrame::Get()->GetLogicalFocus();
}

CTreeListControl* CWinDirStatModel::GetFocusControl()
{
    if (DupeListHasFocus()) return CFileDupeControl::Get();
    if (TopListHasFocus()) return CFileTopControl::Get();
    if (SearchListHasFocus()) return CFileSearchControl::Get();
    if (WatcherListHasFocus()) return CFileWatcherControl::Get();
    if (PermsListHasFocus()) return CFilePermsControl::Get();
    return CFileTreeControl::Get();
}

void CWinDirStatModel::NotifyPanes(const MODEL_CHANGE change, CItem* item)
{
    NotifyPanesExcept(nullptr, change, item);
}

void CWinDirStatModel::NotifyPanesExcept(CWnd* sender, const MODEL_CHANGE change, CItem* item)
{
    InvalidateSelectionCache();

    if (CMainFrame::Get() != nullptr)
    {
        CMainFrame::Get()->UpdateAllPanes(sender, change, item);
    }
}

std::span<CItem* const> CWinDirStatModel::GetSelectedItemsView()
{
    // Check if we can use cached results
    const auto currentFocus = CMainFrame::Get()->GetLogicalFocus();
    if (m_selectionCacheValid && m_cachedFocus == currentFocus)
    {
        return m_cachedSelection;
    }

    // Query fresh selection data
    auto selection = GetFocusControl()->GetAllSelected<CItem>();

    // Expand any visual items if the direct item fetch did not work
    if (selection.empty()) for (const auto item : GetFocusControl()->GetAllSelected<CTreeListItem>(true))
    {
        // If item has no direct link but has children, expand to children
        // Skip root container nodes (no parent) - they should not proxy as a full selection
        if (item->GetLinkedItem()) continue;
        if (item->GetParent() == nullptr) continue;

        for (const auto i : std::views::iota(0, item->GetTreeListChildCount()))
        {
            if (const auto linkedItem = item->GetTreeListChild(i)->GetLinkedItem())
            {
                selection.push_back(linkedItem);
            }
        }
    }

    // Update cache
    m_cachedFocus = currentFocus;
    m_cachedSelection = std::move(selection);
    m_selectionCacheValid = true;

    return m_cachedSelection;
}

std::vector<CItem*> CWinDirStatModel::GetAllSelected()
{
    const auto selection = GetSelectedItemsView();
    return { selection.begin(), selection.end() };
}
