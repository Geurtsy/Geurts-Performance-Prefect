﻿// WinDirStat - Windows Directory Statistics
// Copyright © WinDirStat Team
//
// SPDX-License-Identifier: GPL-3.0-or-later
// Distributed WITHOUT ANY WARRANTY; see LICENSE.md for details.

#pragma once

#include "pch.h"

class ComApartmentScope final
{
public:
    explicit ComApartmentScope(const DWORD flags = COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE) noexcept :
        // Keep a successful COM initialization active for this scope's lifetime.
        m_initialized(SUCCEEDED(CoInitializeEx(nullptr, flags)))
    {
    }

    ~ComApartmentScope() noexcept
    {
        // Balance every successful initialization when the scope ends.
        if (m_initialized) CoUninitialize();
    }

    ComApartmentScope(const ComApartmentScope&) = delete;
    ComApartmentScope& operator=(const ComApartmentScope&) = delete;

    explicit operator bool() const noexcept
    {
        return m_initialized;
    }

private:
    const bool m_initialized;
};

// Interface helpers declarations

// Locale and formatting
std::wstring GetLocaleString(LCTYPE lctype, LCID lcid);
std::wstring GetLocaleString(LCTYPE lctype, const std::wstring& localeName);
std::wstring GetLocaleLanguage(LANGID langid);
wchar_t GetLocaleThousandSeparator() noexcept;
wchar_t GetLocaleDecimalSeparator() noexcept;
std::wstring FormatBytes(ULONGLONG n) noexcept;
std::wstring FormatSizeSuffixes(ULONGLONG n) noexcept;
std::wstring FormatCount(ULONGLONG n) noexcept;
std::wstring FormatDouble(double d) noexcept;
std::wstring FormatFileTime(const FILETIME& t, bool seconds = false) noexcept;
std::wstring FormatAttributes(DWORD attr) noexcept;
std::wstring FormatHex(const std::vector<BYTE>& bytes, bool upper = true) noexcept;
std::wstring FormatMilliseconds(ULONGLONG ms) noexcept;
std::wstring FormatVolumeNameOfRootPath(const std::wstring& rootPath);
std::wstring FormatVolumeName(const std::wstring& rootPath, const std::wstring& volumeName);

// File and path helpers
std::vector<std::wstring> NormalizeScanPaths(const std::wstring& pathSpec);
std::wstring GetFolderNameFromPath(std::wstring_view path);
std::wstring GetBaseNameFromPath(std::wstring_view path);
std::wstring GlobToRegex(const std::wstring& glob, bool useAnchors = true);

// String helpers
void ReplaceString(std::wstring& subject, std::wstring_view search, std::wstring_view replace);
std::wstring& TrimString(std::wstring& s, wchar_t c = L' ', bool endOnly = false) noexcept;
std::wstring MakeLower(const std::wstring& s);
std::wstring JoinString(const std::vector<std::wstring>& items, WCHAR delim = wds::chrPipe);
std::vector<std::wstring> SplitString(const std::wstring& string, WCHAR delim = wds::chrPipe);

// Attribute parsing
DWORD ParseAttributes(const std::wstring_view& attributes) noexcept;

// Size specifiers
const std::wstring& GetSpec_Bytes() noexcept;
const std::wstring& GetSpec_KiB() noexcept;
const std::wstring& GetSpec_MiB() noexcept;
const std::wstring& GetSpec_GiB() noexcept;
const std::wstring& GetSpec_TiB() noexcept;

// System information
FILETIME CurrentSystemFileTime() noexcept;
std::wstring GetCOMSPEC();
const std::wstring& GetSysDirectory() noexcept;

// UI helpers
void DisplayError(const std::wstring& error);
std::wstring TranslateError(HRESULT hr = static_cast<HRESULT>(GetLastError()));
bool ShellExecuteWrapper(const std::wstring& lpFile, const std::wstring& lpParameters = L"",
        const std::wstring& lpVerb = L"", HWND hwnd = GetMainWindowHandle(),
        const std::wstring& lpDirectory = L"", INT nShowCmd = SW_NORMAL, ULONG fMask = 0, HANDLE* process = nullptr);
bool ExecuteCommandInConsole(const std::wstring& command, const std::wstring& title = L"");
std::optional<std::wstring> RemoveSelectedHistoryEntry(const MSG* pMsg, CComboBox& comboBox,
    std::vector<std::wstring>& history);

std::wstring GetLocalizedMenuText(std::wstring_view textId, std::wstring_view detail = {});

// Shell item array
class CItem;
PIDLIST_ABSOLUTE CreateShellPidl(const std::wstring& path);
PIDLIST_ABSOLUTE CreateShellPidl(const CItem* item);
CComPtr<IShellItemArray> CreateShellItemArray(const std::vector<CItem*>& items, bool allOrNothing = false);

// Context menu
constexpr auto CONTENT_MENU_MINCMD = 0x1ul;
constexpr auto CONTENT_MENU_MAXCMD = 0x7FFFul; // Application commands begin at 0x8000.
CComPtr<IContextMenu> GetContextMenu(const std::vector<CItem*>& items);

// Application info
std::wstring GetAppTitle();
std::wstring GetAppFileName(const std::wstring& ext = L"");
std::wstring GetAppFolder();

// Resources
std::vector<BYTE> GetCompressedResource(HRSRC resource) noexcept;
std::wstring GetTextResource(UINT id);
std::wstring GetAcceleratorString(UINT commandID);

// Rect struct
using CSmallRect = struct CSmallRect
{
    WORD left = 0, top = 0, right = 0, bottom = 0;

    // Default constructor
    constexpr CSmallRect() noexcept = default;

    // Constructor from CRect
    explicit constexpr CSmallRect(const CRect& rect) noexcept :
        left(static_cast<WORD>(rect.left)), top(static_cast<WORD>(rect.top)),
        right(static_cast<WORD>(rect.right)), bottom(static_cast<WORD>(rect.bottom)) {}

    // Assignment from CRect
    constexpr CSmallRect& operator=(const CRect& rect) noexcept
    {
        left = static_cast<WORD>(rect.left);
        top = static_cast<WORD>(rect.top);
        right = static_cast<WORD>(rect.right);
        bottom = static_cast<WORD>(rect.bottom);
        return *this;
    }

    // Conversion to CRect
    operator CRect() const noexcept
    {
        return { left, top, right, bottom };
    }
};
