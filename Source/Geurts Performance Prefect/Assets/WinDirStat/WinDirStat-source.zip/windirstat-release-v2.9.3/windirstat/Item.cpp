﻿// WinDirStat - Windows Directory Statistics
// Copyright © WinDirStat Team
//
// SPDX-License-Identifier: GPL-3.0-or-later
// Distributed WITHOUT ANY WARRANTY; see LICENSE.md for details.

#include "pch.h"
#include "Item.h"
#include "Filtering.h"
#include "FinderBasic.h"
#include "FinderMtp.h"
#include "FinderNtfs.h"

class CItem::ScanBatch final
{
    CItem* m_parent;
    BlockingQueue<CItem*>* m_queue;
    std::vector<CItem*> m_children;
    std::unordered_map<std::wstring, std::pair<ULONGLONG, ULONGLONG>> m_extensions;
    ULONGLONG m_physical = 0, m_logical = 0, m_lastFlush = GetTickCount64();
    FILETIME m_lastChange{};
    ULONG m_files = 0, m_folders = 0;

public:
    ScanBatch(CItem* parent, BlockingQueue<CItem*>* queue) : m_parent(parent), m_queue(queue)
    {
        m_children.reserve(128);
    }
    ~ScanBatch() { Flush(); }

    void Add(CItem* child)
    {
        if (m_parent->IsTypeOrFlag(ITF_MTP)) child->SetFlag(ITF_MTP);
        child->SetParent(m_parent);
        m_children.push_back(child);
        m_physical += child->GetSizePhysical();
        m_logical += child->GetSizeLogical();
        m_lastChange = std::max(m_lastChange, child->GetLastChange());
        if (!child->IsTypeOrFlag(IT_FILE)) { ++m_folders; return; }

        ++m_files;
        auto& [files, bytes] = m_extensions[child->GetExtension()];
        ++files;
        bytes += child->GetSizeLogical();
        child->SetFlag(ITF_EXTDATA);
    }

    void FlushIfNeeded(const bool force = false)
    {
        if (force || m_children.size() >= 128 || GetTickCount64() - m_lastFlush >= 100) Flush();
    }

    void Flush()
    {
        if (m_children.empty()) return;
        m_parent->UpwardAddSizePhysical(std::exchange(m_physical, 0));
        m_parent->UpwardAddSizeLogical(std::exchange(m_logical, 0));
        m_parent->UpwardAddFiles(std::exchange(m_files, 0));
        m_parent->UpwardAddFolders(std::exchange(m_folders, 0));
        m_parent->UpwardUpdateLastChange(std::exchange(m_lastChange, FILETIME{}));
        for (const auto& [extension, totals] : m_extensions)
        {
            auto* record = CWinDirStatModel::Get()->GetExtensionDataRecord(extension);
            record->files.fetch_add(totals.first, std::memory_order_relaxed);
            record->bytes.fetch_add(totals.second, std::memory_order_relaxed);
        }
        m_extensions.clear();

        const auto append = [this] { m_parent->m_folderInfo->m_children.append_range(m_children); };
        if (!m_parent->MutateHiddenChildren(append)) CMainFrame::Get()->InvokeInMessageThread([&]
        {
            append();
            if (!m_parent->IsExpanded()) return;
            const std::vector<CTreeListItem*> rows(m_children.begin(), m_children.end());
            CFileTreeControl::Get()->OnChildrenAdded(m_parent, rows);
        });
        for (CItem* child : m_children)
        {
            if (child->IsTypeOrFlag(IT_FILE)) CFileTopControl::Get()->ProcessTop(child);
            else if (child->GetReadJobs() > 0) m_queue->Push(child);
        }
        m_children.clear();
        m_lastFlush = GetTickCount64();
        m_parent->UpwardDrivePacman();
    }
};

// --- Construction / Destruction ---

void* CItem::operator new(const size_t size, const std::wstring_view name)
{
    if (name.size() > std::numeric_limits<USHORT>::max() ||
        size > std::numeric_limits<size_t>::max() - (name.size() + 1) * sizeof(wchar_t))
        throw std::bad_array_new_length();
    return ::operator new(size + (name.size() + 1) * sizeof(wchar_t));
}

CItem* CItem::Create(const ITEMTYPE type, const std::wstring_view name)
{
    return new (type & IT_DRIVE ? std::wstring_view{} : name) CItem(type, name);
}

CItem* CItem::Create(CItem* linkedItem)
{
    return new (std::wstring_view{}) CItem(linkedItem);
}

CItem* CItem::Create(const ITEMTYPE type, const std::wstring_view name, const FILETIME lastChange,
    const ULONGLONG sizePhysical, const ULONGLONG sizeLogical, const ULONGLONG index,
    const DWORD attributes, const ULONG files, const ULONG subdirs)
{
    return new (type & IT_DRIVE ? std::wstring_view{} : name)
        CItem(type, name, lastChange, sizePhysical, sizeLogical, index, attributes, files, subdirs);
}

CItem::CItem(const ITEMTYPE type, const std::wstring_view name) : m_type(type)
{
    if (IsTypeOrFlag(IT_MYCOMPUTER, IT_DRIVE, IT_DIRECTORY, IT_HLINKS, IT_HLINKS_SET, IT_HLINKS_IDX))
    {
        m_folderInfo = std::make_unique<CHILDINFO>();

        // My computer node will never have these attributes set externally
        if (IsTypeOrFlag(IT_MYCOMPUTER))
        {
            m_attributes = 0;
        }
    }

    if (IsTypeOrFlag(IT_DRIVE))
    {
        // Store drive paths with a backslash
        std::wstring nameTmp(name);
        if (nameTmp.ends_with(L":")) nameTmp.append(L"\\");

        // The name string on the drive is two parts separated by a pipe. For example,
        // C:\|Local Disk (C:) is the true path followed by the name description
        SetName(std::format(L"{:.2}|{}", nameTmp, FormatVolumeNameOfRootPath(nameTmp)));
        m_attributes = LOWORD(GetFileAttributes(GetPathLong().c_str()));
    }
    else
    {
        SetName(name);
    }
}

CItem::CItem(CItem* linkedItem) : m_type(IT_HLINKS_FILE)
{
    assert(linkedItem != nullptr);
    SetName({});
    m_sizePhysical = linkedItem->GetSizePhysicalRaw();
    m_sizeLogical = linkedItem->GetSizeLogical();
    m_index = reinterpret_cast<std::uintptr_t>(linkedItem);
    SetLastChange(linkedItem->GetLastChange());
}

CItem::CItem(const ITEMTYPE type, const std::wstring_view name, const FILETIME lastChange,
    const ULONGLONG sizePhysical, const ULONGLONG sizeLogical, const ULONGLONG index,
    const DWORD attributes, const ULONG files, const ULONG subdirs)
{
    m_type = type;
    if (IsTypeOrFlag(IT_MYCOMPUTER, IT_DRIVE, IT_DIRECTORY, IT_HLINKS, IT_HLINKS_SET, IT_HLINKS_IDX))
    {
        m_folderInfo = std::make_unique<CHILDINFO>();
        m_folderInfo->m_subdirs = subdirs;
        m_folderInfo->m_files = files;
    }

    if (IsTypeOrFlag(IT_DRIVE))
    {
        SetName(std::format(L"{:.2}|{}", name, FormatVolumeNameOfRootPath(std::wstring(name))));
    }
    else
    {
        SetName(name);
    }
    SetLastChange(lastChange);
    m_sizePhysical = sizePhysical;
    m_sizeLogical = sizeLogical;
    m_index = index;
    m_attributes = LOWORD(attributes);
}

CItem::~CItem()
{
    if (m_folderInfo != nullptr)
    {
        std::vector<CItem*> queue = std::move(m_folderInfo->m_children);
        while (!queue.empty())
        {
            const CItem* current = queue.back();
            queue.pop_back();

            if (current->m_folderInfo != nullptr)
            {
                if (auto& children = current->m_folderInfo->m_children; !children.empty())
                {
                    queue.append_range(children);
                    children.clear();
                }
            }
            delete current;
        }
    }
    // Release any MTP shell metadata registered to this item
    if (IsTypeOrFlag(ITF_MTP)) FinderMtp::UnregisterPath(m_index);
}

// --- Hierarchy ---

const std::vector<CItem*>& CItem::GetChildren() const noexcept
{
    assert(m_folderInfo != nullptr);
    return m_folderInfo->m_children;
}

CItem* CItem::GetEnumRoot() const noexcept
{
    // Resolve the selected folder, drive, or MTP branch without crossing a multi-root container.
    auto* item = const_cast<CItem*>(this);
    while (!item->IsTypeOrFlag(ITF_ROOTITEM) && item->GetParent() != nullptr &&
        !item->GetParent()->IsTypeOrFlag(IT_MYCOMPUTER)) item = item->GetParent();
    return item;
}

CItem* CItem::GetParentDrive() const noexcept
{
    CItem* enumRoot = GetEnumRoot();
    return enumRoot->IsTypeOrFlag(IT_DRIVE) ? enumRoot : nullptr;
}

CItem* CItem::GetVolumeRoot() const noexcept
{
    // Prefer a nearer mounted volume before falling back to the enumeration root.
    CItem* enumRoot = GetEnumRoot();
    for (auto* item = const_cast<CItem*>(this); item != enumRoot; item = item->GetParent())
    {
        if (item->IsTypeOrFlag(IT_DRIVE, ITRP_MOUNT)) return item;
    }
    return enumRoot;
}

bool CItem::IsScanRoot() const noexcept
{
    // True for the tree root and for every selection placed directly under a multi-root container
    return IsTypeOrFlag(ITF_ROOTITEM) || GetParent() == nullptr || GetParent()->IsTypeOrFlag(IT_MYCOMPUTER);
}

bool CItem::IsMtpRoot() const noexcept
{
    return IsTypeOrFlag(ITF_MTP) && IsScanRoot();
}

bool CItem::HasShellIdentity() const noexcept
{
    return !IsTypeOrFlag(ITF_MTP) || FinderMtp::HasShellIdentity(m_index);
}

bool CItem::MutateHiddenChildren(const std::function<void()>& mutation) const
{
    // Progress reads drive children even when their rows are hidden.
    if (IsTypeOrFlag(IT_DRIVE, IT_MYCOMPUTER) && CMainFrame::Get() != nullptr) return false;
    std::shared_lock lock(CTreeListControl::s_viewStateMutex);
    if (CTreeListControl::s_viewStates.contains(this)) return false;
    mutation();
    return true;
}

void CItem::AddChild(CItem* child, const bool addOnly)
{
    assert(!child->IsTypeOrFlag(IT_FILE, IT_DIRECTORY, IT_DRIVE) || GetParentDrive() == nullptr ||
        GetParentDrive()->GetReadJobs() > 0 || FindHardlinksItem() == nullptr);

    if (IsTypeOrFlag(ITF_MTP)) child->SetFlag(ITF_MTP);

    if (!addOnly)
    {
        UpwardAddSizePhysical(child->GetSizePhysical());
        UpwardAddSizeLogical(child->GetSizeLogical());
        UpwardUpdateLastChange(child->GetLastChange());
        ExtensionDataAdd();
    }

    child->SetParent(this);
    const auto append = [this, child] { m_folderInfo->m_children.push_back(child); };
    if (!MutateHiddenChildren(append)) CMainFrame::Get()->InvokeInMessageThread([&]
    {
        // Add child in UI thread since UI thread immediately uses it
        append();
        if (IsExpanded()) CFileTreeControl::Get()->OnChildAdded(this, child);
    });
}

void CItem::RemoveChild(CItem* child) const
{
    assert(!child->IsTypeOrFlag(IT_FILE, IT_DIRECTORY, IT_DRIVE) || child->GetParentDrive() == nullptr ||
        child->FindHardlinksItem() == nullptr);

    const auto remove = [this, child]
    {
        if (IsVisible()) CFileTreeControl::Get()->OnChildRemoved(this, child);
        auto& children = m_folderInfo->m_children;
        if (const auto it = std::ranges::find(children, child); it != children.end()) children.erase(it);
        delete child;
    };
    if (CMainFrame::Get() != nullptr) CMainFrame::Get()->InvokeInMessageThread(remove);
    else remove();
}

void CItem::RemoveAllChildren() const
{
    assert(!IsTypeOrFlag(IT_FILE, IT_DIRECTORY, IT_DRIVE) || GetParentDrive() == nullptr ||
        FindHardlinksItem() == nullptr);

    if (IsRootItem())
    {
        CWinDirStatModel::Get()->GetExtensionData()->clear();
    }

    if (IsLeaf()) return;
    CMainFrame::Get()->InvokeInMessageThread([this]
    {
        CFileTreeControl::Get()->OnRemovingAllChildren(this);
    });

    for (const auto& child : m_folderInfo->m_children)
    {
        delete child;
    }
    m_folderInfo->m_children.clear();
}

CItem* CItem::AddDirectory(const Finder& finder, ScanBatch& batch)
{
    // Bypass filesystem reparse restrictions when traversing MTP directories
    const bool follow = IsTypeOrFlag(ITF_MTP) || !finder.IsProtectedReparsePoint() &&
        CDirStatApp::Get()->IsFollowingAllowed(finder.GetReparseTag());

    auto* const child = CItem::Create(IT_DIRECTORY, finder.GetFileName());
    child->SetIndex(finder.GetIndex());
    // Preserve MTP shell metadata under the child index for later access
    if (IsTypeOrFlag(ITF_MTP))
        child->SetIndex(FinderMtp::RegisterPath({}, finder.GetShellPath(), finder.GetShellPidl()));
    child->SetLastChange(finder.GetLastWriteTime());
    child->SetAttributes(finder.GetAttributes());
    child->SetReparseTag(finder.GetReparseTag());
    if (finder.IsReserved() || this->IsTypeOrFlag(ITF_RESERVED)) child->SetFlag(ITF_RESERVED);
    if ((finder.RequiresBasicEnumeration() || IsTypeOrFlag(ITF_BASIC)) && follow)
        child->SetFlag(ITF_BASIC);
    batch.Add(child);
    child->UpwardAddReadJobs(follow ? 1 : 0);

    return child;
}

CItem* CItem::AddFile(const Finder& finder, ScanBatch& batch)
{
    auto* const child = CItem::Create(IT_FILE, finder.GetFileName());
    child->SetIndex(finder.GetIndex());
    // Preserve MTP shell metadata under the child index for later access
    if (IsTypeOrFlag(ITF_MTP))
        child->SetIndex(FinderMtp::RegisterPath({}, finder.GetShellPath(), finder.GetShellPidl()));
    child->SetSizePhysical(finder.GetFileSizePhysical());
    child->SetSizeLogical(finder.GetFileSizeLogical());
    child->SetLastChange(finder.GetLastWriteTime());
    child->SetAttributes(finder.GetAttributes());
    child->SetReparseTag(finder.GetReparseTag());
    if (finder.IsReserved() || this->IsTypeOrFlag(ITF_RESERVED)) child->SetFlag(ITF_RESERVED);
    batch.Add(child);
    child->SetDone();
    return child;
}

// --- Size & Stats ---

ULONGLONG CItem::GetSizePhysical() const noexcept
{
    return (IsTypeOrFlag(ITF_HARDLINK) && COptions::ProcessHardlinks) ? 0 : m_sizePhysical.load();
}

void CItem::UpwardAddSizePhysical(const ULONGLONG bytes) noexcept
{
    if (bytes == 0) return;

    for (auto p = this; p != nullptr; p = p->GetParent())
    {
        p->m_sizePhysical += bytes;
        if (p->IsTypeOrFlag(ITF_HARDLINK)) break;
    }
}

void CItem::UpwardSubtractSizePhysical(const ULONGLONG bytes) noexcept
{
    if (bytes == 0) return;

    for (auto p = this; p != nullptr; p = p->GetParent())
    {
        assert(bytes <= p->m_sizePhysical);
        p->m_sizePhysical -= bytes;
        if (p->IsTypeOrFlag(ITF_HARDLINK)) break;
    }
}

void CItem::UpwardAddSizeLogical(const ULONGLONG bytes) noexcept
{
    if (bytes == 0) return;
    for (auto p = this; p != nullptr; p = p->GetParent())
    {
        p->m_sizeLogical += bytes;
    }
}

void CItem::UpwardSubtractSizeLogical(const ULONGLONG bytes) noexcept
{
    if (bytes == 0) return;
    for (auto p = this; p != nullptr; p = p->GetParent())
    {
        assert(bytes <= p->m_sizeLogical);
        p->m_sizeLogical -= bytes;
    }
}

void CItem::UpwardAddFolders(const ULONG dirCount) const noexcept
{
    if (dirCount == 0) return;
    for (auto p = this; p != nullptr; p = p->GetParent())
    {
        if (p->IsTypeOrFlag(IT_FILE)) continue;
        p->m_folderInfo->m_subdirs += dirCount;
    }
}

void CItem::UpwardSubtractFolders(const ULONG dirCount) const noexcept
{
    if (dirCount == 0) return;
    for (auto p = this; p != nullptr; p = p->GetParent())
    {
        assert(p->m_folderInfo->m_subdirs >= dirCount);
        if (p->IsTypeOrFlag(IT_FILE)) continue;
        p->m_folderInfo->m_subdirs -= dirCount;
    }
}

void CItem::UpwardAddFiles(const ULONG fileCount) const noexcept
{
    if (fileCount == 0) return;
    for (auto p = this; p != nullptr; p = p->GetParent())
    {
        if (p->IsTypeOrFlag(IT_FILE)) continue;
        p->m_folderInfo->m_files += fileCount;
    }
}

void CItem::UpwardSubtractFiles(const ULONG fileCount) const noexcept
{
    if (fileCount == 0) return;
    for (auto p = this; p != nullptr; p = p->GetParent())
    {
        if (p->IsTypeOrFlag(IT_FILE)) continue;
        assert(p->m_folderInfo->m_files >= fileCount);
        p->m_folderInfo->m_files -= fileCount;
    }
}

double CItem::GetFraction() const noexcept
{
    if (!GetParent())
    {
        return 1.0;
    }
    const ULONGLONG parentSize = COptions::TreeMapUseLogical ? GetParent()->GetSizeLogical() : GetParent()->GetSizePhysical();
    if (parentSize == 0)
    {
        return 1.0;
    }
    const ULONGLONG size = COptions::TreeMapUseLogical ? GetSizeLogical() : GetSizePhysical();
    return static_cast<double>(size) / static_cast<double>(parentSize);
}

double CItem::GetAbsoluteFraction() const noexcept
{
    if (!GetParent())
    {
        return 1.0;
    }

    const CItem* root = this;
    while (root->GetParent() != nullptr)
    {
        root = root->GetParent();
    }

    const ULONGLONG rootSize = COptions::TreeMapUseLogical ? root->GetSizeLogical() : root->GetSizePhysical();
    if (rootSize == 0)
    {
        return 0.0;
    }

    const ULONGLONG size = COptions::TreeMapUseLogical ? GetSizeLogical() : GetSizePhysical();
    return static_cast<double>(size) / static_cast<double>(rootSize);
}

ULONGLONG CItem::GetItemsCount() const noexcept
{
    if (IsLeaf()) return 0;
    return static_cast<ULONGLONG>(m_folderInfo->m_files) + static_cast<ULONGLONG>(m_folderInfo->m_subdirs);
}

void CItem::ExtensionDataAdd()
{
    if (!IsTypeOrFlag(IT_FILE) || IsTypeOrFlag(ITF_EXTDATA)) return;
    const auto record = CWinDirStatModel::Get()->GetExtensionDataRecord(GetExtension());
    record->AddFile(GetSizeLogical());
    SetFlag(ITF_EXTDATA);
}

void CItem::ExtensionDataRemove()
{
    if (!IsTypeOrFlag(IT_FILE) || !IsTypeOrFlag(ITF_EXTDATA)) return;
    const auto record = CWinDirStatModel::Get()->GetExtensionDataRecord(GetExtension());
    record->RemoveFile(GetSizeLogical());
    if (record->GetFiles() == 0) CWinDirStatModel::Get()->GetExtensionData()->erase(GetExtension());
    SetFlag(ITF_EXTDATA, true);
}

void CItem::ExtensionDataProcessChildren(const bool remove)
{
    std::vector childStack({ this });
    while (!childStack.empty()) [[msvc::forceinline_calls]]
    {
        const auto& item = childStack.back();
        childStack.pop_back();

        if (item->IsTypeOrFlag(IT_MYCOMPUTER, IT_DIRECTORY, IT_DRIVE))
        {
            for (const auto& child : item->GetChildren())
            {
                childStack.push_back(child);
            }
        }
        else if (item->IsTypeOrFlag(IT_FILE))
        {
            remove ? item->ExtensionDataRemove() : item->ExtensionDataAdd();
        }
    }
}

// --- Attributes & Properties ---

DWORD CItem::GetAttributes() const noexcept
{
    return m_attributes == LOWORD(INVALID_FILE_ATTRIBUTES)
        ? INVALID_FILE_ATTRIBUTES : m_attributes;
}

USHORT CItem::GetSortAttributes() const noexcept
{
    if (GetAttributes() == INVALID_FILE_ATTRIBUTES) return 0;

    USHORT ret = 0;

    // We want to enforce the order RHSACE with R being the highest priority
    // attribute and E being the lowest priority attribute.
    ret |= m_attributes & FILE_ATTRIBUTE_READONLY    ? 1 << 6 : 0; // R
    ret |= m_attributes & FILE_ATTRIBUTE_HIDDEN      ? 1 << 5 : 0; // H
    ret |= m_attributes & FILE_ATTRIBUTE_SYSTEM      ? 1 << 4 : 0; // S
    ret |= m_attributes & FILE_ATTRIBUTE_ARCHIVE     ? 1 << 3 : 0; // A
    ret |= m_attributes & FILE_ATTRIBUTE_COMPRESSED  ? 1 << 2 : 0; // C
    ret |= m_attributes & FILE_ATTRIBUTE_ENCRYPTED   ? 1 << 1 : 0; // E
    ret |= m_attributes & FILE_ATTRIBUTE_SPARSE_FILE ? 1 << 0 : 0; // Z

    return ret;
}

DWORD CItem::GetReparseTag() const noexcept
{
    if (IsTypeOrFlag(ITRP_SYMLINK)) return IO_REPARSE_TAG_SYMLINK;
    if (IsTypeOrFlag(ITRP_MOUNT)) return IO_REPARSE_TAG_MOUNT_POINT;
    if (IsTypeOrFlag(ITRP_JUNCTION)) return IO_REPARSE_TAG_JUNCTION_POINT;
    if (IsTypeOrFlag(ITRP_CLOUD)) return IO_REPARSE_TAG_CLOUD_MASK;
    return 0;
}

void CItem::SetReparseTag(const DWORD reparseType) noexcept
{
    if (reparseType == IO_REPARSE_TAG_SYMLINK) SetReparseType(ITRP_SYMLINK);
    else if (reparseType == IO_REPARSE_TAG_MOUNT_POINT) SetReparseType(ITRP_MOUNT);
    else if (reparseType == IO_REPARSE_TAG_JUNCTION_POINT) SetReparseType(ITRP_JUNCTION);
    else if ((reparseType & ~IO_REPARSE_TAG_CLOUD_MASK) == IO_REPARSE_TAG_CLOUD) SetReparseType(ITRP_CLOUD);
}

std::wstring CItem::GetOwner(const bool force) const
{
    // Skip filesystem security queries for MTP items
    if (IsTypeOrFlag(ITF_MTP)) return {};
    auto* viewState = force ? nullptr : GetViewState();
    if (!force && viewState == nullptr) return {};

    // If visible, use cached variable
    std::wstring tmp;
    std::wstring & ret = viewState != nullptr ? viewState->owner : tmp;
    if (!ret.empty()) return ret;

    // Fetch owner information from drive
    SmartPointer ps(LocalFree, static_cast<PSECURITY_DESCRIPTOR>(nullptr));
    PSID sid = nullptr;
    GetNamedSecurityInfo(GetPathLong().c_str(), SE_FILE_OBJECT, OWNER_SECURITY_INFORMATION,
        &sid, nullptr, nullptr, nullptr, &ps);
    ret = GetNameFromSid(sid);
    return ret;
}

void CItem::UpwardUpdateLastChange(const FILETIME& t) noexcept
{
    const auto value = std::bit_cast<ULONGLONG>(t);
    for (auto p = this; p != nullptr; p = p->GetParent())
    {
        auto previous = p->m_lastChange.load(std::memory_order_relaxed);
        while (previous < value && !p->m_lastChange.compare_exchange_weak(previous, value,
            std::memory_order_relaxed)) {}
    }
}

void CItem::UpwardRecalcLastChange()
{
    // ignore current object in recalculation
    for (auto p = GetParent(); p != nullptr; p = p->GetParent())
    {
        const auto newMax = (std::ranges::max)(
            p->GetChildren() | std::views::transform(&CItem::GetLastChange));

        if (p->GetLastChange() == newMax) break;
        p->SetLastChange(newMax);
    }
}

// --- Paths & Names ---

void CItem::SetName(const std::wstring_view name)
{
    if (name.size() > std::numeric_limits<USHORT>::max()) throw std::bad_array_new_length();
    auto nameLen = static_cast<USHORT>(name.size());
    while (nameLen > 0 && name[nameLen - 1] == L'\\') nameLen--;

    auto driveName = IsTypeOrFlag(IT_DRIVE) ? std::make_unique_for_overwrite<wchar_t[]>(nameLen + 1) : nullptr;
    wchar_t* buffer = driveName != nullptr ? driveName.get() : GetNameBuffer();
    if (nameLen) std::wmemcpy(buffer, name.data(), nameLen);
    buffer[nameLen] = L'\0';
    if (driveName != nullptr) m_folderInfo->m_driveName = std::move(driveName);
    m_nameLen = nameLen;
}

std::wstring CItem::GetName(const bool stripDrivePrefix) const noexcept
{
    return std::wstring(GetNameView(stripDrivePrefix));
}

std::wstring_view CItem::GetNameView(const bool stripDrivePrefix) const noexcept
{
    if (IsTypeOrFlag(IT_HLINKS_FILE)) return GetLinkedItem()->GetNameView(stripDrivePrefix);
    if (stripDrivePrefix && IsTypeOrFlag(IT_DRIVE))
    {
        return std::wstring_view(GetNameBuffer(), m_nameLen).substr(std::size(L"?:"));
    }
    return { GetNameBuffer(), m_nameLen };
}

bool CItem::HasExtension(const std::wstring_view extension) const noexcept
{
    if (!IsTypeOrFlag(IT_FILE)) return false;

    const auto name = GetNameView();
    if (extension.empty() || extension.size() > name.size()) return false;

    const auto suffix = name.substr(name.size() - extension.size());
    return _wcsnicmp(suffix.data(), extension.data(), extension.size()) == 0;
}

std::wstring CItem::GetExtension() const
{
    if (!IsTypeOrFlag(IT_FILE)) return GetName();
    const auto extName = GetNameView();
    const auto pos = extName.rfind('.');
    if (pos == std::wstring_view::npos) return {};
    std::wstring extLower(extName.substr(pos));
    _wcslwr_s(extLower.data(), extLower.size() + 1);
    return extLower;
}

std::wstring CItem::GetPath() const
{
    if (IsTypeOrFlag(IT_HLINKS_FILE)) return GetLinkedItem()->GetPath();

    if (IsTypeOrFlag(IT_HLINKS_SET, IT_HLINKS_IDX))
    {
        return {};
    }

    // Reconstruct MTP paths from the registered root and item ancestry
    if (IsTypeOrFlag(ITF_MTP))
    {
        thread_local std::vector<const CItem*> pathParts;
        pathParts.clear();
        const CItem* root = GetEnumRoot();
        for (const CItem* part = this; part != root; part = part->GetParent())
        {
            pathParts.push_back(part);
        }

        std::wstring path = root->IsTypeOrFlag(ITF_MTP) ? FinderMtp::GetPath(root->m_index) : std::wstring{};
        if (!path.empty())
        {
            for (const CItem* part : pathParts | std::views::reverse)
            {
                if (!path.ends_with(L'\\')) path += L'\\';
                path += part->GetNameView();
            }
            return path;
        }
    }

    std::wstring path = GetPathWithoutSlash();
    if (IsTypeOrFlag(IT_DRIVE))
    {
        path += L"\\";
    }
    return path;
}

int CItem::ComparePath(const CItem* other) const
{
    if (!other) return 1;

    auto getValid = [](const CItem* item) -> const CItem*
    {
        while (item && item->IsTypeOrFlag(IT_MYCOMPUTER, IT_HLINKS_SET, IT_HLINKS_IDX))
        {
            item = item->GetParent();
        }

        return item;
    };

    const CItem* leftRoot = getValid(this);
    const CItem* rightRoot = getValid(other);

    if (!leftRoot || !rightRoot) return (leftRoot > rightRoot) - (leftRoot < rightRoot);

    thread_local std::vector<const CItem*> leftPath;
    thread_local std::vector<const CItem*> rightPath;

    leftPath.clear();
    rightPath.clear();

    for (const CItem* p = leftRoot; p; p = getValid(p->GetParent())) leftPath.push_back(p);
    for (const CItem* p = rightRoot; p; p = getValid(p->GetParent())) rightPath.push_back(p);

    size_t leftIdx = leftPath.size();
    size_t rightIdx = rightPath.size();

    // Walk from root toward leaves by indexing backwards.
    while (leftIdx > 0 && rightIdx > 0 && leftPath[leftIdx - 1] == rightPath[rightIdx - 1])
    {
        --leftIdx;
        --rightIdx;
    }

    // One path is an ancestor of the other.
    if (leftIdx == 0 || rightIdx == 0)
    {
        if (leftIdx == 0 && rightIdx == 0) return 0;
        return leftIdx == 0 ? -1 : 1;
    }

    const CItem* left = leftPath[leftIdx - 1];
    const CItem* right = rightPath[rightIdx - 1];
    auto getSlice = [](const CItem* item)
    {
        const auto view = item->GetNameView();
        if (item->IsTypeOrFlag(IT_DRIVE)) return view.substr(0, 2);
        return view;
    };

    const auto leftView = getSlice(left);
    const auto rightView = getSlice(right);

    const size_t minLen = (std::min)(leftView.size(), rightView.size());
    if (const int cmp = _wcsnicmp(leftView.data(), rightView.data(), minLen))
    {
        return (cmp > 0) - (cmp < 0);
    }

    return (leftView.size() > rightView.size()) - (leftView.size() < rightView.size());
}

std::wstring CItem::GetPathLong() const
{
    if (IsTypeOrFlag(ITF_MTP)) return GetPath();
    return FinderBasic::MakeLongPathCompatible(GetPath());
}

std::wstring CItem::GetFolderPath() const
{
    if (IsTypeOrFlag(ITF_MTP))
        return IsTypeOrFlag(IT_FILE) && GetParent() != nullptr ? GetParent()->GetPath() : GetPath();

    std::wstring path = GetPath();
    if (IsTypeOrFlag(IT_FILE))
    {
        const auto i = path.find_last_of(wds::chrBackslash);
        assert(i != std::wstring::npos);
        path = path.substr(0, i + 1);
    }

    return path;
}

bool CItem::HasUncPath() const
{
    if (IsTypeOrFlag(ITF_MTP)) return false;
    return GetPath().starts_with(L"\\\\");
}

CItem* CItem::FindItemByPath(const std::wstring& path, const bool findAncestor) const
{
    // Find the most specific enumeration root containing the requested path.
    CItem* root = GetEnumRoot();
    const auto roots = root->IsTypeOrFlag(IT_MYCOMPUTER) ?
        std::span(root->GetChildren()) : std::span<CItem* const>(&root, 1);
    CItem* current = nullptr;
    size_t rootLength = 0;
    for (CItem* candidate : roots)
    {
        std::wstring rootPath = candidate->GetPath();
        while (!rootPath.empty() && rootPath.back() == L'\\') rootPath.pop_back();
        if (rootPath.size() <= rootLength || path.size() < rootPath.size() ||
            _wcsnicmp(path.c_str(), rootPath.c_str(), rootPath.size()) != 0 ||
            (path.size() > rootPath.size() && path[rootPath.size()] != L'\\')) continue;
        current = candidate;
        rootLength = rootPath.size();
    }
    if (current == nullptr) return nullptr;

    // Split the path into components, filtering out empty strings
    for (const auto part : std::views::split(std::wstring_view(path).substr(rootLength), wds::chrBackslash))
    {
        const std::wstring_view component(part.begin(), part.end());
        if (component.empty()) continue;
        if (current->IsLeaf()) return findAncestor ? current : nullptr;

        // Find the matching child using GetNameView for comparison
        auto it = std::ranges::find_if(current->GetChildren(),
            [&](const CItem* child) { return child->GetNameView() == component; });
        if (it == current->GetChildren().end()) return findAncestor ? current : nullptr;
        current = *it;
    }

    return current;
}

std::wstring CItem::GetPathWithoutSlash() const
{
    // create vector of the path structure in thread scope so we can reverse it
    thread_local std::vector<const CItem*> pathParts;
    thread_local std::wstring path;

    // make sure the vector is cleared before use
    pathParts.clear();
    path.clear();

    // walk backwards to get a list of pointers to each part of the path
    for (auto p = this; p != nullptr; p = p->GetParent())
    {
        pathParts.emplace_back(p);
    }

    // append the strings in reverse order
    for (auto it = pathParts.rbegin(); it != pathParts.rend(); ++it) [[msvc::forceinline_calls]]
    {
        if (const auto & pathPart = *it; pathPart->IsTypeOrFlag(IT_DIRECTORY))
        {
            path.append(pathPart->GetNameBuffer(), pathPart->m_nameLen).append(L"\\");
        }
        else if (pathPart->IsTypeOrFlag(IT_DRIVE))
        {
            path.append(pathPart->GetNameBuffer(), 2).append(L"\\");
        }
        else if (!pathPart->IsTypeOrFlag(IT_MYCOMPUTER))
        {
            path.append(pathPart->GetNameBuffer(), pathPart->m_nameLen);
        }
    }

    // Remove trailing backslashes
    if (const auto pos = path.find_last_not_of(L'\\'); pos != std::wstring::npos)
    {
        path.erase(pos + 1);
    }
    return path;
}

// --- Scanning & Done State ---

void CItem::SetDone()
{
    if (IsDone())
    {
        return;
    }

    if (SupportsSpaceItems())
    {
        UpdateFreeSpaceItem();
        UpdateUnknownItem();
    }

    // Sort and set finish time
    if (!IsLeaf())
    {
        COptions::TreeMapUseLogical ? SortItemsBySizeLogical() : SortItemsBySizePhysical();
        m_folderInfo->m_tfinish = GetScanTickCount();
    }

    // Mark as done just so other functions do not sort at the same time
    SetFlag(ITF_DONE);
}

void CItem::UpwardSetDone() noexcept
{
    for (auto p = this; p != nullptr; p = p->GetParent())
    {
        p->SetDone();
    }
}

void CItem::UpwardSetUndone() noexcept
{
    for (auto p = this; p != nullptr; p = p->GetParent())
    {
        if (p->SupportsSpaceItems() && p->IsDone())
        {
            if (CItem* unknown = p->FindUnknownItem(); unknown != nullptr)
            {
                p->UpwardSubtractSizePhysical(unknown->GetSizePhysical());
                unknown->SetSizePhysical(0);
            }
        }

        p->SetFlag(ITF_DONE, true);
    }
}

void CItem::UpwardAddReadJobs(const ULONG count) const noexcept
{
    if (IsLeaf() || count == 0) return;
    if (m_folderInfo->m_jobs == 0) m_folderInfo->m_tstart = GetScanTickCount();
    for (auto p = this; p != nullptr; p = p->GetParent())
    {
        if (p->IsTypeOrFlag(IT_FILE)) continue;
        p->m_folderInfo->m_jobs += count;
    }
}

void CItem::UpwardSubtractReadJobs(const ULONG count) noexcept
{
    if (count == 0 || IsTypeOrFlag(IT_FILE)) return;
    for (auto p = this; p != nullptr; p = p->GetParent())
    {
        if (p->m_folderInfo->m_jobs.fetch_sub(count) == count)
        {
            p->SetDone();
        }
    }
}

ULONGLONG CItem::GetTicksWorked() const noexcept
{
    if (IsLeaf()) return 0;
    return m_folderInfo->m_tfinish > 0 ? (m_folderInfo->m_tfinish - m_folderInfo->m_tstart) :
        (m_folderInfo->m_tstart > 0) ? (GetScanTickCount() - m_folderInfo->m_tstart) : 0;
}

void CItem::ResetScanStartTime() const noexcept
{
    if (IsLeaf()) return;
    m_folderInfo->m_tfinish = 0;
    m_folderInfo->m_tstart = GetScanTickCount();
}

ULONG CItem::GetScanTickCount() noexcept
{
    const ULONGLONG state = scanClockState.load(std::memory_order_relaxed);
    const ULONGLONG activeMilliseconds = (state & SCAN_CLOCK_SUSPENDED) != 0 ?
        state & ~SCAN_CLOCK_SUSPENDED : GetTickCount64() - state;
    return static_cast<ULONG>(activeMilliseconds / 1000ull);
}

void CItem::SuspendScanClock() noexcept
{
    const ULONGLONG state = scanClockState.load(std::memory_order_relaxed);
    if ((state & SCAN_CLOCK_SUSPENDED) != 0) return;

    const ULONGLONG activeMilliseconds = GetTickCount64() - state;
    assert((activeMilliseconds & SCAN_CLOCK_SUSPENDED) == 0);
    scanClockState.store(SCAN_CLOCK_SUSPENDED | activeMilliseconds, std::memory_order_relaxed);
}

void CItem::ResumeScanClock() noexcept
{
    const ULONGLONG state = scanClockState.load(std::memory_order_relaxed);
    if ((state & SCAN_CLOCK_SUSPENDED) == 0) return;

    const ULONGLONG activeMilliseconds = state & ~SCAN_CLOCK_SUSPENDED;
    scanClockState.store(GetTickCount64() - activeMilliseconds, std::memory_order_relaxed);
}

void CItem::SortItemsBySizePhysical() const
{
    if (IsLeaf()) return;

    // sort by size for proper treemap rendering
    const auto sort = [this]
    {
        m_folderInfo->m_children.shrink_to_fit();
        std::ranges::sort(m_folderInfo->m_children, std::ranges::greater{}, &CItem::GetSizePhysical);
    };
    if (!MutateHiddenChildren(sort)) CMainFrame::Get()->InvokeInMessageThread(sort);
}

void CItem::SortItemsBySizeLogical() const
{
    if (IsLeaf()) return;

    // sort by size for proper treemap rendering
    const auto sort = [this]
    {
        m_folderInfo->m_children.shrink_to_fit();
        std::ranges::sort(m_folderInfo->m_children, std::ranges::greater{}, &CItem::GetSizeLogical);
    };
    if (!MutateHiddenChildren(sort)) CMainFrame::Get()->InvokeInMessageThread(sort);
}

void CItem::UpdateStatsFromDisk()
{
    assert(!IsTypeOrFlag(IT_FILE, IT_DIRECTORY, IT_DRIVE) || GetParentDrive() == nullptr ||
        FindHardlinksItem() == nullptr);

    // Keep MTP metadata supplied by device enumeration
    if (IsTypeOrFlag(ITF_MTP)) return;

    if (IsTypeOrFlag(IT_DIRECTORY, IT_FILE))
    {
        FinderBasic finder(true);
        // A scan root stores its full path as its name, so it must be looked up without a name filter
        if (finder.FindFile(GetFolderPath(), IsScanRoot() ? std::wstring() : GetName(), GetAttributes()))
        {
            SetLastChange(finder.GetLastWriteTime());
            SetAttributes(finder.GetAttributes());

            if (IsTypeOrFlag(IT_FILE))
            {
                ExtensionDataRemove();
                UpwardSubtractSizePhysical(GetSizePhysicalRaw());
                UpwardSubtractSizeLogical(GetSizeLogical());
                UpwardAddSizePhysical(finder.GetFileSizePhysical());
                UpwardAddSizeLogical(finder.GetFileSizeLogical());
                SetIndex(finder.GetIndex());
                ExtensionDataAdd();
            }
        }
        else if (IsScanRoot() && GetAttributes() == INVALID_FILE_ATTRIBUTES)
        {
            // Correct potentially invalid attributes on root items
            if (const DWORD attr = GetFileAttributes(GetPathLong().c_str()); attr != INVALID_FILE_ATTRIBUTES)
            {
                SetAttributes(attr);
            }
        }
    }
    else if (IsTypeOrFlag(IT_DRIVE))
    {
        if (const SmartPointer handle(CloseHandle, CreateFile(GetPathLong().c_str(), FILE_READ_ATTRIBUTES,
            FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr,
            OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, nullptr)); handle != INVALID_HANDLE_VALUE)
        {
            FILETIME lastChange{};
            if (GetFileTime(handle, nullptr, nullptr, &lastChange)) SetLastChange(lastChange);
        }
    }
}

void CItem::ScanItems(BlockingQueue<CItem*> * queue, FinderNtfsContext& contextNtfs, FinderBasicContext& contextBasic,
    std::unordered_map<const CItem*, FinderBasicContext>* folderContexts)
{
    // Reuse the NTFS and MTP finders throughout this worker
    FinderNtfs finderNtfs(&contextNtfs);
    FinderMtp finderMtp;

    for (auto itemOpt = queue->Pop(); itemOpt.has_value(); itemOpt = queue->Pop())
    {
        // Fetch item from queue
        CItem* const item = itemOpt.value();

        // Mark the time we started evaluating this node
        item->ResetScanStartTime();

        if (item->IsTypeOrFlag(IT_DRIVE, IT_DIRECTORY) && CFiltering::IsFilterActive() &&
            CFiltering::IsFilteredOut(item->GetPath()))
        {
            item->UpwardSubtractReadJobs(1);
            item->UpwardDrivePacman();
            continue;
        }

        // Try to load NTFS MFT
        if (item->IsTypeOrFlag(IT_DRIVE) && COptions::UseFastScanEngine)
        {
            contextNtfs.LoadRoot(item, queue);
        }

        if (item->IsTypeOrFlag(IT_DRIVE, IT_DIRECTORY))
        {
            auto* basicContext = &contextBasic;
            if (folderContexts != nullptr)
            {
                // Descendants keep the context of the root initially assigned to this queue.
                const CItem* root = item->GetVolumeRoot();
                auto context = folderContexts->find(root);
                while (context == folderContexts->end()) context = folderContexts->find(root = root->GetParent());
                basicContext = &context->second;
            }
            FinderBasic finderBasic(basicContext);

            // Select the enumeration backend for the queued item
            Finder* finder = item->IsTypeOrFlag(ITF_MTP) ? static_cast<Finder*>(&finderMtp) :
                contextNtfs.IsLoaded() && !item->IsTypeOrFlag(ITF_BASIC) ?
                static_cast<Finder*>(&finderNtfs) : static_cast<Finder*>(&finderBasic);

            ScanBatch batch(item, queue);
            for (bool b = finder->FindFile(item); b; b = finder->FindNext()) [[msvc::forceinline_calls]]
            {
                if (queue->IsPauseOrCancelRequested())
                {
                    batch.Flush();
                    queue->WaitIfSuspended();
                }
                if (finder->IsDirectory())
                {
                    if (COptions::ExcludeHiddenDirectory && finder->IsHidden() ||
                        COptions::ExcludeProtectedDirectory && finder->IsHiddenSystem() ||
                        COptions::ExcludeDropboxIgnored && finder->HasIgnoredStream() ||
                        CFiltering::IsFilterActive() && CFiltering::IsFilteredOut(finder->GetFilePath()))
                    {
                        continue;
                    }

                    item->AddDirectory(*finder, batch);
                }
                else
                {
                    if (COptions::ExcludeHiddenFile && finder->IsHidden() ||
                        COptions::ExcludeProtectedFile && finder->IsHiddenSystem() ||
                        COptions::ExcludeSymbolicLinksFile && finder->GetReparseTag() == IO_REPARSE_TAG_SYMLINK ||
                        COptions::ExcludeDropboxIgnored && finder->HasIgnoredStream() ||
                        CFiltering::IsFilterActive() && CFiltering::IsFilteredOut(finder->GetFileName(),
                            CFiltering::IncludeDirsRegex.empty() ? std::wstring() : finder->GetFilePath(),
                            finder->GetFileSizeLogical(), finder->GetLastWriteTime()))
                    {
                        continue;
                    }

                    CItem* newitem = item->AddFile(*finder, batch);
                    batch.FlushIfNeeded(COptions::ScanForDuplicates);
                    CFileDupeControl::Get()->ProcessDuplicate(newitem, queue);
                }

                // Update pacman position
                batch.FlushIfNeeded(queue->IsPauseOrCancelRequested());
                queue->WaitIfSuspended();
            }
        }
        else if (item->IsTypeOrFlag(IT_FILE))
        {
            // Only used for refreshes
            item->UpdateStatsFromDisk();
            CFileDupeControl::Get()->ProcessDuplicate(item, queue);
            CFileTopControl::Get()->ProcessTop(item);
            item->SetDone();
        }
        else if (item->IsTypeOrFlag(IT_MYCOMPUTER))
        {
            for (const auto & child : item->GetChildren())
            {
                child->UpwardAddReadJobs(1);
                queue->Push(child);
            }
        }
        item->UpwardSubtractReadJobs(1);
        item->UpwardDrivePacman();
    }
}

void CItem::ScanItemsFinalize(CItem* item)
{
    if (item == nullptr) return;
    std::vector queue({item});
    while (!queue.empty()) [[msvc::forceinline_calls]]
    {
        const auto & qitem = queue.back();
        queue.pop_back();
        qitem->SetDone();
        if (qitem->m_folderInfo == nullptr) continue;
        for (const auto& child : qitem->GetChildren())
        {
            if (!child->IsDone()) queue.push_back(child);
        }
    }
}
