﻿// WinDirStat - Windows Directory Statistics
// Copyright © WinDirStat Team
//
// SPDX-License-Identifier: GPL-3.0-or-later
// Distributed WITHOUT ANY WARRANTY; see LICENSE.md for details.

#pragma once
#include "pch.h"

class CWdsListControl;

//
// SSorting. A sorting specification. We sort by column1, and if two items
// are equal in column1, we sort them by column2.
//
struct SSorting
{
    int column1 = 0;
    int column2 = 0;
    int subitem1 = 0;
    int subitem2 = 0;
    bool ascending1 = true;
    bool ascending2 = true;

    bool operator==(const SSorting&) const = default;
};

//
// CWdsListItem. An item in a CWdsListControl.
// Some columns (subitems) may be owner drawn (DrawSubItem() returns true);
// CWdsListControl draws the texts (GetText()) of all others.
// DrawLabel() draws a standard label (with icon, text, selection and focus rect)
//

class CWdsListItem
{
public:
    CWdsListItem() = default;
    virtual ~CWdsListItem() = default;

    // This text is drawn if DrawSubItem returns false
    virtual std::wstring GetText(int subitem) const = 0;
    // This color is used for the current item
    virtual COLORREF GetItemTextColor() const
    {
        return DarkMode::SystemColor(COLOR_WINDOWTEXT);
    }

    // Comparison methods for sorting
    virtual int Compare(const CWdsListItem* other, int subitem) const = 0;
    int CompareSort(const CWdsListItem* other, const SSorting& sorting) const;

    // Return value is true if the item draws itself.
    // width != nullptr -> only determine width, do not draw.
    // If focus rectangle shall not begin leftmost, set *focusLeft
    // to the left edge of the desired focus rectangle.
    virtual bool DrawSubItem(int subitem, CDC* pdc, CRect rc, UINT state, int* width, int* focusLeft) = 0;
    virtual void DrawAdditionalState(CDC* /*pdc*/, const CRect& /*rcLabel*/) const {}
    void DrawSelection(const CWdsListControl* list, CDC* pdc, CRect rc, UINT state) const;
    virtual HICON GetIcon() = 0;
    virtual bool IsVisible() const { return true; }
    void DrawLabel(const CWdsListControl* list, CDC* pdc, CRect& rc, UINT state, int* width, int* focusLeft, bool indent = true);
    void DrawPercentage(CDC* pdc, CRect rc, double fraction, COLORREF color) const;
};

//
// CWdsListControl. Must be report view. Deals with CWdsListItems.
// Can have a grid or not (own implementation, don't set LVS_EX_GRIDLINES). Flicker-free.
// Also handles sorting functionality (merged from CSortingListControl).
//
class CWdsListControl : public MessageTarget<CWdsListControl, CListCtrl>
{
public:
    CWdsListControl(std::vector<int>* columnOrder, std::vector<int>* columnWidths, std::vector<int>* columnVisibility);
    ~CWdsListControl() override = default;
    void OnColumnsInserted(std::initializer_list<int> requiredColumns = {}, std::initializer_list<int> defaultHiddenColumns = {});
    void OnFontSizeChanged(int oldPercent, int newPercent) override;
    virtual void SysColorChanged();
    void OnAppearanceChanged() override { SysColorChanged(); }

    int GetRowHeight() const { return m_rowHeight; }
    int GetIconSize() const { return m_iconSize; }
    void CalculateRowHeight();
    void ShowGrid(bool show);
    void ShowStripes(bool show);
    void ShowFullRowSelection(bool show);
    bool IsFullRowSelection() const { return m_showFullRowSelect; }

    COLORREF GetHighlightColor() const;
    COLORREF GetHighlightTextColor() const;

    bool IsItemStripColor(const int i) const { return m_showStripes && i % 2 != 0; }
    COLORREF GetItemBackgroundColor(const int i) const { return IsItemStripColor(i) ? m_stripeColor : m_windowColor; }
    COLORREF GetItemSelectionBackgroundColor(int i) const;
    COLORREF GetItemSelectionTextColor(int i) const;

    CWdsListItem* GetItem(int i) const;
    int FindListItem(const CWdsListItem* item) const;
    int GetGeneralLeftIndent() const;
    CRect GetWholeSubitemRect(int item, int subitem) const;
    void LoadPersistentAttributes();
    void InsertListItem(int i, std::span<CWdsListItem* const> items);
    void InsertSortedListItems(std::span<CWdsListItem* const> items);
    void InsertListItem(const int i, CWdsListItem* item) { InsertListItem(i, std::span<CWdsListItem* const>(&item, 1)); }
    void RemoveListItem(int i, int c = 1);

    // Shadow CListCtrl methods for Owner Data management.
    // Use these instead of standard CListCtrl methods to ensure proper data management in LVS_OWNERDATA mode.
    virtual bool DeleteItem(int i);
    bool DeleteAllItems();

    // Sorting functionality
    int ColumnToSubItem(int col) const;
    int SubItemToColumn(int subitem) const;
    bool IsColumnVisible(int subitem) const;
    void SetColumnVisible(int subitem, bool visible, bool force = false);
    void SetSorting(const SSorting& sorting) { m_sorting = sorting; }
    void SetSorting(int sortColumn1, bool ascending1, int sortColumn2, bool ascending2);
    void SetSorting(int sortColumn, bool ascending);
    virtual void SortItems();
    virtual bool GetAscendingDefault(int) { return true; }
    int GetItemCount() const noexcept { return static_cast<int>(m_items.size()); }
    void SetOwnsItems(const bool owns) { m_ownsItems = owns; }

    // Selection change batching
    void PostSelectionChanged();
    void DeselectAll();
    HFONT GetFont() const;

protected:
    void InitializeColors();
    void UpdateSortIndicator();
    void ApplyColumnVisibility(int column);
    void DrawItem(LPDRAWITEMSTRUCT pdis) override;
    int GetSubItemWidth(CWdsListItem* item, int subitem, CDC* pDC = nullptr);
    bool IsColumnRequired(int subitem) const;
    virtual void OnItemContextMenu(CPoint /*point*/) {}
    void SavePersistentAttributes() const override;
    void ShowColumnContextMenu(CPoint point);

    // Owner-drawn related members
    std::vector<CWdsListItem*> m_items;
    std::unordered_map<CWdsListItem*, int> m_itemMap;
    bool m_ownsItems = false;
    COLORREF m_windowColor = CLR_NONE; // The default background color if !m_showStripes
    COLORREF m_stripeColor = CLR_NONE; // The stripe color, used for every other item if m_showStripes
    int m_rowHeight = 20;              // Height of an item
    int m_iconSize = 16;
    int m_columnCount = 0;
    bool m_showGrid = false;           // Whether to draw a grid
    bool m_showStripes = false;        // Whether to show stripes
    bool m_showFullRowSelect = false;  // Whether to draw full row selection

    // Sorting related members (merged from CSortingListControl)
    std::vector<int>* m_columnOrder = nullptr;
    std::vector<int>* m_columnWidths = nullptr;
    std::vector<int>* m_columnVisibility = nullptr;
    std::vector<int> m_defaultColumnWidths;
    std::vector<int> m_requiredColumns;
    SSorting m_sorting;
    int m_indicatedColumn = -1;

    // Selection change batching
    static constexpr DWORD WM_SELECTION_CHANGED = WM_APP + 1;
    bool m_selectionChangePending = false;
    mutable HFONT m_cachedFont = nullptr;

public:
    static std::span<const RouteEntry> Routes();

protected:
    void OnContextMenu(WindowRef pWnd, CPoint point);
    bool OnEraseBkgnd(CDC* pDC) const;
    void OnHdnBeginTrack(NMHDR* pNMHDR, LRESULT* pResult);
    void OnHdnDividerdblclick(NMHDR* pNMHDR, LRESULT* pResult);
    void OnHdnItemchanging(NMHDR* pNMHDR, LRESULT* pResult);
    void OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult) const;
    void OnLvnGetDispInfo(NMHDR* pNMHDR, LRESULT* pResult) const;
    void OnHdnItemClick(NMHDR* pNMHDR, LRESULT* pResult);
    void OnHdnItemDblClick(NMHDR* pNMHDR, LRESULT* pResult);
    void OnDestroy();
    void OnSettingChange(UINT uFlags, LPCTSTR lpszSection);
    virtual LRESULT OnSelectionChanged(WPARAM wParam, LPARAM lParam);
    LRESULT OnSetFont(WPARAM wParam, LPARAM lParam);
};

inline std::span<const RouteEntry> CWdsListControl::Routes()
{
    static constexpr std::array entries
    {
        Route::Window<&OnSelectionChanged>(WM_SELECTION_CHANGED),
        Route::Notify<&OnHdnBeginTrack>(HDN_BEGINTRACK, 0),
        Route::Notify<&OnHdnDividerdblclick>(HDN_DIVIDERDBLCLICK, 0),
        Route::Notify<&OnHdnItemchanging>(HDN_ITEMCHANGING, 0),
        Route::Notify<&OnHdnItemClick>(HDN_ITEMCLICK, 0),
        Route::Notify<&OnHdnItemDblClick>(HDN_ITEMDBLCLICK, 0),
        Route::Notify<&OnCustomDraw>(NM_CUSTOMDRAW, 0),
        Route::ReflectNotify<&OnLvnGetDispInfo>(LVN_GETDISPINFO),
        Route::Window<&OnContextMenu>(WM_CONTEXTMENU),
        Route::Window<&OnDestroy>(WM_DESTROY),
        Route::Window<&OnEraseBkgnd>(WM_ERASEBKGND),
        Route::Window<&OnSettingChange>(WM_SETTINGCHANGE),
        Route::Window<&OnShowWindow>(WM_SHOWWINDOW),
        Route::Window<&OnSetFont>(WM_SETFONT),
    };
    return entries;
}
