﻿// WinDirStat - Windows Directory Statistics
// Copyright © WinDirStat Team
//
// SPDX-License-Identifier: GPL-3.0-or-later
// Distributed WITHOUT ANY WARRANTY; see LICENSE.md for details.

#include "pch.h"
#include "FinderNtfs.h"

enum ATTRIBUTE_TYPE_CODE : ULONG
{
    AttributeStandardInformation = 0x10,
    AttributeFileName = 0x30,
    AttributeData = 0x80,
    AttributeReparsePoint = 0xC0,
    AttributeEnd = 0xFFFFFFFF,
};

using FILE_RECORD = struct FILE_RECORD
{
    ULONG Signature;
    USHORT UsaOffset;
    USHORT UsaCount;
    ULONGLONG Lsn;
    USHORT SequenceNumber;
    USHORT LinkCount;
    USHORT FirstAttributeOffset;
    USHORT Flags;
    ULONG FirstFreeByte;
    ULONG BytesAvailable;
    ULONGLONG BaseFileRecordNumber : 48;
    ULONGLONG BaseFileRecordSequence : 16;
    USHORT NextAttributeNumber;
    USHORT SegmentNumberHighPart;
    ULONG SegmentNumberLowPart;

    constexpr ULONGLONG SegmentNumber() const noexcept
    {
        return static_cast<ULONGLONG>(SegmentNumberHighPart) << 32ul | SegmentNumberLowPart;
    }

    constexpr bool IsValid() const noexcept
    {
        return Signature == 0x454C4946; // 'FILE'
    }
    constexpr bool IsInUse() const noexcept
    {
        return Flags & 0x0001;
    }

    constexpr bool IsDirectory() const noexcept
    {
        return Flags & 0x0002;
    }
};

using ATTRIBUTE_RECORD = struct ATTRIBUTE_RECORD
{
    ATTRIBUTE_TYPE_CODE TypeCode;
    ULONG RecordLength;
    UCHAR FormCode;
    UCHAR NameLength;
    USHORT NameOffset;
    USHORT Flags;
    USHORT Instance;

    union
    {
        struct
        {
            ULONG ValueLength;
            USHORT ValueOffset;
            UCHAR Reserved[2];
        } Resident;

        struct
        {
            LONGLONG LowestVcn;
            LONGLONG HighestVcn;
            USHORT DataRunOffset;
            USHORT CompressionSize;
            UCHAR Padding[4];
            ULONGLONG AllocatedLength;
            ULONGLONG FileSize;
            ULONGLONG ValidDataLength;
            ULONGLONG Compressed;
        } Nonresident;
    } Form;

    constexpr bool IsNonResident() const noexcept
    {
        return FormCode & 0x0001;
    }

    constexpr bool IsCompressed() const noexcept
    {
        return Flags & 0x0001;
    }

    constexpr bool IsSparse() const noexcept
    {
        return Flags & 0x8000;
    }

    ATTRIBUTE_RECORD* next() const noexcept
    {
        return ByteOffset<ATTRIBUTE_RECORD>(const_cast<ATTRIBUTE_RECORD*>(this), RecordLength);
    }

    static constexpr std::pair<ATTRIBUTE_RECORD*, ATTRIBUTE_RECORD*> bounds(FILE_RECORD* FileRecord, auto TotalLength) noexcept
    {
        return {
            ByteOffset<ATTRIBUTE_RECORD>(FileRecord, FileRecord->FirstAttributeOffset),
            ByteOffset<ATTRIBUTE_RECORD>(FileRecord, TotalLength)
        };
    }
};

using FILE_NAME = struct FILE_NAME
{
    ULONGLONG ParentDirectory : 48;
    ULONGLONG ParentSequence : 16;
    LONGLONG CreationTime;
    LONGLONG LastModificationTime;
    LONGLONG MftChangeTime;
    LONGLONG LastAccessTime;
    LONGLONG AllocatedLength;
    LONGLONG FileSize;
    ULONG FileAttributes;
    USHORT PackedEaSize;
    USHORT Reserved;
    UCHAR FileNameLength;
    UCHAR Flags;
    WCHAR FileName[1];

    constexpr bool IsShortNameRecord() const noexcept
    {
        return Flags == 0x02;
    }
};

using STANDARD_INFORMATION = struct STANDARD_INFORMATION
{
    FILETIME CreationTime;
    FILETIME LastModificationTime;
    FILETIME MftChangeTime;
    FILETIME LastAccessTime;
    ULONG FileAttributes;
};

bool FinderNtfsContext::LoadRoot(CItem* driveitem, BlockingQueue<CItem*>* queue)
{
    m_isLoaded = false;
    queue->WaitIfSuspended();

    // Trim off excess characters
    std::wstring volumePath = driveitem->GetPathLong();
    while (!volumePath.empty() && volumePath.back() == L'\\') volumePath.pop_back();
    if (!volumePath.empty() && volumePath[0] != L'\\' && volumePath[0] != L'/') volumePath.insert(0, L"\\\\.\\");

    // Open volume handle with FILE_FLAG_OVERLAPPED for asynchronous I/O
    const SmartPointer volumeHandle(CloseHandle, CreateFile(volumePath.c_str(), FILE_READ_DATA | FILE_READ_ATTRIBUTES | SYNCHRONIZE,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING,
        FILE_FLAG_NO_BUFFERING | FILE_FLAG_OVERLAPPED, nullptr));
    if (volumeHandle == INVALID_HANDLE_VALUE) return false;

    // Get volume information
    NTFS_VOLUME_DATA_BUFFER volumeInfo = {};
    ULONG bytesReturned;
    if (!DeviceIoControl(volumeHandle, FSCTL_GET_NTFS_VOLUME_DATA, nullptr, 0, &volumeInfo, sizeof(volumeInfo), &bytesReturned, nullptr)) return
        false;

    // Get MFT retrieval pointers
    const SmartPointer fileHandle(CloseHandle, CreateFile((volumePath + L"\\$MFT::$DATA").c_str(), FILE_READ_ATTRIBUTES | SYNCHRONIZE,
        FILE_SHARE_WRITE | FILE_SHARE_READ | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING,
        FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_NO_BUFFERING, nullptr));
    if (fileHandle == INVALID_HANDLE_VALUE) return false;

    std::vector<BYTE> dataRunsBuffer(sizeof(RETRIEVAL_POINTERS_BUFFER) + 32 * sizeof(LARGE_INTEGER));
    STARTING_VCN_INPUT_BUFFER input = {};
    bool pointersFetched = false;
    while ((pointersFetched = DeviceIoControl(fileHandle, FSCTL_GET_RETRIEVAL_POINTERS, &input, sizeof(input), dataRunsBuffer.data(),
        static_cast<DWORD>(dataRunsBuffer.size()), &bytesReturned, nullptr)) == 0 && GetLastError() == ERROR_MORE_DATA)
    {
        queue->WaitIfSuspended();
        dataRunsBuffer.resize(dataRunsBuffer.size() * 2);
    }
    if (!pointersFetched)
    {
        return false;
    }

    // Extract data run origins and cluster counts
    RETRIEVAL_POINTERS_BUFFER* retrievalBuffer = ByteOffset<RETRIEVAL_POINTERS_BUFFER>(dataRunsBuffer.data(), 0);
    const std::span extents(retrievalBuffer->Extents, retrievalBuffer->ExtentCount);
    std::vector<std::tuple<ULONGLONG, LONGLONG, ULONGLONG, ULONGLONG>> dataRuns(extents.size(), {});
    auto vcnStart = retrievalBuffer->StartingVcn.QuadPart;
    for (const auto [i, extent] : std::views::enumerate(extents))
    {
        const auto vcnNext = extent.NextVcn.QuadPart;
        dataRuns[i] = std::make_tuple(
            static_cast<ULONGLONG>(vcnStart),
            extent.Lcn.QuadPart,
            static_cast<ULONGLONG>(vcnNext - vcnStart), 0ull
        );
        vcnStart = vcnNext;
    }

    // Each data run owns its parse maps across pauses, with no shared record writes.
    struct RecordPartition
    {
        std::unordered_map<ULONGLONG, FileRecordBase> records;
        std::unordered_map<ULONGLONG, std::vector<FileRecordName>> children;
    };
    std::vector<RecordPartition> partitions(dataRuns.size());
    const auto runIndices = std::views::iota(size_t{}, dataRuns.size());
    std::atomic<bool> readFailed = false;
    const auto readRun = [&](const size_t runIndex)
    {
        // Page alignment satisfies FILE_FLAG_NO_BUFFERING for any sector size
        constexpr size_t bufferSize = 4ull * wds::Mi;
        constexpr size_t bufferAlignment = 4ull * wds::Ki;
        thread_local std::unique_ptr<UCHAR, decltype(&_aligned_free)> buffer(
            static_cast<UCHAR*>(_aligned_malloc(bufferSize, bufferAlignment)), &_aligned_free);

        auto& [runVcnStart, clusterStart, clusterCount, bytesReadFromRun] = dataRuns[runIndex];
        auto& partition = partitions[runIndex];

        // Enumerate over the data run in buffer-sized chunks
        ULONGLONG bytesToRead = clusterCount * volumeInfo.BytesPerCluster - bytesReadFromRun;
        LARGE_INTEGER fileOffset{ .QuadPart = static_cast<LONGLONG>(
            clusterStart * volumeInfo.BytesPerCluster + bytesReadFromRun) };
        thread_local SmartPointer event(CloseHandle, CreateEvent(nullptr, false, false, nullptr));
        const ULONGLONG mftRunOffset = runVcnStart * volumeInfo.BytesPerCluster;
        ULONG bytesRead = 0;
        for (; bytesToRead > 0;
            bytesReadFromRun += bytesRead, bytesToRead -= bytesRead, fileOffset.QuadPart += bytesRead)
        {
            if (readFailed || queue->IsPauseOrCancelRequested()) return;

            // Animate pacman
            driveitem->UpwardDrivePacman();

            // Set file pointer for synchronous read
            bytesRead = 0;
            const ULONG bytesThisRead = static_cast<ULONG>(std::min<ULONGLONG>(bytesToRead, bufferSize));
            OVERLAPPED overlapped = { .Offset = fileOffset.LowPart, .OffsetHigh = static_cast<DWORD>(fileOffset.HighPart), .hEvent = event };
            if (ReadFile(volumeHandle, buffer.get(), bytesThisRead, &bytesRead, &overlapped) == 0)
            {
                if (GetLastError() != ERROR_IO_PENDING)
                {
                    readFailed = true;
                    return;
                }

                DWORD waitResult;
                while ((waitResult = WaitForSingleObject(event, 50)) == WAIT_TIMEOUT)
                {
                    if (readFailed || queue->IsPauseOrCancelRequested()) break;
                }
                if (waitResult != WAIT_OBJECT_0) CancelIoEx(volumeHandle, &overlapped);
                if (!GetOverlappedResult(volumeHandle, &overlapped, &bytesRead, true))
                {
                    if (!queue->IsPauseOrCancelRequested()) readFailed = true;
                    return;
                }
            }
            if (bytesRead == 0)
            {
                readFailed = true;
                return;
            }

            for (ULONG offset = 0; offset + volumeInfo.BytesPerFileRecordSegment <= bytesRead; offset += volumeInfo.BytesPerFileRecordSegment)
            {
                // Process MFT record inline
                const auto fileRecord = ByteOffset<FILE_RECORD>(buffer.get(), offset);

                // Bounds check for fixup array access
                constexpr auto MFT_RECORD_SECTOR_SIZE = 512u;
                if (!fileRecord->IsValid() ||
                    fileRecord->UsaCount != volumeInfo.BytesPerFileRecordSegment / MFT_RECORD_SECTOR_SIZE + 1 ||
                    fileRecord->UsaOffset < sizeof(FILE_RECORD) || fileRecord->UsaOffset % sizeof(USHORT) != 0 ||
                    fileRecord->UsaOffset + sizeof(USHORT) * fileRecord->UsaCount >
                        volumeInfo.BytesPerFileRecordSegment ||
                    fileRecord->FirstAttributeOffset >= volumeInfo.BytesPerFileRecordSegment) continue;

                // Apply fixup (NTFS MFTs always have a 512 byte sector size)
                constexpr auto wordsPerSector = MFT_RECORD_SECTOR_SIZE / sizeof(USHORT);
                const auto recordWords = reinterpret_cast<PUSHORT>(ByteOffset<UCHAR>(buffer.get(), offset));
                bool skipRecord = false;
                if (fileRecord->UsaCount > 0)
                {
                    const std::span fixupSpan(ByteOffset<USHORT>(fileRecord, fileRecord->UsaOffset), fileRecord->UsaCount);
                    const auto usn = fixupSpan[0];
                    for (const auto [idx, fixup] : std::views::enumerate(fixupSpan.subspan(1)))
                    {
                        const auto sectorEnd = recordWords + (idx + 1) * wordsPerSector - 1;
                        if (*sectorEnd == usn) *sectorEnd = fixup;
                        else { skipRecord = true; break; }
                    }
                }

                // Skip if corrupt record detected
                if (skipRecord) [[unlikely]] continue;

                // Only process records that have valid headers and are in use
                if (!fileRecord->IsValid() || !fileRecord->IsInUse()) continue;
                const auto currentRecord = (mftRunOffset + bytesReadFromRun + offset) / volumeInfo.BytesPerFileRecordSegment;
                const auto baseRecordIndex = fileRecord->BaseFileRecordNumber > 0 ? fileRecord->BaseFileRecordNumber : currentRecord;
                const ULONGLONG baseRecordSequence = fileRecord->BaseFileRecordNumber > 0 ?
                    fileRecord->BaseFileRecordSequence : fileRecord->SequenceNumber;
                const auto baseFileReference = baseRecordIndex | (baseRecordSequence << 48);

                auto& baseRecord = partition.records[baseRecordIndex];

                for (auto [curAttribute, endAttribute] = ATTRIBUTE_RECORD::bounds(fileRecord, volumeInfo.BytesPerFileRecordSegment); curAttribute <
                    endAttribute && curAttribute->TypeCode != AttributeEnd && curAttribute->RecordLength > 0; curAttribute = curAttribute->next())
                {
                    if (curAttribute->TypeCode == AttributeStandardInformation)
                    {
                        if (curAttribute->IsNonResident()) continue;
                        const auto si = ByteOffset<STANDARD_INFORMATION>(curAttribute, curAttribute->Form.Resident.ValueOffset);
                        baseRecord.HasStandardInfo = true;
                        baseRecord.LastModifiedTime = si->LastModificationTime;
                        baseRecord.Attributes |= si->FileAttributes;
                        if (fileRecord->IsDirectory()) baseRecord.Attributes |= FILE_ATTRIBUTE_DIRECTORY;
                        if (baseRecord.Attributes == 0) baseRecord.Attributes = FILE_ATTRIBUTE_NORMAL;
                    }
                    else if (curAttribute->TypeCode == AttributeFileName)
                    {
                        if (curAttribute->IsNonResident()) continue;
                        const auto fn = ByteOffset<FILE_NAME>(curAttribute, curAttribute->Form.Resident.ValueOffset);
                        // FileName is not null-terminated so compare by length and characters
                        if (fn->IsShortNameRecord() ||
                            (fn->FileNameLength == 1 && fn->FileName[0] == L'.') ||
                            (fn->FileNameLength == 2 && fn->FileName[0] == L'.' && fn->FileName[1] == L'.')) continue;

                        auto& children = partition.children.try_emplace(fn->ParentDirectory).first->second;
                        children.emplace_back(std::wstring{ fn->FileName, fn->FileNameLength }, baseFileReference);
                    }
                    else if (curAttribute->TypeCode == AttributeData)
                    {
                        // Named data streams
                        if (const WCHAR* streamName = ByteOffset<WCHAR>(curAttribute, curAttribute->NameOffset); curAttribute->NameLength > 0)
                        {
                            const std::wstring_view name(streamName, curAttribute->NameLength);

                            // WofCompressedData: correct physical size for WOF-compressed files
                            if (name == L"WofCompressedData" &&
                                (!curAttribute->IsNonResident() || curAttribute->Form.Nonresident.LowestVcn == 0))
                            {
                                baseRecord.PhysicalSize = curAttribute->IsNonResident() ?
                                    curAttribute->Form.Nonresident.AllocatedLength :
                                    (curAttribute->Form.Resident.ValueLength + 7) & ~7;
                                baseRecord.HasWofData = true;
                            }

                            // Dropbox (and compatible tools) set this stream to mark items as ignored
                            if (COptions::ExcludeDropboxIgnored && name == L"com.dropbox.ignored" &&
                                (!curAttribute->IsNonResident() || curAttribute->Form.Nonresident.LowestVcn == 0))
                            {
                                baseRecord.HasIgnoredStream = (curAttribute->IsNonResident() ?
                                    curAttribute->Form.Nonresident.FileSize : curAttribute->Form.Resident.ValueLength) != 0;
                            }

                            continue;
                        }

                        // Default stream processing
                        if (curAttribute->IsNonResident())
                        {
                            if (curAttribute->Form.Nonresident.LowestVcn != 0) continue;
                            baseRecord.HasData = true;
                            baseRecord.LogicalSize = curAttribute->Form.Nonresident.FileSize;

                            if (const ULONGLONG physSize = (curAttribute->IsCompressed() || curAttribute->IsSparse()) ?
                                curAttribute->Form.Nonresident.Compressed :
                                    curAttribute->Form.Nonresident.AllocatedLength;
                                !baseRecord.HasWofData && physSize > 0)
                            {
                                baseRecord.PhysicalSize = physSize;
                            }
                        }
                        else
                        {
                            baseRecord.HasData = true;
                            baseRecord.LogicalSize = curAttribute->Form.Resident.ValueLength;
                            if (!baseRecord.HasWofData)
                                baseRecord.PhysicalSize = (curAttribute->Form.Resident.ValueLength + 7) & ~7;
                        }
                    }
                    else if (curAttribute->TypeCode == AttributeReparsePoint)
                    {
                        if (curAttribute->IsNonResident()) continue;
                        const auto fn = ByteOffset<Finder::REPARSE_DATA_BUFFER>(curAttribute, curAttribute->Form.Resident.ValueOffset);
                        baseRecord.ReparsePointTag = fn->ReparseTag;

                        // Treat WOF files as compressed
                        if (fn->ReparseTag == IO_REPARSE_TAG_WOF)
                        {
                            baseRecord.Attributes |= FILE_ATTRIBUTE_COMPRESSED;
                        }

                        if (Finder::IsJunction(*fn))
                        {
                            baseRecord.ReparsePointTag = IO_REPARSE_TAG_JUNCTION_POINT;
                        }
                    }
                }
            }
        }
    };
    do
    {
        std::for_each(std::execution::par, runIndices.begin(), runIndices.end(), readRun);
        // Only the registered worker reports idle after all parallel reads have drained.
        queue->WaitIfSuspended();
        if (readFailed)
        {
            VTRACE(L"ERROR: Failed to read MFT data.");
            return false;
        }
    }
    while (std::ranges::any_of(dataRuns, [&](const auto& run)
    {
        return std::get<3>(run) < std::get<2>(run) * volumeInfo.BytesPerCluster;
    }));

    // Adopt the first run's maps outright, since an unfragmented MFT has no other runs to combine.
    m_baseFileRecordMap.clear();
    m_parentToChildMap.clear();
    if (!partitions.empty())
    {
        m_baseFileRecordMap.swap(partitions.front().records);
        m_parentToChildMap.swap(partitions.front().children);
    }

    // Transfer unique nodes and combine extension records after all readers have joined.
    size_t recordCount = m_baseFileRecordMap.size();
    for (const auto& partition : partitions) recordCount += partition.records.size();
    m_baseFileRecordMap.reserve(recordCount);
    for (auto& partition : partitions)
    {
        m_baseFileRecordMap.merge(partition.records);
        for (const auto& [index, record] : partition.records)
        {
            auto& merged = m_baseFileRecordMap.at(index);
            if (record.HasStandardInfo) merged.LastModifiedTime = record.LastModifiedTime;
            if (record.HasData) merged.LogicalSize = record.LogicalSize;
            if (record.HasWofData || !merged.HasWofData && record.HasData)
                merged.PhysicalSize = record.PhysicalSize;
            merged.Attributes |= record.Attributes;
            if (record.ReparsePointTag != 0) merged.ReparsePointTag = record.ReparsePointTag;
            merged.HasIgnoredStream |= record.HasIgnoredStream;
            merged.HasWofData |= record.HasWofData;
            merged.HasData |= record.HasData;
            merged.HasStandardInfo |= record.HasStandardInfo;
        }

        m_parentToChildMap.merge(partition.children);
        for (auto& [index, children] : partition.children)
        {
            auto& merged = m_parentToChildMap.at(index);
            merged.append_range(children | std::views::as_rvalue);
        }

        // Release each run's storage as soon as it has been combined.
        partition = {};
    }

    // Verify root node exists
    if (!m_parentToChildMap.contains(NtfsNodeRoot))
    {
        return false;
    }

    driveitem->SetIndex(NtfsNodeRoot);
    m_isLoaded = true;
    return true;
}

bool FinderNtfs::FindNext()
{
    if (m_recordIterator == m_recordIteratorEnd) return false;
    m_index = m_recordIterator->FileReference & FinderNtfsContext::NtfsRecordMask;
    const auto it = m_master->m_baseFileRecordMap.find(m_index);
    if (it == m_master->m_baseFileRecordMap.end()) return false;
    m_currentRecord = &it->second;
    m_currentRecordName = &(*m_recordIterator);
    ++m_recordIterator;

    return true;
}

bool FinderNtfs::FindFile(const CItem* item)
{
    m_base = item->GetPath();
    const auto result = m_master->m_parentToChildMap.find(item->GetIndex() & FinderNtfsContext::NtfsRecordMask);
    if (result == m_master->m_parentToChildMap.end()) return false;
    m_recordIteratorEnd = result->second.end();
    m_recordIterator = result->second.begin();
    return FindNext();
}

std::wstring FinderNtfs::GetFilePath() const
{
    // Get full path to folder or file
    std::wstring path = m_base;
    if (!path.ends_with(L'\\')) path += L'\\';
    path += GetFileName();

    // Strip special dos chars
    if (path.starts_with(s_dosUNCPath)) return L"\\\\" + path.substr(s_dosUNCPath.length());
    if (path.starts_with(s_dosPath)) return path.substr(s_dosPath.length());
    return path;
}
