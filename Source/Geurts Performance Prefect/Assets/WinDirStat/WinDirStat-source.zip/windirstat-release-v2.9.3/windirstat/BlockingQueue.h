﻿// WinDirStat - Windows Directory Statistics
// Copyright © WinDirStat Team
//
// SPDX-License-Identifier: GPL-3.0-or-later
// Distributed WITHOUT ANY WARRANTY; see LICENSE.md for details.

#pragma once

#include "pch.h"

template <typename T>
class BlockingQueue final
{
    std::mutex m_threadMutex;
    std::vector<std::jthread> m_threads;
    std::deque<T> m_queue;
    std::mutex m_mutex;
    std::condition_variable m_pushed;
    std::condition_variable m_waiting;
    unsigned int m_totalWorkerThreads = 1;
    unsigned int m_workersWaiting = 0;
    unsigned int m_stopReason = 0;
    bool m_started = false;
    bool m_suspended = false;
    bool m_cancelled = false;
    bool m_exitOnAllIdle = true;

    bool AllThreadsIdling() const noexcept
    {
        return m_totalWorkerThreads == m_workersWaiting;
    }

public:
    BlockingQueue(const BlockingQueue&) = delete;
    BlockingQueue(BlockingQueue&&) = delete;
    BlockingQueue& operator=(const BlockingQueue&) = delete;
    BlockingQueue& operator=(BlockingQueue&&) = delete;
    ~BlockingQueue() = default;
    BlockingQueue(const bool exitOnAllIdle = true) : m_exitOnAllIdle(exitOnAllIdle) {}

    void ThreadWrapper(const std::function<void()>& callback)
    {
        try
        {
            callback();
        }
        catch (std::exception&)
        {
            // Exception caught from a long-running task or cancellation
            std::scoped_lock lock(m_mutex);
            m_workersWaiting++;
            m_waiting.notify_all();
        }
    }

    void StartThreads(const unsigned int workerThreads, const std::function<void()>& callback)
    {
        ResetQueue(workerThreads, false);
        std::scoped_lock threadLock(m_threadMutex);

        for ([[maybe_unused]] const auto _ : std::views::iota(0u, m_totalWorkerThreads))
        {
            m_threads.emplace_back(&BlockingQueue::ThreadWrapper, this, callback);
        }
    }

    void Push(T const& value)
    {
        // Push another entry onto the queue
        std::scoped_lock lock(m_mutex);
        m_queue.push_front(value);
        m_pushed.notify_one();
    }

    void Push(T&& value)
    {
        // Push another entry onto the queue (move semantics)
        std::scoped_lock lock(m_mutex);
        m_queue.push_front(std::move(value));
        m_pushed.notify_one();
    }

    std::optional<T> Pop()
    {
        // Record that the worker is waiting for an item until
        // the queue has something in it and we are not suspended
        std::unique_lock lock(m_mutex);
        m_workersWaiting++;
        m_waiting.notify_all();

        // Check if all workers are waiting and queue is empty - time to exit
        if (m_started && AllThreadsIdling() && m_queue.empty() && m_exitOnAllIdle)
        {
            m_cancelled = true;
            m_pushed.notify_all();
            return std::nullopt;
        }

        m_pushed.wait(lock, [&]
        {
            return !m_suspended && !m_queue.empty() || m_cancelled;
        });

        if (m_cancelled)
        {
            // Abort and signal other threads
            m_pushed.notify_all();
            return std::nullopt;
        }

        // Worker now has something to work on so pop it off the queue
        m_workersWaiting--;
        m_started = true;
        T i = std::move(m_queue.front());
        m_queue.pop_front();
        return i;
    }

    void PushIfNotQueued(T const& value)
    {
        std::scoped_lock lock(m_mutex);
        if (std::ranges::contains(m_queue, value)) return;
        m_queue.push_back(value);
        m_pushed.notify_one();
    }

    void PushIfNotQueued(T&& value)
    {
        std::scoped_lock lock(m_mutex);
        if (std::ranges::contains(m_queue, value)) return;
        m_queue.push_back(std::move(value));
        m_pushed.notify_one();
    }

    bool IsPauseOrCancelRequested()
    {
        std::scoped_lock lock(m_mutex);
        return m_suspended || m_cancelled;
    }

    void WaitIfSuspended()
    {
        // wait until not suspended or it's cancelled
        std::unique_lock lock(m_mutex);
        if (!m_suspended && !m_cancelled) return;
        m_workersWaiting++;
        m_waiting.notify_all();
        m_waiting.wait(lock, [&]
        {
            return !m_suspended || m_cancelled;
        });
        m_workersWaiting--;

        // if cancelled then throw to terminate current task
        if (m_cancelled)
        {
            throw std::exception(__FUNCTION__);
        }
    }

    int WaitForCompletion()
    {
        // Wait for all worker threads to be idled or cancelled
        std::unique_lock lock(m_mutex);
        m_waiting.wait(lock, [&]
        {
            return m_started && !m_suspended && AllThreadsIdling() && m_queue.empty() || m_cancelled;
        });

        return m_stopReason;
    }

    void CancelThreadIo()
    {
        std::scoped_lock threadLock(m_threadMutex);
        for (auto& thread : m_threads)
        {
            if (thread.joinable())
                CancelSynchronousIo(thread.native_handle());
        }
    }

    void JoinThreads()
    {
        std::scoped_lock threadLock(m_threadMutex);
        for (auto& thread : m_threads)
        {
            if (thread.joinable()) thread.join();
        }
    }

    void CancelExecution(const int stopReason = -1)
    {
        // Start cancellation process
        if (std::scoped_lock lock(m_mutex); true)
        {
            if (stopReason != -1) m_stopReason = stopReason;
            m_cancelled = true;
            m_waiting.notify_all();
            m_pushed.notify_all();
        }

        // Wait for threads to complete
        JoinThreads();

        // Keep completion observable until StartThreads resets the queue.
        std::scoped_lock lock(m_threadMutex, m_mutex);
        m_threads.clear();
        m_queue.clear();
    }

    void SuspendExecution(const bool clearQueue = false)
    {
        std::unique_lock lock(m_mutex);
        if (!m_started) return;
        m_suspended = true;
        m_waiting.notify_all();
        m_waiting.wait(lock, [&]
        {
            return AllThreadsIdling();
        });
        if (clearQueue) m_queue.clear();
    }

    void ResumeExecution()
    {
        std::scoped_lock lock(m_mutex);
        m_suspended = false;
        m_waiting.notify_all();
        m_pushed.notify_all();
    }

    void ResetQueue(const int totalWorkerThreads, const bool clearQueue = true)
    {
        std::scoped_lock lock(m_threadMutex, m_mutex);
        m_workersWaiting = 0;
        m_suspended = false;
        m_started = false;
        m_cancelled = false;
        m_stopReason = 0;
        m_totalWorkerThreads = totalWorkerThreads;
        m_threads.clear();
        m_threads.reserve(m_totalWorkerThreads);
        if (clearQueue) m_queue.clear();
    }
};

template<typename T>
class SingleConsumerQueue final
{
    struct Node
    {
        std::atomic<Node*> next{ nullptr };
        T data{};

        Node() = default;

        template<typename U>
        explicit Node(U&& value) : data(std::forward<U>(value)) {}
    };

    alignas(std::hardware_destructive_interference_size) std::atomic<Node*> m_head;
    alignas(std::hardware_destructive_interference_size) Node* m_tail;

public:
    SingleConsumerQueue()
    {
        Node* dummy = new Node();
        m_tail = dummy;
        m_head.store(dummy, std::memory_order_relaxed);
    }

    ~SingleConsumerQueue()
    {
        for (T tmp; pop(tmp);) {}
        delete m_tail;
    }

    template<typename U>
    void push(U&& item) noexcept
    {
        Node* node = new Node(std::forward<U>(item));
        Node* prev = m_head.exchange(node, std::memory_order_release);
        prev->next.store(node, std::memory_order_release);
    }

    bool pop(T& item) noexcept(std::is_nothrow_move_assignable_v<T>)
    {
        Node* t = m_tail;
        Node* next = t->next.load(std::memory_order_acquire);

        if (next == nullptr)
        {
            if (m_head.load(std::memory_order_acquire) == t)
                return false;

            while ((next = t->next.load(std::memory_order_acquire)) == nullptr)
            {
                std::this_thread::yield();
            }
        }

        item = std::move(next->data);
        m_tail = next;

        delete t;
        return true;
    }

    // Only valid for consumer
    bool empty() const noexcept
    {
        if (m_tail->next.load(std::memory_order_acquire) != nullptr) return false;
        return m_head.load(std::memory_order_acquire) == m_tail;
    }

    // Clear out queue (unsafe with concurrent producers)
    void clear() noexcept
    {
        for (T tmp; pop(tmp);) {}

        const Node* old = m_tail; // One dummy remains
        Node* dummy = new Node();

        m_tail = dummy;
        m_head.store(dummy, std::memory_order_release);

        delete old;
    }
};
