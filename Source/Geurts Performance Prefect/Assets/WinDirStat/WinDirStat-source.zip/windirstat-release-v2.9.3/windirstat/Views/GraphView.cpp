﻿// WinDirStat - Windows Directory Statistics
// Copyright © WinDirStat Team
//
// SPDX-License-Identifier: GPL-3.0-or-later
// Distributed WITHOUT ANY WARRANTY; see LICENSE.md for details.

#include "pch.h"
#include "FileTreeView.h"
#include "GraphView.h"

void CGraphView::SuspendRecalculationDrawing(const bool suspend)
{
    if (suspend == m_drawingSuspended) return;

    if (suspend)
    {
        // Refresh scans can remove items immediately after this call. Drop all
        // cached item pointers and renderer geometry before mutation starts.
        ResetInputState();
        OnSuspending();
        Inactivate();
    }

    m_drawingSuspended = suspend;
    if (!suspend) Invalidate();
}

bool CGraphView::PreCreateWindow(CREATESTRUCT& cs)
{
    if (!CWinDirStatPane::PreCreateWindow(cs)) return false;

    const wchar_t* className = GetWindowClassName();
    WNDCLASSW wc{};
    if (!GetClassInfoW(GetAppInstance(), className, &wc))
    {
        if (!GetClassInfoW(GetAppInstance(), cs.lpszClass, &wc)) return false;
        wc.hbrBackground = nullptr;
        wc.lpszClassName = className;
        if (RegisterClassW(&wc) == 0 && GetLastError() != ERROR_CLASS_ALREADY_EXISTS)
            return false;
    }

    cs.lpszClass = className;
    return true;
}

void CGraphView::DrawEmptyView()
{
    CClientDC dc(this);
    PaintEmptyView(&dc);
}

void CGraphView::TrimRenderCache()
{
    ResetInputState();
    ClearHover();
    m_bitmap.Reset();
    m_dimmed.Reset();
    m_dimmedSize = { 0, 0 };
    ClearVisualizationLayout();
    OnRenderCacheTrimmed();
}

void CGraphView::PaintEmptyView(CDC* pDC)
{
    Inactivate();
    if (DrawDimmedView(pDC)) return;

    const CRect rect = GetClientRect();
    pDC->FillSolidRect(rect, GetBackgroundColor());
    DrawEmptyPlaceholder(pDC, rect);
}

bool CGraphView::IsReadyToDraw() const
{
    const CItem* root = CWinDirStatModel::Get()->GetRootItem();
    return root != nullptr && root->IsDone() && !m_drawingSuspended;
}

bool CGraphView::PrepareDrawing(CDC* /*pDC*/, CRect& rect)
{
    assert(m_size == rect.Size());
    assert(rect.TopLeft() == CPoint(0, 0));
    return !rect.IsEmpty();
}

bool CGraphView::CreateRenderBitmap(CDC* pDC, const CSize size)
{
    return m_bitmap.CreateCompatible(pDC, size.cx, size.cy);
}

void CGraphView::OnDraw(CDC* pDC)
{
    if (!IsReadyToDraw())
    {
        PaintEmptyView(pDC);
        return;
    }

    CRect rect = GetClientRect();
    if (!PrepareDrawing(pDC, rect)) return;

    CDC memoryDc(pDC);
    if (!memoryDc)
    {
        DiscardRenderCache();
        pDC->FillSolidRect(rect, GetBackgroundColor());
        return;
    }

    if (!IsDrawn())
    {
        CWaitCursor waitCursor;
        if (m_dimmed.m_hObject != nullptr && m_dimmedSize == rect.Size())
        {
            // Rendering is synchronous, so the dimmed bitmap can be recycled
            // instead of briefly retaining two full-window device bitmaps.
            m_bitmap.Attach(m_dimmed.Detach());
            m_dimmedSize = { 0, 0 };
        }
        else
        {
            // Do not retain a stale full-window bitmap while allocating its
            // differently sized replacement.
            m_dimmed.Reset();
            m_dimmedSize = { 0, 0 };
            if (!CreateRenderBitmap(pDC, rect.Size()))
            {
                DiscardRenderCache();
                pDC->FillSolidRect(rect, GetBackgroundColor());
                return;
            }
        }

        GdiObjectSelection selectBitmap(&memoryDc, &m_bitmap);
        RenderVisualization(&memoryDc, rect);
        m_dimmed.Reset();
        m_dimmedSize = { 0, 0 };
    }

    // Present the cached graph and its overlays together to avoid highlight flicker.
    CBufferedDC frameDc(*pDC, this);
    {
        GdiObjectSelection selectBitmap(&memoryDc, &m_bitmap);
        frameDc.BitBlt(rect.left, rect.top, rect.Width(), rect.Height(),
            &memoryDc, 0, 0, SRCCOPY);
    }

    DrawHighlights(&frameDc);
}

bool CGraphView::DrawDimmedView(CDC* pDC)
{
    if (m_dimmed.m_hObject == nullptr) return false;

    const CRect clientRect = GetClientRect();
    CDC memoryDc(pDC);
    if (!memoryDc)
    {
        pDC->FillSolidRect(clientRect, GetBackgroundColor());
        return true;
    }

    GdiObjectSelection selectBitmap(&memoryDc, &m_dimmed);
    pDC->BitBlt(clientRect.left, clientRect.top, m_dimmedSize.cx, m_dimmedSize.cy,
        &memoryDc, 0, 0, SRCCOPY);

    if (clientRect.Width() > m_dimmedSize.cx)
    {
        CRect fill = clientRect;
        fill.left += m_dimmedSize.cx;
        pDC->FillSolidRect(fill, GetBackgroundColor());
    }
    if (clientRect.Height() > m_dimmedSize.cy)
    {
        CRect fill = clientRect;
        fill.top += m_dimmedSize.cy;
        pDC->FillSolidRect(fill, GetBackgroundColor());
    }
    return true;
}

void CGraphView::DrawHighlights(CDC* pDC)
{
    const ScopedDcState dcState(pDC);
    switch (CMainFrame::Get()->GetLogicalFocus())
    {
    case LF_DUPELIST:
    case LF_TOPLIST:
    case LF_FILETREE:
    case LF_SEARCHLIST:
        DrawSelection(pDC);
        break;
    case LF_EXTLIST:
        DrawHighlightExtension(pDC);
        break;
    default:
        break;
    }
    if (m_hoverItem != nullptr) DrawHover(pDC);
}

bool CGraphView::IsExtensionHighlighted(const CItem* item)
{
    const CWinDirStatModel* model = CWinDirStatModel::Get();
    if (!item->TmiIsLeaf()) return false;

    if (model->IsHighlightUnregistered())
    {
        return item->IsTypeOrFlag(IT_FILE)
            && model->GetHighlightExtensions().contains(item->GetExtension());
    }
    return item->HasExtension(model->GetHighlightExtension());
}

const CItem* CGraphView::GetDisplayItem(const CItem* item)
{
    return item->IsTypeOrFlag(ITF_HARDLINK) ? item->FindHardlinksIndexItem() : item;
}

void CGraphView::RenderHighlightRectangle(CDC* pDC, CRect rect, const bool hover)
{
    if (rect.IsEmpty()) return;

    const COLORREF color = hover ? DarkMode::SystemColor(COLOR_WINDOWTEXT) : COptions::TreeMapHighlightColor;
    const int scale = std::max(1, MulDiv(pDC->GetDeviceCaps(LOGPIXELSX), GetFontSizePercent(),
        USER_DEFAULT_SCREEN_DPI * 100));
    if (!hover && std::min(rect.Width(), rect.Height()) <= 2 * scale)
    {
        pDC->FillSolidRect(rect, color);
        return;
    }
    const int thickness = (hover ? 1 : 2) * scale;
    for (int inset = 0; inset < thickness && !rect.IsEmpty(); ++inset)
    {
        pDC->SetDCBrushColor(!hover && inset < scale ? CColorSpace::GetContrastingColor(color) : color);
        FrameRect(pDC->Handle(), &rect, static_cast<HBRUSH>(GetStockObject(DC_BRUSH)));
        rect.Deflate(1, 1);
    }
}

CItem* CGraphView::ResolveItemAtPoint(CPoint point, const bool isScreenCoords)
{
    const CItem* root = CWinDirStatModel::Get()->GetRootItem();
    if (root == nullptr || !root->IsDone() || !HasValidLayout()) return nullptr;

    if (isScreenCoords) point = ToClient(point);
    if (!GetClientRect().Contains(point)) return nullptr;
    return FindItemAtPoint(point);
}

void CGraphView::OnSize(UINT /*nType*/, const int cx, const int cy)
{
    const CSize size(cx, cy);
    if (size == m_size) return;

    OnBeforeSizeChanged();
    ResetInputState();
    Inactivate();
    m_size = size;
    if (!m_drawingSuspended) Invalidate();
}

void CGraphView::OnLButtonDblClk(UINT /*nFlags*/, const CPoint point)
{
    if (CItem* item = ResolveItemAtPoint(point)) DrillDown(item);
}

void CGraphView::OnLButtonDown(UINT /*nFlags*/, const CPoint point)
{
    if (CItem* item = ResolveItemAtPoint(point))
    {
        CWinDirStatModel::Get()->ClearReselectChildStack();
        NotifyOtherPanes(MODEL_CHANGE_SELECTION_ACTION, item);
    }
}

void CGraphView::DrillDown(CItem* item)
{
    ClearHover();
    CWinDirStatModel* model = CWinDirStatModel::Get();
    CItem* target = item == model->GetZoomItem()
        ? model->GetRootItem()
        : (item->IsTypeOrFlag(IT_FILE) ? item->GetParent() : item);

    if (target != nullptr && target != model->GetZoomItem()) model->SetZoomItem(target);
}

void CGraphView::OnMButtonDown(UINT /*nFlags*/, const CPoint point)
{
    ResetZoom(point);
}

void CGraphView::ResetZoom(const CPoint point)
{
    if (ResolveItemAtPoint(point))
        GetMainWindow()->SendMessage(WM_COMMAND, ID_TREEMAP_ZOOMRESET);
}

void CGraphView::Inactivate(const bool clearLayout)
{
    ClearHover();
    if (clearLayout) ClearVisualizationLayout();
    if (m_bitmap.m_hObject == nullptr) return;

    m_dimmed.Reset();
    m_dimmed.Attach(m_bitmap.Detach());
    m_dimmedSize = m_size;

    CClientDC dc(this);
    CDC memoryDc(&dc);
    if (!memoryDc) return;
    GdiObjectSelection selectBitmap(&memoryDc, &m_dimmed);
    constexpr BLENDFUNCTION blendFunction{
        .BlendOp = AC_SRC_OVER,
        .BlendFlags = 0,
        .SourceConstantAlpha = 175,
        .AlphaFormat = 0,
    };
    memoryDc.FillSolidRect(CRect(0, 0, m_dimmedSize.cx, m_dimmedSize.cy), GetBackgroundColor());
    memoryDc.AlphaBlend(0, 0, m_dimmedSize.cx, m_dimmedSize.cy, &dc,
        0, 0, m_dimmedSize.cx, m_dimmedSize.cy, blendFunction);
}

void CGraphView::DiscardRenderCache(const bool clearLayout)
{
    ClearHover();
    m_bitmap.Reset();
    if (clearLayout) ClearVisualizationLayout();
}

void CGraphView::EmptyView()
{
    ClearHover();
    ResetInputState();
    ClearVisualizationLayout();
    m_bitmap.Reset();
    m_dimmed.Reset();
    m_dimmedSize = { 0, 0 };
    OnViewEmptied();
}

void CGraphView::OnSetFocus(WindowRef /*pOldWnd*/)
{
    CMainFrame::Get()->GetFileTreeView()->SetFocus();
}

void CGraphView::OnUpdate(CWnd* sender, const MODEL_CHANGE change, CItem* item)
{
    if (!CWinDirStatModel::Get()->IsRootDone())
    {
        if (IsWindowVisible()) Inactivate();
        else TrimRenderCache();
    }

    switch (change)
    {
    case MODEL_CHANGE_NEW_ROOT:
        EmptyView();
        CWinDirStatPane::OnUpdate(sender, change, item);
        CMainFrame::Get()->UpdatePaneText();
        break;

    case MODEL_CHANGE_SELECTION_ACTION:
    case MODEL_CHANGE_SELECTION_REFRESH:
    case MODEL_CHANGE_SELECTION_STYLE:
    case MODEL_CHANGE_EXTENSION_SELECTION:
        CWinDirStatPane::OnUpdate(sender, change, item);
        CMainFrame::Get()->UpdatePaneText();
        break;

    case MODEL_CHANGE_TREEMAP_STYLE:
    case MODEL_CHANGE_ZOOM:
    case MODEL_CHANGE_NONE:
    case MODEL_CHANGE_SIZE_MODE:
        OnVisualizationChanged(change);
        CWinDirStatPane::OnUpdate(sender, change, item);
        break;

    default:
        break;
    }
}

void CGraphView::OnVisualizationChanged(const MODEL_CHANGE change)
{
    ResetInputState();
    if (!IsWindowVisible())
    {
        TrimRenderCache();
        return;
    }
    Inactivate(!CanReuseVisualizationLayout(change));
}

void CGraphView::ResetInputState()
{
    if (m_trackingMouse && Handle())
    {
        TRACKMOUSEEVENT trackMouseEvent{
            .cbSize = sizeof(TRACKMOUSEEVENT),
            .dwFlags = TME_CANCEL | TME_LEAVE,
            .hwndTrack = m_hWnd,
        };
        TrackMouseEvent(&trackMouseEvent);
    }
    m_trackingMouse = false;
    m_navigationWheelDeltaRemainder = 0;
    m_zoomWheelDeltaRemainder = 0;
    OnInputStateReset();
}

HoverInfo CGraphView::GetHoverInfo() const
{
    if (!IsWindowVisible()) return {};

    const auto point = GetClientCursorPos();
    if (!point || !GetClientRect().Contains(*point)) return {};
    return { m_paneTextOverride, m_paneSizeOverride };
}

void CGraphView::ClearHover()
{
    const bool hadHover = m_hoverItem != nullptr;
    m_hoverItem = nullptr;
    if (hadHover && Handle() != nullptr) Invalidate(false);
    if (UpdateHoverDetails(nullptr, true) && CMainFrame::Get() != nullptr)
        CMainFrame::Get()->UpdatePaneText();
}

std::span<const UINT> CGraphView::GetPersistentContextCommands() const
{
    static constexpr std::array<UINT, 14> commands{
        ID_TREEMAP_ZOOMIN,
        ID_TREEMAP_ZOOMOUT,
        ID_TREEMAP_SELECT_PARENT,
        ID_TREEMAP_RESELECT_CHILD,
        ID_VIEW_GROUP_TYPES,
        ID_TREEMAP_SHOW_EXTENSIONS,
        ID_TREEMAP_LOGICAL_SIZE,
        ID_TREEMAP_PHYSICAL_SIZE,
        ID_VIEW_GRAPH_PRESET_CLASSIC,
        ID_VIEW_GRAPH_PRESET_CALM,
        ID_VIEW_GRAPH_PRESET_FLAT,
        ID_VIEW_GRAPH_PRESET_PASTEL,
        ID_VIEW_GRAPH_PRESET_HIGH_CONTRAST,
        ID_VIEW_GRAPH_PRESET_CUSTOM,
    };
    return commands;
}

void CGraphView::OnContextMenu(WindowRef /*pWnd*/, const CPoint point)
{
    ShowGraphContextMenu(ResolveItemAtPoint(point, true), point,
        GetPersistentContextCommands());
}

void CGraphView::OnMouseMove(UINT /*nFlags*/, const CPoint point)
{
    if (!m_trackingMouse)
    {
        TRACKMOUSEEVENT trackMouseEvent{
            .cbSize = sizeof(TRACKMOUSEEVENT),
            .dwFlags = TME_LEAVE,
            .hwndTrack = m_hWnd,
        };
        m_trackingMouse = TrackMouseEvent(&trackMouseEvent) != 0;
    }

    const CItem* item = ResolveItemAtPoint(point);
    const bool itemChanged = item != m_hoverItem;
    if (itemChanged) m_hoverItem = item;
    const bool detailsChanged = UpdateHoverDetails(item, itemChanged);
    if (itemChanged || detailsChanged) Invalidate(false);
    if (detailsChanged) CMainFrame::Get()->UpdatePaneText();
}

bool CGraphView::UpdateHoverDetails(const CItem* item, const bool itemChanged)
{
    if (!itemChanged) return false;
    const std::wstring path = item == nullptr ? std::wstring{} : item->GetPath();
    const ULONGLONG size = item == nullptr ? 0 : item->TmiGetSize();
    if (path == m_paneTextOverride && size == m_paneSizeOverride) return false;

    m_paneTextOverride = path;
    m_paneSizeOverride = size;
    return true;
}

void CGraphView::OnMouseLeave()
{
    m_trackingMouse = false;
    ClearHover();
}

bool CGraphView::OnMouseWheel(const UINT nFlags, const short zDelta, const CPoint pt)
{
    const CMainFrame* frame = CMainFrame::Get();
    if (frame == nullptr) return CWinDirStatPane::OnMouseWheel(nFlags, zDelta, pt);

    const bool zoomCommand = (nFlags & MK_CONTROL) != 0;
    int& remainder = zoomCommand
        ? m_zoomWheelDeltaRemainder : m_navigationWheelDeltaRemainder;
    const int totalDelta = remainder + static_cast<int>(zDelta);
    const int clicks = totalDelta / WHEEL_DELTA;
    remainder = totalDelta % WHEEL_DELTA;
    if (clicks == 0) return true;

    const UINT commandUp = (nFlags & MK_CONTROL)
        ? ID_TREEMAP_ZOOMIN : ID_TREEMAP_SELECT_PARENT;
    const UINT commandDown = (nFlags & MK_CONTROL)
        ? ID_TREEMAP_ZOOMOUT : ID_TREEMAP_RESELECT_CHILD;
    const UINT command = clicks > 0 ? commandUp : commandDown;
    const auto currentItem = [zoomCommand]() -> const CItem*
    {
        return zoomCommand
            ? CWinDirStatModel::Get()->GetZoomItem()
            : CFileTreeControl::Get()->GetFirstSelectedItem<CItem>();
    };
    for ([[maybe_unused]] const int i : std::views::iota(0, std::abs(clicks)))
    {
        const CItem* before = currentItem();
        frame->SendMessage(WM_COMMAND, command);
        if (currentItem() == before) break;
    }
    return true;
}
