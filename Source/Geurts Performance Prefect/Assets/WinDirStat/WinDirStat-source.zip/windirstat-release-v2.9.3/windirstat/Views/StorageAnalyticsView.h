﻿// WinDirStat - Windows Directory Statistics
// Copyright © WinDirStat Team
//
// SPDX-License-Identifier: GPL-3.0-or-later
// Distributed WITHOUT ANY WARRANTY; see LICENSE.md for details.

#pragma once

#include "pch.h"
#include "WinDirStatPane.h"

//
// CCenteredEdit. Custom edit control that vertically centers its text.
//
class CCenteredEdit final : public MessageTarget<CCenteredEdit, CEdit>
{
public:
    bool m_isDecimal = false;

protected:
    void OnNcCalcSize(bool bCalcValidRects, NCCALCSIZE_PARAMS* lpncsp);
    void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
public:
    static std::span<const RouteEntry> Routes();

};

//
// CStorageAnalyticsView. Shows storage tier analytics and cloud cost estimations.
//
class CStorageAnalyticsView final : public MessageTarget<CStorageAnalyticsView, CWinDirStatPane>
{
public:
    CStorageAnalyticsView();
    void OnFontSizeChanged(int, int) override;
    ~CStorageAnalyticsView() override = default;

    void OnDraw(CDC* pDC) override;
    void OnUpdate(CWnd* sender, MODEL_CHANGE change, CItem* item) override;
    bool PreprocessMessage(MSG* pMsg) override;
    int OnCreate(LPCREATESTRUCT lpCreateStruct);
    void OnSetFocus(WindowRef pOldWnd);
    void OnSize(UINT nType, int cx, int cy);
    bool OnEraseBkgnd(CDC*) { return true; }
    HBRUSH OnCtlColor(CDC* pDC, WindowRef pWnd, UINT nCtlColor);
    void OnBtnRecalculate();
    void OnComboUnitSelChange();
    void OnEditChange();
    void OnEditChangeRange(UINT nID);

static std::span<const RouteEntry> Routes();

struct TierInfo {
        std::wstring name;

        std::unique_ptr<CStatic> lblThreshold;
        std::unique_ptr<CCenteredEdit> editThreshold;
        std::unique_ptr<CStatic> lblCost;
        std::unique_ptr<CCenteredEdit> editCost;

        double thresholdDays = 0.0;
        double costGiB = 0.0;

        ULONGLONG filesCount = 0;
        ULONGLONG totalSize = 0;

        COLORREF bgLight{}, bgDark{};
        COLORREF borderLight{}, borderDark{};
        COLORREF accent{};

        bool active = true;
    };

private:
    static constexpr UINT RecalculateId = 1001;
    static constexpr UINT UnitId = 1007;

    // Recalculates metrics by traversing the loaded directory tree
    void Recalculate();

    // Validates inputs and optionally applies them to the tiers
    bool ReadParameters(bool apply);

    // Performs a performant single-pass DFS traversal over CItem hierarchy
    void Traverse(CItem* item, FILETIME now);

    // Helper functions for unit selection and cost label generation
    double GetScaleForSelection(int sel) const;
    double GetActiveUnitScale() const;
    void UpdateCostLabels() const;

    std::vector<TierInfo> m_tiers;
    std::wstring m_monthSuffix;

    // UI Configuration controls on the left panel
    CStatic m_lblTitle;
    CStatic m_lblUnit;
    CComboBox m_comboUnit;
    CButton m_btnRecalculate;

    // GDI resources for dashboard painting
    CFont m_fontLeftPanel;
    CFont m_fontLeftPanelTitle;

    int m_lastUnitSel = 1;
    bool m_hasData = false;
    bool m_binsDirty = true;
};

inline std::span<const RouteEntry> CCenteredEdit::Routes()
{
    static constexpr std::array entries
    {
        Route::Window<&OnNcCalcSize>(WM_NCCALCSIZE),
        Route::Window<&OnChar>(WM_CHAR),
    };
    return entries;
}

inline std::span<const RouteEntry> CStorageAnalyticsView::Routes()
{
    static constexpr std::array entries
    {
        Route::Window<&OnCreate>(WM_CREATE),
        Route::Window<&OnSetFocus>(WM_SETFOCUS),
        Route::Window<&OnSize>(WM_SIZE),
        Route::Window<&OnEraseBkgnd>(WM_ERASEBKGND),
        Route::Window<&OnCtlColor>(WM_CTLCOLOR),
        Route::Control<&OnBtnRecalculate>(BN_CLICKED, RecalculateId),
        Route::Control<&OnComboUnitSelChange>(CBN_SELCHANGE, UnitId),
        Route::Control<&OnEditChangeRange>(EN_CHANGE, 2000, 2100),
    };
    return entries;
}
