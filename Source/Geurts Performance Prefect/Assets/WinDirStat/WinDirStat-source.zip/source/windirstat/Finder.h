﻿// WinDirStat - Windows Directory Statistics
// Copyright © WinDirStat Team
//
// SPDX-License-Identifier: GPL-3.0-or-later
// Distributed WITHOUT ANY WARRANTY; see LICENSE.md for details.

#pragma once

#include "pch.h"

class Finder
{
protected:

    static constexpr std::wstring_view s_dosPath = L"\\??\\";
    static constexpr std::wstring_view s_dosUNCPath = L"\\??\\UNC\\";
    static constexpr std::wstring_view s_longPath = L"\\\\?\\";
    static constexpr std::wstring_view s_longUNCPath = L"\\\\?\\UNC\\";

public:

    virtual ~Finder() = default;

    virtual bool FindNext() = 0;
    virtual bool FindFile(const CItem* item) = 0;
    virtual inline DWORD GetAttributes() const = 0;
    virtual inline ULONGLONG GetFileSizePhysical() const = 0;
    virtual inline ULONGLONG GetFileSizeLogical() const = 0;
    virtual inline FILETIME GetLastWriteTime() const = 0;
    virtual std::wstring GetFilePath() const = 0;
    virtual std::wstring_view GetFileName() const = 0;
    virtual std::wstring GetShellPath() const { return {}; }
    virtual PCIDLIST_ABSOLUTE GetShellPidl() const { return nullptr; }
    virtual inline ULONGLONG GetIndex() const = 0;
    virtual DWORD GetReparseTag() const = 0;
    virtual bool IsReserved() const = 0;
    virtual bool HasIgnoredStream() const = 0;

    bool IsDirectory() const
    {
        return (GetAttributes() & FILE_ATTRIBUTE_DIRECTORY) != 0;
    }

    bool IsHidden() const
    {
        return (GetAttributes() & FILE_ATTRIBUTE_HIDDEN) != 0;
    }

    bool IsHiddenSystem() const
    {
        constexpr DWORD hiddenSystem = FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM;
        return (GetAttributes() & hiddenSystem) == hiddenSystem;
    }

    bool IsProtectedReparsePoint() const
    {
        constexpr DWORD protect = FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM | FILE_ATTRIBUTE_REPARSE_POINT;
        return (GetAttributes() & protect) == protect;
    }

    virtual std::wstring GetFilePathLong() const
    {
        return MakeLongPathCompatible(GetFilePath());
    }

    static std::wstring MakeLongPathCompatible(const std::wstring& path)
    {
        if (path.size() >= 3 && path[1] == L':' && path[2] == L'\\') return s_longPath.data() + path;
        if (path.starts_with(L"\\\\?")) return path;
        if (path.starts_with(L"\\\\")) return s_longUNCPath.data() + path.substr(2);
        return path;
    }

    using REPARSE_DATA_BUFFER = struct REPARSE_DATA_BUFFER {
        ULONG  ReparseTag;
        USHORT ReparseDataLength;
        USHORT Reserved;
        USHORT SubstituteNameOffset;
        USHORT SubstituteNameLength;
        USHORT PrintNameOffset;
        USHORT PrintNameLength;
        WCHAR PathBuffer[1];
    };

    static bool IsMountPoint(REPARSE_DATA_BUFFER & reparseBuffer)
    {
        if (reparseBuffer.ReparseTag == IO_REPARSE_TAG_MOUNT_POINT)
        {
            const auto path = ByteOffset<WCHAR>(reparseBuffer.PathBuffer, reparseBuffer.SubstituteNameOffset);
            if (constexpr auto volumeIdentifier = LR"(\??\Volume)";
                reparseBuffer.SubstituteNameLength / sizeof(WCHAR) >= wcslen(volumeIdentifier) &&
                _wcsnicmp(path, volumeIdentifier, wcslen(volumeIdentifier)) == 0)
            {
                return true;
            }
        }

        return false;
    }

    bool RequiresBasicEnumeration() const
    {
        return GetReparseTag() == IO_REPARSE_TAG_MOUNT_POINT ||
            GetReparseTag() == IO_REPARSE_TAG_SYMLINK ||
            GetReparseTag() == IO_REPARSE_TAG_JUNCTION_POINT;
    }

    static bool IsJunction(REPARSE_DATA_BUFFER& reparseBuffer)
    {
        return reparseBuffer.ReparseTag == IO_REPARSE_TAG_MOUNT_POINT &&
            !IsMountPoint(reparseBuffer);
    }
};
