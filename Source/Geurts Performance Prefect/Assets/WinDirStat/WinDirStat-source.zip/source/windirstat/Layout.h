﻿// WinDirStat - Windows Directory Statistics
// Copyright © WinDirStat Team
//
// SPDX-License-Identifier: GPL-3.0-or-later
// Distributed WITHOUT ANY WARRANTY; see LICENSE.md for details.

#pragma once

#include "pch.h"

//
// CLayout. A poor man's dialog layout mechanism.
// Simple, flat, and sufficient for our purposes.
//
class CLayout final
{
    template <typename T>
    struct SControlInfoT
    {
        HWND control;
        T movex;
        T movey;
        T stretchx;
        T stretchy;

        CRect originalRectangle;

        SControlInfoT(HWND ctl, const T& x, const T& y, const T& w, const T& h)
            : control(ctl)
              , movex(x)
              , movey(y)
              , stretchx(w)
              , stretchy(h)
        {
        }
    };

    using SControlInfo = SControlInfoT<double>;

    class CSizeGripper final : public MessageTarget<CSizeGripper, CWnd>
    {
    public:
        const int m_width = ScaleForDpi(14);

        CSizeGripper() = default;
        void Create(CWnd* parent, CRect rc);

    private:
        static void DrawShadowLine(CDC* pdc, CPoint start, CPoint end);

    public:
        static std::span<const RouteEntry> Routes();

    protected:
        void OnPaint();
        LRESULT OnNcHitTest(CPoint point) const;
    };

    class CPositioner final
    {
    public:
        CPositioner(int nNumWindows = 10);
        ~CPositioner();
        void SetWindowPos(HWND hWnd, int x, int y, int cx, int cy, UINT uFlags);

    private:
        HDWP m_wdp;
    };

public:
    CLayout(CWnd* dialog, RECT* placement);
    int AddControl(CWnd* control, double movex, double movey, double stretchx, double stretchy);
    void AddControl(UINT id, double movex, double movey, double stretchx, double stretchy);

    void OnInitDialog(bool centerWindow);
    void OnSize();
    void OnGetMinMaxInfo(MINMAXINFO* mmi) const;
    void OnDestroy() const;

protected:
    RECT* m_wp;
    CWnd* m_dialog;
    CSize m_originalDialogSize;
    std::vector<SControlInfo> m_control;
    CSizeGripper m_sizeGripper;
};

//
// CLayoutDialog. A class that provides automatic layout management
// for dialogs. Inherit from this class instead of CDialog to get automatic
// m_layout support with OnSize, OnGetMinMaxInfo, and OnDestroy handling.
//
class CLayoutDialog : public MessageTarget<CLayoutDialog, CDialog>
{
protected:
    CLayout m_layout;

    // Constructor that takes dialog ID and window placement
    CLayoutDialog(const UINT nIDTemplate, RECT* placement, WindowRef pParent = nullptr)
        : MessageTarget(nIDTemplate, pParent)
        , m_layout(this, placement)
    {
    }

    // Message handlers
public:
    static std::span<const RouteEntry> Routes();

protected:
    void OnSize(UINT nType, int cx, int cy);
    void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
    void OnDestroy();
    void SavePersistentAttributes() const override { m_layout.OnDestroy(); }
};

inline std::span<const RouteEntry> CLayoutDialog::Routes()
{
    static constexpr std::array entries
    {
        Route::Window<&OnSize>(WM_SIZE),
        Route::Window<&OnGetMinMaxInfo>(WM_GETMINMAXINFO),
        Route::Window<&OnDestroy>(WM_DESTROY),
    };
    return entries;
}

inline std::span<const RouteEntry> CLayout::CSizeGripper::Routes()
{
    static constexpr std::array entries
    {
        Route::Window<&OnPaint>(WM_PAINT),
        Route::Window<&OnNcHitTest>(WM_NCHITTEST),
    };
    return entries;
}
