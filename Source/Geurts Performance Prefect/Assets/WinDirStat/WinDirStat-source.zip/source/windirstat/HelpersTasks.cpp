﻿// WinDirStat - Windows Directory Statistics
// Copyright © WinDirStat Team
//
// SPDX-License-Identifier: GPL-3.0-or-later
// Distributed WITHOUT ANY WARRANTY; see LICENSE.md for details.

#include "pch.h"
#include "HelpersTasks.h"
#include "FinderBasic.h"

#pragma comment(lib,"powrprof.lib")
#pragma comment(lib,"wbemuuid.lib")
#pragma comment(lib,"virtdisk.lib")
#pragma comment(lib,"mpr.lib")

static NTSTATUS(NTAPI* NtSetInformationProcess)(HANDLE ProcessHandle, ULONG ProcessInformationClass,
    PVOID ProcessInformation, ULONG ProcessInformationLength) = reinterpret_cast<decltype(NtSetInformationProcess)>(
        reinterpret_cast<LPVOID>(GetProcAddress(GetModuleHandle(L"ntdll.dll"), "NtSetInformationProcess")));

static void CloseAlgProvider(const BCRYPT_ALG_HANDLE h) noexcept { BCryptCloseAlgorithmProvider(h, 0); }
static void FreeXxHashState(XXH3_state_t* state) noexcept { XXH3_freeState(state); }

static HRESULT WmiConnect(CComPtr<IWbemServices>& pSvc)
{
    if (thread_local SmartPointer comInit([](PVOID) noexcept { CoUninitialize(); }, PVOID{});
        comInit == nullptr)
    {
        if (const HRESULT result = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
            FAILED(result) && result != RPC_E_CHANGED_MODE) return result;
        comInit = reinterpret_cast<PVOID>(1);
    }

    CComPtr<IWbemLocator> locObj;
    return SUCCEEDED(CoCreateInstance(CLSID_WbemLocator, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&locObj))) &&
        SUCCEEDED(locObj->ConnectServer(CComBSTR(L"ROOT\\CIMV2"), nullptr, nullptr, nullptr, 0, nullptr, nullptr, &pSvc)) &&
        SUCCEEDED(CoSetProxyBlanket(pSvc, RPC_C_AUTHN_WINNT, RPC_C_AUTHZ_NONE, nullptr,
            RPC_C_AUTHN_LEVEL_CALL, RPC_C_IMP_LEVEL_IMPERSONATE, nullptr, EOAC_NONE)) ? S_OK : E_FAIL;
}

// WMI helpers
void QueryShadowCopies(ULONGLONG& count, ULONGLONG& bytesUsed)
{
    count = 0;
    bytesUsed = 0;
    if (!IsElevationActive()) return;

    CComPtr<IWbemServices> svcObj;
    CComPtr<IEnumWbemClassObject> enumObj;
    if (FAILED(WmiConnect(svcObj)) ||
        FAILED(svcObj->ExecQuery(CComBSTR(L"WQL"), CComBSTR(L"SELECT UsedSpace FROM Win32_ShadowStorage"),
            WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, nullptr, &enumObj))) return;

    // Sum up all used space
    while (true)
    {
        ULONG uRet;
        CComPtr<IWbemClassObject> pObj;
        if (enumObj->Next(WBEM_INFINITE, 1, &pObj, &uRet) != WBEM_S_NO_ERROR || uRet == 0) break;

        CComVariant usedStr, usedString;
        if (SUCCEEDED(pObj->Get(L"UsedSpace", 0, &usedStr, nullptr, nullptr)) &&
            SUCCEEDED(VariantChangeType(&usedString, &usedStr, 0, VT_UI8)))
            bytesUsed += usedString.ullVal;
    }

    // Count existing shadow copies
    enumObj.Release();
    if (SUCCEEDED(svcObj->ExecQuery(CComBSTR(L"WQL"), CComBSTR(L"SELECT ID FROM Win32_ShadowCopy"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, nullptr, &enumObj)))
    {
        for (ULONG ret = 0;; ++count)
        {
            CComPtr<IWbemClassObject> pObj;
            if (enumObj->Next(WBEM_INFINITE, 1, &pObj, &ret) != WBEM_S_NO_ERROR || ret == 0) break;
        }
    }
}

std::vector<std::wstring> QueryWmiStringProperty(const std::wstring& wmiClass, const std::wstring& property, const std::wstring& whereClause)
{
    std::vector<std::wstring> results;
    CComPtr<IWbemServices> svcObj;
    CComPtr<IEnumWbemClassObject> enumObj;
    if (FAILED(WmiConnect(svcObj)) || !svcObj ||
        FAILED(svcObj->ExecQuery(CComBSTR(L"WQL"),
            CComBSTR(std::format(L"SELECT {} FROM {} WHERE {}", property, wmiClass, whereClause).c_str()),
            WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, nullptr, &enumObj)))
    {
        return results;
    }

    while (true)
    {
        ULONG uRet;
        CComPtr<IWbemClassObject> pObj;
        if (enumObj->Next(WBEM_INFINITE, 1, &pObj, &uRet) != WBEM_S_NO_ERROR || uRet == 0) break;

        CComVariant vtVal;
        if (SUCCEEDED(pObj->Get(property.c_str(), 0, &vtVal, nullptr, nullptr)) && vtVal.vt == VT_BSTR)
        {
            results.emplace_back(vtVal.bstrVal);
        }
    }

    return results;
}

void RemoveWmiInstances(const std::wstring& wmiClass, CProgressDlg* pdlg, const std::wstring& whereClause)
{
    CComPtr<IWbemServices> svcObj;
    CComPtr<IWbemClassObject> classObj;
    CComPtr<IEnumWbemClassObject> enumObj;
    if (FAILED(WmiConnect(svcObj)) || !svcObj ||
        FAILED(svcObj->GetObject(CComBSTR(wmiClass.c_str()), 0, nullptr, &classObj, nullptr)) || !classObj ||
        FAILED(svcObj->ExecQuery(CComBSTR(L"WQL"), CComBSTR(std::format(L"SELECT __PATH FROM {} WHERE {}", wmiClass, whereClause).c_str()),
            WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, nullptr, &enumObj)))
    {
        return;
    }

    for (; !pdlg->IsCancelled(); pdlg->Increment())
    {
        ULONG uRet;
        CComPtr<IWbemClassObject> pObj;
        if (enumObj->Next(WBEM_INFINITE, 1, &pObj, &uRet) != WBEM_S_NO_ERROR || uRet == 0) break;

        CComVariant vtPath;
        if (SUCCEEDED(pObj->Get(L"__PATH", 0, &vtPath, nullptr, nullptr)) && vtPath.vt == VT_BSTR)
        {
            svcObj->DeleteInstance(vtPath.bstrVal, 0, nullptr, nullptr);
        }
    }
}

bool CreateShadowCopy(const std::wstring& volumePath)
{
    CComPtr<IWbemServices> svcObj;
    CComPtr<IWbemClassObject> classObj;
    CComPtr<IWbemClassObject> inParams;
    CComPtr<IWbemClassObject> outParams;
    CComVariant vtReturnValue;

    if (FAILED(WmiConnect(svcObj)) ||
        FAILED(svcObj->GetObject(CComBSTR(L"Win32_ShadowCopy"), 0, nullptr, &classObj, nullptr)) ||
        FAILED(classObj->GetMethod(L"Create", 0, &inParams, nullptr)))
    {
        return false;
    }

    // Ensure volume path ends with backslash
    std::wstring volume = volumePath;
    if (!volume.empty() && !volume.ends_with(L'\\')) volume += L'\\';

    // Attempt to do the shadow copy creation
    CComVariant vtVolume(volume.c_str());
    CComVariant vtContext(L"ClientAccessible");
    if (FAILED(inParams->Put(L"Volume", 0, &vtVolume, 0)) ||
        FAILED(inParams->Put(L"Context", 0, &vtContext, 0)) ||
        FAILED(svcObj->ExecMethod(CComBSTR(L"Win32_ShadowCopy"), CComBSTR(L"Create"),
            0, nullptr, inParams, &outParams, nullptr)) || !outParams ||
        FAILED(outParams->Get(L"ReturnValue", 0, &vtReturnValue, nullptr, nullptr)))
    {
        return false;
    }

    return vtReturnValue.vt == VT_I4 && vtReturnValue.lVal == 0;
}

std::vector<std::wstring> GetDriveList(const std::vector<UINT>& driveTypes, const bool checkLocal, const bool checkRemote)
{
    std::vector<std::wstring> drives;
    const DWORD driveMask = GetLogicalDrives();

    for (const auto [i, letter] : std::views::enumerate(wds::strAlpha))
    {
        if ((driveMask & (1 << i)) == 0) continue;

        // See if the drive type matches and the drive is accessible
        const std::array<WCHAR, 4> driveStr = { letter, L':', L'\\', L'\0' };
        const UINT driveType = GetDriveType(driveStr.data());
        if (std::ranges::contains(driveTypes, driveType))
        {
            // Check if the drive is actually accessible
            if ((checkLocal && driveType != DRIVE_REMOTE ||
                checkRemote && driveType == DRIVE_REMOTE) && !DriveExists(driveStr.data())) continue;

            // Passed checks - add to drive list
            drives.push_back(std::wstring{ letter, L':' });
        }
    }

    return drives;
}

// File system helpers
bool FolderExists(const std::wstring& path) noexcept
{
    const DWORD result = GetFileAttributes(FinderBasic::MakeLongPathCompatible(path).c_str());
    return result != INVALID_FILE_ATTRIBUTES && (result & FILE_ATTRIBUTE_DIRECTORY) != 0;
}

bool DriveExists(const std::wstring& path, const bool checkAccess) noexcept
{
    if (path.size() < 2 || path[1] != wds::chrColon) return false;

    const int d = std::towupper(path[0]) - wds::strAlpha[0];
    return d >= 0 && d < 26 && (GetLogicalDrives() & (1UL << d)) != 0 &&
        (!checkAccess || GetVolumeInformation(path.c_str(), nullptr, 0, nullptr, nullptr, nullptr, nullptr, 0) != 0);
}

bool IsLocalDrive(const std::wstring& path) noexcept
{
    if (path.size() < 3 || path[1] != wds::chrColon || path[2] != wds::chrBackslash)
    {
        return false;
    }

    const auto driveType = GetDriveType(GetDrive(path).c_str());
    return driveType == DRIVE_REMOVABLE || driveType == DRIVE_FIXED;
}

std::wstring GetVolumeName(const std::wstring& rootPath)
{
    std::wstring volumeName(MAX_PATH, L'\0');
    std::wstring volumePath = rootPath;
    if (volumePath.back() != L'\\') volumePath += L'\\';
    GetVolumeInformation(volumePath.c_str(), volumeName.data(),
        static_cast<DWORD>(volumeName.size()), nullptr, nullptr, nullptr, nullptr, 0);
    volumeName.resize(wcslen(volumeName.data()));
    return volumeName;
}

bool DeleteFileForce(const std::wstring& path, DWORD attributes)
{
    // Attempt deletion
    if (DeleteFile(path.c_str())) return true;

    // If attributes not provided, query them
    if (attributes == INVALID_FILE_ATTRIBUTES)
    {
        attributes = GetFileAttributes(path.c_str());
    }

    // Clear problematic attributes
    const DWORD newAttrs = attributes == INVALID_FILE_ATTRIBUTES ? FILE_ATTRIBUTE_NORMAL :
        attributes & ~(FILE_ATTRIBUTE_READONLY | FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM);
    if (newAttrs != attributes)
    {
        SetFileAttributes(path.c_str(), newAttrs);
        if (DeleteFile(path.c_str())) return true;
    }

    // If normal delete failed, try delete-on-close
    const SmartPointer handle(CloseHandle, CreateFile(path.c_str(), DELETE,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        nullptr, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, nullptr));
    if (handle == INVALID_HANDLE_VALUE) return false;

    FILE_DISPOSITION_INFO info{ .DeleteFile = true };
    SetFileInformationByHandle(handle, FileDispositionInfo, &info, sizeof(info));
    return GetFileAttributes(path.c_str()) == INVALID_FILE_ATTRIBUTES
        && GetLastError() == ERROR_FILE_NOT_FOUND;
}

// Path utilities
std::wstring QueryDosDevicePath(const std::wstring& drive)
{
    if (drive.size() < 2 || drive[1] != wds::chrColon) return {};

    std::array<WCHAR, 512> info;
    if (::QueryDosDevice(GetDrive(drive).c_str(), info.data(), std::ssize(info)) == 0)
    {
        VTRACE(L"QueryDosDevice({}) Failed: {}", GetDrive(drive), TranslateError());
        return {};
    }

    return info.data();
}

bool IsSUBSTedDrive(const std::wstring& drive)
{
    const std::wstring info = QueryDosDevicePath(drive);
    return info.starts_with(L"\\??\\");
}

// Hibernation
void DisableHibernate() noexcept
{
    BOOLEAN hibernateEnabled = false;
    (void)CallNtPowerInformation(SystemReserveHiberFile, &hibernateEnabled,
        sizeof(hibernateEnabled), nullptr, 0);

    // Delete file in the event that the above call does not actually delete the file as
    // designed or hibernate was previously disabled in a way that did not delete the file
    if (WCHAR drive[3]; GetEnvironmentVariable(L"SystemDrive", drive, std::size(drive)) == std::size(drive) - 1)
    {
        DeleteFile((drive + std::wstring(L"\\hiberfil.sys")).c_str());
    }
}

bool IsStorageSenseAvailable() noexcept
{
    static const bool result = []() noexcept -> bool {
        CRegKey key;
        return key.Open(HKEY_CLASSES_ROOT, L"ms-settings", KEY_READ) == ERROR_SUCCESS;
    }();
    return result;
}

bool IsHibernateEnabled() noexcept
{
    WCHAR drive[3];
    return GetEnvironmentVariable(L"SystemDrive", drive, std::size(drive)) == std::size(drive) - 1 &&
        FinderBasic::DoesFileExist(drive + std::wstring(L"\\"), L"hiberfil.sys");
}

// Elevation and privileges
bool IsElevationActive() noexcept
{
    static const auto result = []() noexcept -> bool
    {
        SmartPointer token(CloseHandle, HANDLE{});
        TOKEN_ELEVATION elevation;
        DWORD size = sizeof(TOKEN_ELEVATION);
        if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token) == 0 ||
            GetTokenInformation(token, TokenElevation, &elevation, sizeof(elevation), &size) == 0)
        {
            return false;
        }
        return elevation.TokenIsElevated != 0;
    }();

    return result;
}

bool IsElevationAvailable() noexcept
{
    static const auto result = []() noexcept -> bool
    {
        if (IsElevationActive()) return false;

        SmartPointer token(CloseHandle, HANDLE{});
        TOKEN_ELEVATION_TYPE elevationType;
        DWORD size = sizeof(TOKEN_ELEVATION_TYPE);
        if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token) == 0 ||
            GetTokenInformation(token, TokenElevationType, &elevationType, sizeof(elevationType), &size) == 0)
        {
            return false;
        }

        return elevationType == TokenElevationTypeLimited;
    }();

    return result;
}

void RunElevated(const std::wstring& cmdLine)
{
    PersistedSetting::WritePersistedProperties();
    SmartPointer process(CloseHandle, HANDLE{});
    if (!ShellExecuteWrapper(GetAppFileName(), cmdLine, L"runas",
        GetDialogOwner(), L"", SW_NORMAL, SEE_MASK_NOASYNC, &process)) return;

    AllowSetForegroundWindow(GetProcessId(process));
    ExitProcess(0);
}

bool EnableReadPrivileges() noexcept
{
    // Open a connection to the currently running process token and request
    // we have the ability to look at and adjust our privileges
    SmartPointer token(CloseHandle, HANDLE{});
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token) == 0)
    {
        return false;
    }

    // Fetch a list of privileges we currently have
    std::vector<BYTE> privsBytes(64 * sizeof(LUID_AND_ATTRIBUTES) + sizeof(DWORD), 0);
    const PTOKEN_PRIVILEGES privsAvailable = reinterpret_cast<PTOKEN_PRIVILEGES>(privsBytes.data());
    DWORD privLength = 0;
    if (GetTokenInformation(token, TokenPrivileges, privsBytes.data(),
        static_cast<DWORD>(privsBytes.size()), &privLength) == 0)
    {
        return false;
    }

    bool ret = true;
    for (const auto priv : { SE_RESTORE_NAME, SE_BACKUP_NAME })
    {
        // Populate the privilege adjustment structure
        TOKEN_PRIVILEGES privEntry = {};
        privEntry.PrivilegeCount = 1;
        privEntry.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

        // Translate the privilege name into the binary representation
        if (LookupPrivilegeValue(nullptr, priv, &privEntry.Privileges[0].Luid) == 0)
        {
            ret = false;
            continue;
        }

        // Check if privilege is in the list of ones we have
        const std::span availablePrivileges(privsAvailable->Privileges, privsAvailable->PrivilegeCount);
        if (std::ranges::none_of(availablePrivileges, [&](const LUID_AND_ATTRIBUTES& element) {
            return element.Luid.HighPart == privEntry.Privileges[0].Luid.HighPart &&
                element.Luid.LowPart == privEntry.Privileges[0].Luid.LowPart; }))
        {
            ret = false;
            continue;
        }

        // Adjust the process to change the privilege
        if (AdjustTokenPrivileges(token, false, &privEntry,
            sizeof(TOKEN_PRIVILEGES), nullptr, nullptr) == 0)
        {
            ret = false;
            break;
        }

        // Error if not all items were assigned
        if (GetLastError() == ERROR_NOT_ALL_ASSIGNED)
        {
            ret = false;
            break;
        }
    }

    return ret;
}

// SID helpers
std::wstring GetNameFromSid(const PSID sid)
{
    // return immediately if sid is null or invalid
    if (sid == nullptr || !IsValidSid(sid)) return {};

    // attempt to look up sid in cache (guarded since callers may be on worker threads)
    const std::vector sidVec(ByteOffset<BYTE>(sid, 0), ByteOffset<BYTE>(sid, GetLengthSid(sid)));
    static std::mutex nameMapMutex;
    static std::map<std::vector<BYTE>, std::wstring> nameMap;
    {
        std::scoped_lock lock(nameMapMutex);
        if (const auto iter = nameMap.find(sidVec); iter != nameMap.end()) return iter->second;
    }

    // query required buffer sizes first so long domains (e.g. APPLICATION PACKAGE AUTHORITY) resolve
    SID_NAME_USE nameUse;
    DWORD accountSize = 0;
    DWORD domainSize = 0;
    LookupAccountSid(nullptr, sid, nullptr, &accountSize, nullptr, &domainSize, &nameUse);
    if (accountSize > 0)
    {
        std::wstring accountName(accountSize, L'\0');
        std::wstring domainName(domainSize, L'\0');
        if (LookupAccountSid(nullptr, sid, accountName.data(), &accountSize,
            domainName.data(), &domainSize, &nameUse) != 0)
        {
            accountName.resize(accountSize);
            domainName.resize(domainSize);

            // omit the domain prefix for well-known identities with none (e.g. Everyone)
            std::scoped_lock lock(nameMapMutex);
            return nameMap.try_emplace(sidVec, domainName.empty() ? accountName :
                std::format(L"{}\\{}", domainName, accountName)).first->second;
        }
    }

    // fallback: return sid string
    SmartPointer sidBuff(LocalFree, static_cast<LPWSTR>(nullptr));
    ConvertSidToStringSid(sid, &sidBuff);
    std::scoped_lock lock(nameMapMutex);
    return nameMap.try_emplace(sidVec, sidBuff != nullptr ?
        std::wstring(sidBuff) : std::wstring()).first->second;
}

// Compression
bool CompressFileAllowed(const std::wstring& volumeName, const CompressionAlgorithm algorithm)
{
    // When scanning a specific folder GetVolumeRoot() returns a directory item, so
    // GetPath() yields a path without a trailing backslash that fails GetVolumeInformation().
    std::array<WCHAR, MAX_PATH> volumeRoot{};
    const std::wstring resolvedVolume = (!volumeName.ends_with(L'\\') &&
        GetVolumePathName(volumeName.c_str(), volumeRoot.data(), static_cast<DWORD>(volumeRoot.size()))) ?
        std::wstring(volumeRoot.data()) : volumeName;

    static std::unordered_map<std::wstring, bool> compressionStandard;
    static std::unordered_map<std::wstring, bool> compressionModern;

    // Enable 'none' button if at least standard is available
    if (algorithm == NONE)
    {
        return CompressFileAllowed(resolvedVolume, LZNT1) ||
            CompressFileAllowed(resolvedVolume, XPRESS4K);
    }

    const auto& compressionMap = (algorithm == LZNT1) ?
        compressionStandard : compressionModern;

    if (const auto it = compressionMap.find(resolvedVolume); it != compressionMap.end())
    {
        return it->second;
    }

    // Query volume for standard compression support based on whether NTFS
    std::array<WCHAR, MAX_PATH> fileSystemName{};
    DWORD fileSystemFlags = 0;
    const bool isNTFS = GetVolumeInformation(resolvedVolume.c_str(), nullptr, 0, nullptr, nullptr,
        &fileSystemFlags, fileSystemName.data(), std::ssize(fileSystemName)) != 0 &&
        std::wstring(fileSystemName.data()) == L"NTFS";

    // Query volume for modern compression support based on NTFS and OS version
    compressionStandard[resolvedVolume] = isNTFS && (fileSystemFlags & FILE_FILE_COMPRESSION) != 0;
    compressionModern[resolvedVolume] = isNTFS && IsWindows10OrGreater() && !resolvedVolume.starts_with(L"\\\\");

    return compressionMap.at(resolvedVolume);
}

bool CompressFile(const std::wstring& filePath, const CompressionAlgorithm algorithm)
{
    USHORT numericAlgorithm = static_cast<USHORT>(algorithm) & ~FILE_PROVIDER_COMPRESSION_MODERN;
    const bool modernAlgorithm = static_cast<USHORT>(algorithm) != numericAlgorithm;

    const SmartPointer handle(CloseHandle, CreateFile(filePath.c_str(),
        GENERIC_READ | GENERIC_WRITE, 0, nullptr, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, nullptr));
    if (handle == INVALID_HANDLE_VALUE)
    {
        VTRACE(L"CreateFile() Error: {:#08X}", GetLastError());
        return false;
    }

    DWORD bytesReturned = 0;
    bool status = false;
    if (modernAlgorithm)
    {
        struct
        {
            WOF_EXTERNAL_INFO wof_info;
            FILE_PROVIDER_EXTERNAL_INFO_V1 file_info;
        }
        info =
        {
            .wof_info = {
                .Version = WOF_CURRENT_VERSION,
                .Provider = WOF_PROVIDER_FILE,
            },
            .file_info = {
                .Version = FILE_PROVIDER_CURRENT_VERSION,
                .Algorithm = numericAlgorithm,
            },
        };

        status = DeviceIoControl(handle, FSCTL_SET_EXTERNAL_BACKING,
            &info, sizeof(info), nullptr, 0, &bytesReturned, nullptr);
    }
    else if (numericAlgorithm == COMPRESSION_FORMAT_LZNT1)
    {
        status = DeviceIoControl(
            handle, FSCTL_SET_COMPRESSION, &numericAlgorithm,
            sizeof(numericAlgorithm), nullptr, 0, &bytesReturned, nullptr);
    }
    else
    {
        // Decompress: clearing standard compression also prompts the WOF
        // driver to fully expand an externally backed file, so the explicit
        // backing removal below is a fallback that typically reports
        // ERROR_OBJECT_NOT_EXTERNALLY_BACKED
        status = DeviceIoControl(
            handle, FSCTL_SET_COMPRESSION, &numericAlgorithm,
            sizeof(numericAlgorithm), nullptr, 0, &bytesReturned, nullptr);

        if (DeviceIoControl(
            handle, FSCTL_DELETE_EXTERNAL_BACKING, nullptr,
            0, nullptr, 0, &bytesReturned, nullptr)) status = true;
    }

    // WOF refuses files that would not shrink - treat as success
    return status || GetLastError() == ERROR_COMPRESSION_NOT_BENEFICIAL;
}

bool SparsifyFile(const std::wstring& path, CProgressDlg* pdlg, const ULONGLONG chunkSize, const ULONGLONG minZeroRunSize)
{
    // Open file with read/write access
    const SmartPointer h(CloseHandle, CreateFile(path.c_str(), GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, nullptr));
    if (h == INVALID_HANDLE_VALUE) return false;
    LARGE_INTEGER fileSize{};
    if (!GetFileSizeEx(h, &fileSize)) return false;

    // Determine filesystem cluster size for alignment
    DWORD sectorsPerCluster = 0, bytesPerSector = 0, dummy1, dummy2;
    wchar_t volume[MAX_PATH];
    ::GetVolumePathName(path.c_str(), volume, MAX_PATH);
    ::GetDiskFreeSpace(volume, &sectorsPerCluster, &bytesPerSector, &dummy1, &dummy2);
    ULONGLONG clusterSize = static_cast<ULONGLONG>(sectorsPerCluster) * bytesPerSector;
    if (clusterSize == 0) clusterSize = 4 * wds::Ki;

    auto alignDown = [clusterSize](const ULONGLONG val) { return (val / clusterSize) * clusterSize; };
    auto alignUp = [clusterSize](const ULONGLONG val) { return ((val + clusterSize - 1) / clusterSize) * clusterSize; };

    struct ZeroRange { ULONGLONG offset, length; };
    std::vector<ZeroRange> ranges;
    std::vector<BYTE> buffer(static_cast<size_t>(chunkSize));
    ULONGLONG pos = 0, runStart = 0, runLen = 0;
    bool inRun = false;

    // Save qualifying zero runs with cluster alignment
    auto saveRun = [&]
    {
        if (inRun && runLen >= minZeroRunSize) {
            const ULONGLONG alignedStart = alignUp(runStart);
            const ULONGLONG alignedEnd = alignDown(runStart + runLen);
            if (alignedEnd > alignedStart)
                ranges.push_back({ alignedStart, alignedEnd - alignedStart });
        }
        inRun = false;
    };

    // Scan file in chunks to detect zero byte runs
    auto isCancelled = [pdlg] { return pdlg != nullptr && pdlg->IsCancelled(); };

    for (DWORD bytesRead = 0; pos < static_cast<ULONGLONG>(fileSize.QuadPart); pos += bytesRead)
    {
        if (isCancelled()) return false;
        const DWORD toRead = static_cast<DWORD>(std::min(chunkSize, static_cast<ULONGLONG>(fileSize.QuadPart) - pos));
        if (!ReadFile(h, buffer.data(), toRead, &bytesRead, nullptr) || !bytesRead) break;

        const BYTE* data = buffer.data();
        for (DWORD i = 0; i < bytesRead; )
        {
            if (data[i] == 0) {
                if (!inRun) { runStart = pos + i; runLen = 0; inRun = true; }

                // Optimized zero detection using 64-bit word scanning
                const BYTE* ptr = data + i;
                const DWORD remaining = bytesRead - i;
                DWORD scanned = 0;

                if (remaining >= 8 && (reinterpret_cast<uintptr_t>(ptr) & 7) == 0)
                {
                    const uint64_t* qword = reinterpret_cast<const uint64_t*>(ptr);
                    while (scanned + 8 <= remaining && *qword++ == 0) scanned += 8;
                }
                while (scanned < remaining && ptr[scanned] == 0) ++scanned;

                runLen += scanned;
                i += scanned;
            }
            else {
                saveRun();
                ++i;
            }
        }
        if (pdlg != nullptr) pdlg->Increment();
    }
    saveRun();

    if (ranges.empty()) return true;

    // Mark file as sparse
    DWORD bytesReturned = 0;
    if (!DeviceIoControl(h, FSCTL_SET_SPARSE, nullptr, 0, nullptr, 0, &bytesReturned, nullptr))
        return false;

    // Deallocate storage for each zero range
    bool success = true;
    for (const auto& [offset, length] : ranges) {
        if (isCancelled()) return false;
        FILE_ZERO_DATA_INFORMATION zdi{};
        zdi.FileOffset.QuadPart = static_cast<LONGLONG>(offset);
        zdi.BeyondFinalZero.QuadPart = static_cast<LONGLONG>(offset + length);
        if (!DeviceIoControl(h, FSCTL_SET_ZERO_DATA, &zdi, sizeof(zdi),
            nullptr, 0, &bytesReturned, nullptr))
            success = false;
    }
    return success;
}

bool CreateHardlinkFromFile(const std::wstring& pathOne, const std::wstring& pathTwo)
{
    // Construct a temporary name in the same directory
    GUID guid;
    if (FAILED(CoCreateGuid(&guid))) return false;
    std::array<WCHAR, GUIDSTRING_MAX> guidStr;
    (void) StringFromGUID2(guid, guidStr.data(), static_cast<int>(guidStr.size()));

    // Create hardlink to source and move it over the target
    const std::wstring tempPath = pathTwo + guidStr.data();
    if (CreateHardLink(tempPath.c_str(), pathOne.c_str(), nullptr) == 0) return false;
    if (MoveFileEx(tempPath.c_str(), pathTwo.c_str(), MOVEFILE_REPLACE_EXISTING) != 0) return true;

    // Do not leave the temporary link behind on failure
    DeleteFile(tempPath.c_str());
    return false;
}

// File hashing
static std::mutex mtpStreamMutex;

HRESULT OpenMtpStream(const CItem* item, CComPtr<IStream>& stream)
{
    // Serialize shell binding while resolving the MTP item to a readable content stream
    const std::scoped_lock lock(mtpStreamMutex);
    const SmartPointer pidl(CoTaskMemFree, CreateShellPidl(item));
    CComPtr<IBindCtx> bindContext;
    CComPtr<IShellItem> shellItem;
    BIND_OPTS options{ sizeof(BIND_OPTS), 0, STGM_READ | STGM_SHARE_DENY_NONE };
    HRESULT result = pidl ? CreateBindCtx(0, &bindContext) : E_FAIL;
    if (FAILED(result) || FAILED(result = bindContext->SetBindOptions(&options)) ||
        FAILED(result = SHCreateItemFromIDList(pidl, IID_PPV_ARGS(&shellItem)))) return result;
    return shellItem->BindToHandler(bindContext, BHID_Stream, IID_PPV_ARGS(&stream));
}

HRESULT ReadFileContent(HANDLE file, IStream* stream, void* buffer, const ULONG size, ULONG* bytesRead,
    const std::optional<ULONGLONG> offset)
{
    // Use native reads for filesystem handles and serialize reads from shell-backed streams
    const LARGE_INTEGER position{ .QuadPart = static_cast<LONGLONG>(offset.value_or(0)) };
    if (!stream)
    {
        if (offset && !SetFilePointerEx(file, position, nullptr, FILE_BEGIN))
            return HRESULT_FROM_WIN32(GetLastError());
        return ReadFile(file, buffer, size, bytesRead, nullptr) ? S_OK : HRESULT_FROM_WIN32(GetLastError());
    }
    const std::scoped_lock lock(mtpStreamMutex);
    if (offset)
        if (const HRESULT result = stream->Seek(position, STREAM_SEEK_SET, nullptr); FAILED(result)) return result;
    return stream->Read(buffer, size, bytesRead);
}

std::wstring ComputeFileHashes(const CItem* item, CProgressDlg* pProgressDlg)
{
    // Open MTP content through the shell and filesystem content through a native handle
    const ComApartmentScope com;
    SmartPointer hFile(CloseHandle, HANDLE{});
    CComPtr<IStream> fileStream;
    if (item->IsTypeOrFlag(ITF_MTP))
    {
        if (!com) return TranslateError(CO_E_NOTINITIALIZED);
        if (const HRESULT result = OpenMtpStream(item, fileStream); FAILED(result)) return TranslateError(result);
    }
    else if ((hFile = CreateFile(item->GetPathLong().c_str(), GENERIC_READ,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING,
        FILE_FLAG_SEQUENTIAL_SCAN, nullptr)) == INVALID_HANDLE_VALUE) return TranslateError();

    // Initialize all hash contexts
    using HashContext = struct HashContext {
        LPCWSTR name = nullptr;
        DWORD objectLen = 0;
        std::vector<BYTE> hashObject;
        std::vector<BYTE> hash;
        SmartPointer<XXH3_state_t*> xxHash = { FreeXxHashState, nullptr };
        SmartPointer<BCRYPT_ALG_HANDLE> hAlg = { CloseAlgProvider, BCRYPT_ALG_HANDLE{} };
        SmartPointer<BCRYPT_HASH_HANDLE, decltype(&BCryptDestroyHash)> hHash = { BCryptDestroyHash, BCRYPT_HASH_HANDLE{} };
    };

    // Set up all algorithms
    std::vector<HashContext> contexts;
    for (const auto& [algorithm, id, name] : HashAlgorithms)
    {
        HashContext ctx;

        // xxHash is not provided by BCrypt; use the bundled implementation
        if (algorithm == HASH_XXHASH)
        {
            ctx.xxHash = XXH3_createState();
            if (!ctx.xxHash.IsValid()) continue;
            ctx.name = name;
            XXH3_64bits_reset(ctx.xxHash);
            contexts.emplace_back(std::move(ctx));
            continue;
        }

        BCRYPT_ALG_HANDLE hAlg = nullptr;
        if (BCryptOpenAlgorithmProvider(&hAlg, id, nullptr, 0) != 0) continue;
        ctx.hAlg = SmartPointer(CloseAlgProvider, hAlg);

        DWORD bytesWritten = 0;
        DWORD hashLen = 0;
        if (BCryptGetProperty(ctx.hAlg, BCRYPT_OBJECT_LENGTH,
            reinterpret_cast<PBYTE>(&ctx.objectLen), sizeof(DWORD), &bytesWritten, 0) != ERROR_SUCCESS ||
            BCryptGetProperty(ctx.hAlg, BCRYPT_HASH_LENGTH,
            reinterpret_cast<PBYTE>(&hashLen), sizeof(DWORD), &bytesWritten, 0) != ERROR_SUCCESS)
        {
            continue;
        }

        ctx.name = name;
        ctx.hashObject.resize(ctx.objectLen);
        ctx.hash.resize(hashLen);

        BCRYPT_HASH_HANDLE hHash = nullptr;
        if (BCryptCreateHash(ctx.hAlg, &hHash, ctx.hashObject.data(),
            ctx.objectLen, nullptr, 0, 0) != 0) continue;

        ctx.hHash = SmartPointer(BCryptDestroyHash, hHash);

        contexts.emplace_back(std::move(ctx));
    }

    // Read file and update all hashes
    constexpr size_t BUFFER_SIZE = wds::Mi; // 1MB chunks
    std::vector<BYTE> buffer(BUFFER_SIZE);
    DWORD bytesRead;
    HRESULT readResult = S_OK;

    // Update all valid hashes with the same buffer in parallel
    while (SUCCEEDED(readResult = ReadFileContent(hFile, fileStream,
        buffer.data(), BUFFER_SIZE, &bytesRead)) && bytesRead > 0)
    {
        if (pProgressDlg->IsCancelled()) return wds::strEmpty;
        std::for_each(std::execution::par, contexts.begin(), contexts.end(),
            [&buffer, bytesRead](auto& ctx) {
                if (ctx.xxHash.IsValid()) XXH3_64bits_update(ctx.xxHash, buffer.data(), bytesRead);
                else (void)BCryptHashData(ctx.hHash, buffer.data(), bytesRead, 0);
            });
        pProgressDlg->Increment();
        // Some shell streams report the final successful partial read with S_FALSE
        if (readResult == S_FALSE) break;
    }
    if (FAILED(readResult)) return TranslateError(readResult);

    // Finalize all hashes and convert to hex strings
    std::wstring result = item->GetPath() + L"\n\n";
    for (auto& ctx : contexts)
    {
        if (ctx.xxHash.IsValid())
        {
            XXH64_canonical_t canonical;
            XXH64_canonicalFromHash(&canonical, XXH3_64bits_digest(ctx.xxHash));
            ctx.hash.assign(canonical.digest, canonical.digest + sizeof(canonical.digest));
        }
        else if (BCryptFinishHash(ctx.hHash, ctx.hash.data(),
            static_cast<ULONG>(ctx.hash.size()), 0) != 0) continue;

        // Add to result
        result += std::format(L"{:\u2007<7}\t{}\n",
            std::wstring(ctx.name) + L':', FormatHex(ctx.hash));
    }
    if (!result.empty() && result.back() == L'\n') result.pop_back();

    return result;
}

// Process priority and VHD optimization
void SetProcessPriority(const int level) noexcept
{
    constexpr std::array cpuPriorities = {
        IDLE_PRIORITY_CLASS,
        NORMAL_PRIORITY_CLASS,
        HIGH_PRIORITY_CLASS
    };
    constexpr ULONG ProcessIoPriority = 33;
    const auto priority = static_cast<size_t>(std::clamp<int>(level, LOW, HIGH));

    if (!SetPriorityClass(GetCurrentProcess(), cpuPriorities[priority]))
    {
        VTRACE(L"SetPriorityClass() Failed");
    }

    ULONG ioPriority = static_cast<ULONG>(priority + 1); // Low, Normal, High
    if (NtSetInformationProcess(GetCurrentProcess(),
        ProcessIoPriority, &ioPriority, sizeof(ioPriority)) != 0)
    {
        VTRACE(L"NtSetInformationProcess() Failed");
    }
}

bool OptimizeVhd(const std::wstring& vhdPath) noexcept
{
    constexpr VIRTUAL_DISK_ACCESS_MASK accessMask = VIRTUAL_DISK_ACCESS_ALL;
    OPEN_VIRTUAL_DISK_PARAMETERS openParams{};
    openParams.Version = OPEN_VIRTUAL_DISK_VERSION_1;

    VIRTUAL_STORAGE_TYPE storageType{
        .DeviceId = VIRTUAL_STORAGE_TYPE_DEVICE_UNKNOWN,
        .VendorId = VIRTUAL_STORAGE_TYPE_VENDOR_MICROSOFT };

    SmartPointer vhdHandle(CloseHandle, HANDLE{});
    if (OpenVirtualDisk(&storageType, vhdPath.c_str(),
        accessMask, OPEN_VIRTUAL_DISK_FLAG_NONE,
        &openParams, &vhdHandle) != ERROR_SUCCESS) return false;

    COMPACT_VIRTUAL_DISK_PARAMETERS compactParams{};
    compactParams.Version = COMPACT_VIRTUAL_DISK_VERSION_1;

    return CompactVirtualDisk(vhdHandle, COMPACT_VIRTUAL_DISK_FLAG_NONE,
        &compactParams, nullptr) == ERROR_SUCCESS;
}

// Drive mappings
void CopyAllDriveMappings() noexcept
{
    if (!IsElevationActive() || !COptions::AutoMapDrivesWhenElevated) return;

    // Open the registry key for network drives
    CRegKey keyNetwork;
    if (keyNetwork.Open(HKEY_CURRENT_USER, L"Network", KEY_READ) != ERROR_SUCCESS) return;

    // Enumerate all drive mappings and attempt to connect in parallel
    std::vector<std::future<void>> futures;
    std::array<WCHAR, MAX_PATH> driveLetter;
    ULONG driveLetterSize = static_cast<ULONG>(driveLetter.size());
    for (DWORD index = 0; keyNetwork.EnumKey(index, driveLetter.data(), &driveLetterSize) == ERROR_SUCCESS;
        ++index, driveLetterSize = static_cast<ULONG>(driveLetter.size()))
    {
        CRegKey keyDrive;
        std::array<WCHAR, MAX_PATH> remotePath{};
        ULONG remotePathSize = static_cast<ULONG>(remotePath.size());
        if (keyDrive.Open(keyNetwork, driveLetter.data(), KEY_READ) == ERROR_SUCCESS &&
            keyDrive.QueryStringValue(L"RemotePath", remotePath.data(), &remotePathSize) == ERROR_SUCCESS)
        {
            std::wstring withColon = driveLetter.data() + std::wstring(L":");
            // An assigned drive letter needs no mapping, even if its server is unresponsive.
            if (DriveExists(withColon, false)) continue;

            futures.emplace_back(std::async(std::launch::async, [withColon, remotePath]
            {
                NETRESOURCEW res{ .dwType = RESOURCETYPE_DISK,
                    .lpLocalName  = const_cast<LPWSTR>(withColon.data()),
                    .lpRemoteName = const_cast<LPWSTR>(remotePath.data()) };
                (void)WNetAddConnection2(&res, nullptr, nullptr, 0);
            }));
        }
    }

    // Wait for all mappings to complete with a busy cursor while keeping the window responsive.
    if (futures.empty()) return;
    CWaitCursor wc;
    CWinApp::RunTaskWithUiUpdates([&]
    {
        for (auto& f : futures) f.wait();
    });
}
