﻿// Geurts Performance Prefect theme adapter for WinDirStat 2.9.3.
// Copyright (c) 2026 Geurts. SPDX-License-Identifier: GPL-3.0-or-later
// Reads only this executable's portable INI. No system theme or registry writes.
#pragma once

namespace PrefectTheme
{
    inline const std::wstring& IniPath()
    {
        static const auto path = [] {
            std::array<wchar_t, 32768> module{};
            const auto length = GetModuleFileNameW(nullptr, module.data(), static_cast<DWORD>(module.size()));
            std::wstring result(module.data(), length);
            const auto dot = result.find_last_of(L'.');
            if (dot != std::wstring::npos) result.resize(dot);
            return result + L".ini";
        }();
        return path;
    }

    inline bool Enabled()
    {
        static const bool enabled = GetPrivateProfileIntW(L"PrefectTheme", L"Enabled", 0, IniPath().c_str()) == 1;
        return enabled && !DarkMode::IsHighContrastActive();
    }

    inline COLORREF ReadColor(const wchar_t* key, COLORREF fallback)
    {
        const auto value = GetPrivateProfileIntW(L"PrefectTheme", key, fallback, IniPath().c_str());
        return value <= 0xFFFFFF ? value : fallback;
    }

    inline COLORREF Color(const wchar_t* key, COLORREF fallback)
    {
        // Read each key once; painting must never perform INI I/O for each pixel/control.
        static std::map<std::wstring, COLORREF> colors;
        static std::mutex gate;
        if (!Enabled()) return fallback;
        const std::lock_guard lock(gate);
        const auto found = colors.find(key);
        if (found != colors.end()) return found->second;
        return colors.emplace(key, ReadColor(key, fallback)).first->second;
    }

    inline void ApplyFont(LOGFONTW& font, int dpi, int percent)
    {
        if (!Enabled()) return;
        const auto size = GetPrivateProfileIntW(L"PrefectTheme", L"FontSizeHundredths", 1300, IniPath().c_str());
        if (size >= 600 && size <= 9600) font.lfHeight = -MulDiv(static_cast<int>(size), dpi * percent, 960000);
        std::array<wchar_t, LF_FACESIZE> family{};
        GetPrivateProfileStringW(L"PrefectTheme", L"FontFamily", L"", family.data(), static_cast<DWORD>(family.size()), IniPath().c_str());
        if (family[0] != L'\0') wcscpy_s(font.lfFaceName, family.data());
    }
}
