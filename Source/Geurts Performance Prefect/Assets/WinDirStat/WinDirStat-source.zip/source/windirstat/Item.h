﻿// WinDirStat - Windows Directory Statistics
// Copyright © WinDirStat Team
//
// SPDX-License-Identifier: GPL-3.0-or-later
// Distributed WITHOUT ANY WARRANTY; see LICENSE.md for details.

#pragma once

#include "pch.h"
#include "TreeListControl.h"
#include "Finder.h"

class Finder;
class FinderNtfsContext;
class FinderBasicContext;

// Columns
enum ITEMCOLUMNS : std::uint8_t
{
    COL_NAME,
    COL_SIZE_PROPORTION,
    COL_PERCENTAGE,
    COL_SIZE_PHYSICAL,
    COL_SIZE_LOGICAL,
    COL_ITEMS,
    COL_FILES,
    COL_FOLDERS,
    COL_LAST_CHANGE,
    COL_ATTRIBUTES,
    COL_OWNER
};

// Item types - all values are bitmasks for efficient type checking
enum ITEMTYPE : std::uint32_t
{
    IT_NONE        = 0u,       // No type
    IT_MYCOMPUTER  = 1u << 0,  // Pseudo Container "My Computer"
    IT_DRIVE       = 1u << 1,  // C:\, D:\ etc.
    IT_DIRECTORY   = 1u << 2,  // Folder
    IT_FILE        = 1u << 3,  // Regular file
    IT_FREESPACE   = 1u << 4,  // Pseudo File "<Free Space>"
    IT_UNKNOWN     = 1u << 5,  // Pseudo File "<Unknown>"
    IT_HLINKS      = 1u << 6,  // Pseudo Container "<Hardlinks>"
    IT_HLINKS_SET  = 1u << 7,  // Pseudo Folder "Index Set N" under <Hardlinks>
    IT_HLINKS_IDX  = 1u << 8,  // Pseudo Folder "Index N" under Index Set
    IT_HLINKS_FILE = 1u << 9,  // Pseudo File reference under Index N
    IT_MASK        = 0x0000FFFF,

    ITHASH_NONE    = 0u,       // Indicates no hash
    ITHASH_SKIP    = 1u << 16, // Indicates cannot be hashed (unreadable)
    ITHASH_SMALL   = 1u << 17, // Indicates a small hash has been performed
    ITHASH_MEDIUM  = 1u << 18, // Indicates a medium hash has been performed
    ITHASH_LARGE   = 1u << 19, // Indicates a large hash has been performed
    ITHASH_MASK    = 0x000F0000,

    ITRP_NONE      = 0u,       // Indicates no reparse data
    ITRP_SYMLINK   = 1u << 20, // Indicates a reparse point that is a symlink
    ITRP_MOUNT     = 1u << 21, // Indicates a reparse point that is a mount point
    ITRP_JUNCTION  = 1u << 22, // Indicates a reparse point that is a junction
    ITRP_CLOUD     = 1u << 23, // Indicates a reparse point that is a cloud link
    ITRP_MASK      = 0x00F00000,

    ITF_NONE       = 0u,       // No flags
    ITF_RESERVED   = 1u << 24, // Indicates special reserved file
    ITF_BASIC      = 1u << 25, // Forces basic finder
    ITF_EXTDATA    = 1u << 26, // Notes extension data has been processed
    ITF_HARDLINK   = 1u << 27, // Indicates file is a hardlink
    ITF_ROOTITEM   = 1u << 28, // Indicates root item
    ITF_DONE       = 1u << 29, // Indicates done processing
    ITF_PREVIEW    = 1u << 30, // Indicates preview item (color stored in index)
    ITF_MTP        = 1u << 31, // Indicates MTP item
    ITF_MASK       = 0xFF000000,

    ITF_ANY        = 0xFFFFFFFF, // Indicates any item type or flag
};

constexpr ITEMTYPE operator~(const ITEMTYPE& a)
{
    return static_cast<ITEMTYPE>(~std::to_underlying(a));
}

constexpr ITEMTYPE operator|(const ITEMTYPE& a, const ITEMTYPE& b)
{
    return static_cast<ITEMTYPE>(std::to_underlying(a) | std::to_underlying(b));
}

constexpr ITEMTYPE operator&(const ITEMTYPE& a, const ITEMTYPE& b)
{
    return static_cast<ITEMTYPE>(std::to_underlying(a) & std::to_underlying(b));
}

constexpr auto operator<=>(const FILETIME& t1, const FILETIME& t2)
{
    return std::bit_cast<std::uint64_t>(t1) <=> std::bit_cast<std::uint64_t>(t2);
}

constexpr bool operator==(const FILETIME& t1, const FILETIME& t2)
{
    return std::bit_cast<std::uint64_t>(t1) == std::bit_cast<std::uint64_t>(t2);
}

//
// CItem. This is the object, from which the whole tree is built.
// For every directory, file etc. we find on the hard disks, there is one CItem.
// It is derived from CTreeListItem because it _may_ become "visible" and therefore
// may be inserted in the TreeList view (we don't clone any data).
//
class __declspec(empty_bases) CItem final : public CTreeListItem
{
public:
    CItem(const CItem&) = delete;
    CItem(CItem&&) = delete;
    CItem& operator=(const CItem&) = delete;
    CItem& operator=(CItem&&) = delete;

    // Construction / Destruction
    static CItem* Create(ITEMTYPE type, std::wstring_view name);
    static CItem* Create(CItem* linkedItem);
    static CItem* Create(ITEMTYPE type, std::wstring_view name, FILETIME lastChange, ULONGLONG sizePhysical,
        ULONGLONG sizeLogical, ULONGLONG index, DWORD attributes, ULONG files, ULONG subdirs);

    static void operator delete(void* mem) noexcept { ::operator delete(mem); }
    ~CItem() override;

    // CTreeListItem Interface
    bool DrawSubItem(int subitem, CDC* pdc, CRect rc, UINT state, int* width, int* focusLeft) override;
    std::wstring GetText(int subitem) const override;
    COLORREF GetItemTextColor() const override;
    int CompareSibling(const CTreeListItem* tlib, int subitem) const override;
    int GetTreeListChildCount() const noexcept override { return IsLeaf() ? 0 : static_cast<int>(GetChildren().size()); }
    CTreeListItem* GetTreeListChild(const int i) const noexcept override { return GetChildren()[i]; }
    HICON GetIcon() override;
    void DrawAdditionalState(CDC* pdc, const CRect& rcLabel) const override;
    CItem* GetLinkedItem() noexcept override;
    const CItem* GetLinkedItem() const noexcept;

    // Hierarchy / Navigation
    const std::vector<CItem*>& GetChildren() const noexcept;
    bool IsLeaf() const noexcept { return m_folderInfo == nullptr; }
    bool HasChildren() const noexcept { return m_folderInfo != nullptr && !m_folderInfo->m_children.empty(); }
    CItem* GetParent() const noexcept { return reinterpret_cast<CItem*>(CTreeListItem::GetParent()); }
    CItem* GetEnumRoot() const noexcept;
    CItem* GetParentDrive() const noexcept;
    CItem* GetVolumeRoot() const noexcept;
    bool IsScanRoot() const noexcept;
    bool IsMtpRoot() const noexcept;
    bool SupportsFilesystemApis() const noexcept { return !IsTypeOrFlag(ITF_MTP); }
    bool HasShellIdentity() const noexcept;
    void AddChild(CItem* child, bool addOnly = false);
    void RemoveChild(CItem* child) const;
    void RemoveAllChildren() const;

    // Size & Statistics
    ULONGLONG GetSizePhysical() const noexcept;
    ULONGLONG GetSizeLogical() const noexcept { return m_sizeLogical; }
    ULONGLONG GetSizePhysicalRaw() const noexcept { return m_sizePhysical; }
    void SetSizePhysical(ULONGLONG size) noexcept { m_sizePhysical = size; }
    void SetSizeLogical(ULONGLONG size) noexcept { m_sizeLogical = size; }
    void UpwardAddSizePhysical(ULONGLONG bytes) noexcept;
    void UpwardSubtractSizePhysical(ULONGLONG bytes) noexcept;
    void UpwardAddSizeLogical(ULONGLONG bytes) noexcept;
    void UpwardSubtractSizeLogical(ULONGLONG bytes) noexcept;
    void UpwardAddFolders(ULONG dirCount) const noexcept;
    void UpwardSubtractFolders(ULONG dirCount) const noexcept;
    void UpwardAddFiles(ULONG fileCount) const noexcept;
    void UpwardSubtractFiles(ULONG fileCount) const noexcept;
    double GetFraction() const noexcept;
    double GetAbsoluteFraction() const noexcept;
    ULONG GetFilesCount() const noexcept { if (IsLeaf()) return 0; return m_folderInfo->m_files; }
    ULONG GetFoldersCount() const noexcept { if (IsLeaf()) return 0; return m_folderInfo->m_subdirs; }
    ULONGLONG GetItemsCount() const noexcept;
    void ExtensionDataAdd();
    void ExtensionDataRemove();
    void ExtensionDataProcessChildren(bool remove = false);

    // Attributes & Properties
    FILETIME GetLastChange() const noexcept
    {
        return std::bit_cast<FILETIME>(m_lastChange.load(std::memory_order_relaxed));
    }
    void SetLastChange(const FILETIME& t) noexcept
    {
        m_lastChange.store(std::bit_cast<ULONGLONG>(t), std::memory_order_relaxed);
    }
    void SetAttributes(DWORD attr) noexcept { m_attributes = LOWORD(attr); }
    DWORD GetAttributes() const noexcept;
    USHORT GetSortAttributes() const noexcept;
    void SetIndex(ULONGLONG index) noexcept { m_index = index; }
    ULONGLONG GetIndex() const noexcept { return m_index; }
    DWORD GetReparseTag() const noexcept;
    void SetReparseTag(DWORD reparseType) noexcept;
    std::wstring GetOwner(bool force = false) const;
    void UpwardUpdateLastChange(const FILETIME& t) noexcept;
    void UpwardRecalcLastChange();

    // Paths & Names
    std::wstring GetName(bool stripDrivePrefix = false) const noexcept;
    std::wstring_view GetNameView(bool stripDrivePrefix = false) const noexcept;
    bool HasExtension(std::wstring_view extension) const noexcept;
    std::wstring GetExtension() const;
    std::wstring GetPath() const;
    int ComparePath(const CItem* other) const;
    std::wstring GetPathLong() const;
    std::wstring GetFolderPath() const;
    bool HasUncPath() const;
    CItem* FindItemByPath(const std::wstring& path, bool findAncestor = false) const;

    // Scanning & Done State
    void SetDone();
    bool IsDone() const noexcept { return IsTypeOrFlag(ITF_DONE); }
    void UpwardSetDone() noexcept;
    void UpwardSetUndone() noexcept;
    ULONG GetReadJobs() const noexcept { if (IsLeaf()) return 0; return m_folderInfo->m_jobs; }
    void UpwardAddReadJobs(ULONG count) const noexcept;
    void UpwardSubtractReadJobs(ULONG count) noexcept;
    ULONGLONG GetTicksWorked() const noexcept;
    void ResetScanStartTime() const noexcept;
    static void SuspendScanClock() noexcept;
    static void ResumeScanClock() noexcept;
    void SortItemsBySizePhysical() const;
    void SortItemsBySizeLogical() const;
    void UpdateStatsFromDisk();
    static void ScanItems(BlockingQueue<CItem*>*, FinderNtfsContext& contextNtfs, FinderBasicContext& contextBasic,
        std::unordered_map<const CItem*, FinderBasicContext>* folderContexts = nullptr);
    static void ScanItemsFinalize(CItem* item);

    // CTreeMap Interface
    bool TmiIsLeaf() const noexcept { return IsLeaf() || IsTypeOrFlag(IT_HLINKS_IDX); }
    COLORREF TmiGetGraphColor() const { return GetGraphColor(); }
    int TmiGetChildCount() const noexcept;
    CItem* TmiGetChild(const int c) const noexcept { return m_folderInfo->m_children[c]; }
    ULONGLONG TmiGetSize() const noexcept;

    // Drive/Volume Specific
    bool IsRootItem() const noexcept { return IsTypeOrFlag(ITF_ROOTITEM); }
    bool SupportsSpaceItems() const noexcept;
    std::vector<CItem*> GetDriveItems() const;
    std::vector<CItem*> GetSpaceItems() const;
    ULONGLONG GetProgressRange() const;
    ULONGLONG GetProgressPos() const;
    static int GetSizeProportionWidth() { return 105; }
    CItem* FindRecyclerItem() const;
    void CreateFreeSpaceItem();
    CItem* FindFreeSpaceItem() const;
    void UpdateFreeSpaceItem();
    void RemoveFreeSpaceItem();
    void CreateUnknownItem();
    CItem* FindUnknownItem() const;
    void UpdateUnknownItem() const;
    void RemoveUnknownItem();
    void UpwardDrivePacman() const;

    // Hardlinks & Hashing
    void CreateHardlinksItem();
    CItem* FindHardlinksItem() const;
    CItem* FindHardlinksIndexItem() const;
    void RemoveHardlinksItem();
    void DoHardlinkAdjustment();
    std::vector<BYTE> GetFileHash(ULONGLONG hashSizeLimit, BlockingQueue<CItem*>* queue, bool sampled);

    ITEMTYPE GetItemType() const noexcept { return m_type & IT_MASK; }
    ITEMTYPE GetRawType() const noexcept { return m_type; }

    template<typename... Args>
    constexpr bool IsTypeOrFlag(Args... args) const noexcept
    {
        const ITEMTYPE combinedMask = (args | ...);
        return (m_type & combinedMask) != IT_NONE;
    }

    template<ITEMTYPE Mask>
    void SetType(const ITEMTYPE type, const bool bitOp = false, const bool unsetVal = false) noexcept
    {
        if (unsetVal) m_type = (m_type & ~type);
        else m_type = bitOp ? (m_type | type) : ((m_type & ~Mask) | type);
    }

    template<typename Predicate = decltype([](const CItem* item) { return item->IsTypeOrFlag(IT_FILE); }) >
    static std::vector<CItem*> GetItemsRecursive(const std::vector<CItem*>& initialItems, Predicate&& predicate = {})
    {
        std::vector<CItem*> items;
        for (std::vector childStack{ initialItems }; !childStack.empty();)
        {
            CItem* item = childStack.back();
            childStack.pop_back();
            if (item->HasChildren())
            {
                const auto& children = item->GetChildren();
                childStack.insert(childStack.end(), children.begin(), children.end());
            }
            else if (std::invoke(predicate, item)) items.emplace_back(item);
        }
        return items;
    }

    void SetReparseType(const ITEMTYPE type) noexcept { SetType<ITRP_MASK>(type); }
    void SetHashType(const ITEMTYPE type, const bool addType = true) noexcept { SetType<ITHASH_MASK>(type, addType); }
    void SetFlag(const ITEMTYPE type, const bool unsetVal = false) noexcept { SetType<ITF_MASK>(type, true, unsetVal); }

private:
    CItem(ITEMTYPE type, std::wstring_view name);
    explicit CItem(CItem* linkedItem);
    CItem(ITEMTYPE type, std::wstring_view name, FILETIME lastChange, ULONGLONG sizePhysical,
        ULONGLONG sizeLogical, ULONGLONG index, DWORD attributes, ULONG files, ULONG subdirs);

    // Dynamic memory management for flexible buffer layout
    static void* operator new(size_t size, std::wstring_view name);
    static void operator delete(void* mem, std::wstring_view) noexcept { ::operator delete(mem); }

    void SetName(std::wstring_view name);
    const wchar_t* GetNameBuffer() const noexcept
    {
        return IsTypeOrFlag(IT_DRIVE) ? m_folderInfo->m_driveName.get() :
            reinterpret_cast<const wchar_t*>(this + 1);
    }
    wchar_t* GetNameBuffer() noexcept
    {
        return const_cast<wchar_t*>(std::as_const(*this).GetNameBuffer());
    }

    ULONGLONG GetProgressRangeMyComputer() const;
    ULONGLONG GetProgressRangeDrive() const;
    COLORREF GetGraphColor() const;
    bool MustShowReadJobs() const noexcept;
    COLORREF GetPercentageColor() const noexcept;
    std::wstring GetPathWithoutSlash() const;

    static constexpr ULONGLONG SCAN_CLOCK_SUSPENDED =
        ULONGLONG{ 1 } << (std::numeric_limits<ULONGLONG>::digits - 1);

    // High bit marks suspension; other bits hold paused milliseconds or frozen active milliseconds.
    inline static std::atomic<ULONGLONG> scanClockState = 0;
    static ULONG GetScanTickCount() noexcept;
    class ScanBatch;
    bool MutateHiddenChildren(const std::function<void()>& mutation) const;
    CItem* AddDirectory(const Finder& finder, ScanBatch& batch);
    CItem* AddFile(const Finder& finder, ScanBatch& batch);

    // Special structure for container items that is separately allocated to
    // reduce memory usage.  This operates under the assumption that most
    // containers have files in them.
    using CHILDINFO = struct CHILDINFO
    {
        std::vector<CItem*> m_children;
        std::unique_ptr<wchar_t[]> m_driveName;
        std::atomic<ULONG> m_tstart = 0;  // time this node started enumerating
        std::atomic<ULONG> m_tfinish = 0; // time this node finished enumerating
        std::atomic<ULONG> m_files = 0;   // # Files in subtree
        std::atomic<ULONG> m_subdirs = 0; // # Folders in subtree
        std::atomic<ULONG> m_jobs = 0;    // # "read jobs" in subtree.
    };

    std::unique_ptr<CHILDINFO> m_folderInfo;   // Child information for non-files
    std::atomic<ULONGLONG> m_sizePhysical = 0; // Total physical size of self or subtree
    std::atomic<ULONGLONG> m_sizeLogical = 0;  // Total local size of self or subtree
    ULONGLONG m_index = 0;                     // Index of item for special scan types
    std::atomic<ULONGLONG> m_lastChange = 0;      // Last modification time of self or subtree
    ITEMTYPE m_type;                           // Indicates our type.
    USHORT m_attributes = 0xFFFF;              // File or directory attributes of the item
    USHORT m_nameLen = 0;                      // Length of name string
};
