﻿// WinDirStat - Windows Directory Statistics
// Copyright © WinDirStat Team
//
// SPDX-License-Identifier: GPL-3.0-or-later
// Distributed WITHOUT ANY WARRANTY; see LICENSE.md for details.

#pragma once

#include "pch.h"
#include "ProgressDlg.h"

constexpr auto signum(auto x) noexcept { return x < 0 ? -1 : x == 0 ? 0 : 1; }
constexpr auto usignum(auto x, auto y) noexcept { return x < y ? -1 : x == y ? 0 : 1; }

constexpr auto FILE_PROVIDER_COMPRESSION_MODERN = 1u << 8;
using CompressionAlgorithm = enum CompressionAlgorithm {
    NONE = COMPRESSION_FORMAT_NONE,
    LZNT1 = COMPRESSION_FORMAT_LZNT1,
    XPRESS4K = FILE_PROVIDER_COMPRESSION_XPRESS4K | FILE_PROVIDER_COMPRESSION_MODERN,
    XPRESS8K = FILE_PROVIDER_COMPRESSION_XPRESS8K | FILE_PROVIDER_COMPRESSION_MODERN,
    XPRESS16K = FILE_PROVIDER_COMPRESSION_XPRESS16K | FILE_PROVIDER_COMPRESSION_MODERN,
    LZX = FILE_PROVIDER_COMPRESSION_LZX | FILE_PROVIDER_COMPRESSION_MODERN
};

using HashAlgorithm = enum HashAlgorithm {
    HASH_MD5,
    HASH_SHA1,
    HASH_SHA256,
    HASH_SHA384,
    HASH_SHA512,
    HASH_XXHASH
};

struct HashAlgorithmInfo
{
    HashAlgorithm algorithm;
    LPCWSTR id;
    LPCWSTR name;
};

constexpr std::array HashAlgorithms = {
    HashAlgorithmInfo{ HASH_MD5, BCRYPT_MD5_ALGORITHM, L"MD5" },
    HashAlgorithmInfo{ HASH_SHA1, BCRYPT_SHA1_ALGORITHM, L"SHA1" },
    HashAlgorithmInfo{ HASH_SHA256, BCRYPT_SHA256_ALGORITHM, L"SHA256" },
    HashAlgorithmInfo{ HASH_SHA384, BCRYPT_SHA384_ALGORITHM, L"SHA384" },
    HashAlgorithmInfo{ HASH_SHA512, BCRYPT_SHA512_ALGORITHM, L"SHA512" },
    HashAlgorithmInfo{ HASH_XXHASH, nullptr, L"xxHash" }
};

// Used at runtime to distinguish between mount points and junction points since they
// share the same reparse tag on the file system.
constexpr DWORD IO_REPARSE_TAG_JUNCTION_POINT = ~IO_REPARSE_TAG_MOUNT_POINT;

template<typename T>
constexpr T* ByteOffset(void* ptr, const std::ptrdiff_t offset) noexcept
{
    return reinterpret_cast<T*>(static_cast<std::byte*>(ptr) + offset);
}

// Task helpers declarations grouped by functionality

// WMI helpers
void QueryShadowCopies(ULONGLONG& count, ULONGLONG& bytesUsed);
std::vector<std::wstring> QueryWmiStringProperty(const std::wstring& wmiClass, const std::wstring& property, const std::wstring& whereClause);
void RemoveWmiInstances(const std::wstring& wmiClass, CProgressDlg* pdlg, const std::wstring& whereClause = L"__PATH IS NOT NULL");
bool CreateShadowCopy(const std::wstring& volumePath);

// Disk utilities
std::vector<std::wstring> GetDriveList(
    const std::vector<UINT> & driveTypes = {DRIVE_FIXED, DRIVE_REMOTE,
    DRIVE_REMOVABLE, DRIVE_RAMDISK }, bool checkLocal = true, bool checkRemote = false);

// File system helpers
bool FolderExists(const std::wstring& path) noexcept;
bool DriveExists(const std::wstring& path, bool checkAccess = true) noexcept;
bool IsLocalDrive(const std::wstring& path) noexcept;
std::wstring GetVolumeName(const std::wstring& rootPath);
bool DeleteFileForce(const std::wstring& path, DWORD attributes = INVALID_FILE_ATTRIBUTES);

// Path utilities
std::wstring QueryDosDevicePath(const std::wstring& drive);
bool IsSUBSTedDrive(const std::wstring& drive);
inline auto GetDrive(const std::wstring_view& sv) { return std::wstring{ sv.substr(0, 2) }; }

// Hibernation
void DisableHibernate() noexcept;
bool IsHibernateEnabled() noexcept;
bool IsStorageSenseAvailable() noexcept;

// Elevation and privileges
bool IsElevationActive() noexcept;
bool IsElevationAvailable() noexcept;
inline bool IsElevationPossible() noexcept { return IsElevationActive() || IsElevationAvailable(); }
bool EnableReadPrivileges() noexcept;
void RunElevated(const std::wstring& cmdLine);

// SID helpers
std::wstring GetNameFromSid(PSID sid);

// Compression
bool CompressFileAllowed(const std::wstring& volumeName, CompressionAlgorithm algorithm);
bool CompressFile(const std::wstring& filePath, CompressionAlgorithm algorithm);
bool SparsifyFile(const std::wstring& path, CProgressDlg* pdlg = nullptr,
    ULONGLONG chunkSize = wds::Mi, ULONGLONG minZeroRunSize = 64ull * wds::Ki);
bool CreateHardlinkFromFile(const std::wstring& pathOne, const std::wstring& pathTwo);

// File hashing
class CItem;
HRESULT OpenMtpStream(const CItem* item, CComPtr<IStream>& stream);
HRESULT ReadFileContent(HANDLE file, IStream* stream, void* buffer, ULONG size, ULONG* bytesRead,
    std::optional<ULONGLONG> offset = std::nullopt);
std::wstring ComputeFileHashes(const CItem* item, CProgressDlg* pProgressDlg);

// Process priority and VHD optimization
void SetProcessPriority(int level) noexcept;
bool OptimizeVhd(const std::wstring& vhdPath) noexcept;

// Drive mappings
void CopyAllDriveMappings() noexcept;
