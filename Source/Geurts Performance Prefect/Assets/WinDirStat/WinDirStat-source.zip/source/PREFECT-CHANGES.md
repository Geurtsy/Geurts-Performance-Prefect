# Geurts Performance Prefect theme build

Modified from WinDirStat release/v2.9.3 on 2026-10-20. Copyright WinDirStat Team;
theme adapter copyright 2026 Geurts. All modifications are GPL-3.0-or-later.
This is a modified, unsigned build and is not an official WinDirStat release.

The optional `[PrefectTheme]` section in the executable's adjacent portable INI
supplies Windows COLORREF values for Background, Panel, Text, Muted, Accent,
Border, Selection, SelectionText and Graph0 through Graph7. FontFamily and
FontSizeHundredths supply the host's font. Values are cached for the session.
Windows high contrast takes precedence; without Enabled=1, normal WinDirStat
appearance is retained. No system theme settings are written.

Changes: PrefectTheme.h; DarkMode.cpp colour roles; UiAppearance.cpp font;
UiControls.cpp tab colours; Controls/WdsListControl.cpp percentage/selection
colours and common-control fallback colours; Controls/TreeMap.cpp graph palette.
Scanning, deletion, elevation, dialogs, file handling and argument parsing are
unchanged. xxHash v0.8.3 source/licence is included under contrib/xxhash so the
native build does not need to download dependencies. project.targets allows an
optional isolated ATL SDK directory via PrefectAtlRoot.

Build with Visual Studio 2026 C++ v145, the Windows SDK and the ATL component:
MSBuild.exe windirstat.sln /p:Configuration=Release /p:Platform=x64 /m:4
The Prefect repository's scripts/Build-WinDirStat.ps1 also builds this archive in
a fresh output directory. Do not run the original upstream build.cmd for this
integration: that script is a separate upstream installer/signing workflow.
